# BlueJob Production Deployment

This file is intentionally operational, not architectural.

## 1. Configure production secrets

Copy:

```bash
cp server/.env.production.example server/.env
```

Generate application encryption keys:

```bash
npm run generate:secrets
```

Put the generated values in your secret manager and `server/.env` on the production host only.

Do not commit `server/.env`.

## 2. Create external services

You need live credentials for:

- PostgreSQL
- Resend
- Twilio Verify
- Stripe
- S3 + KMS
- Malware scanning provider/pipeline

Put those credentials in `server/.env`.

## 3. Configure Stripe

Create a recurring monthly Price for **$15.99** and place the Price ID in:

```text
STRIPE_FOUNDING_PRICE_ID
```

Configure Stripe webhook:

```text
POST https://<API-DOMAIN>/api/billing/webhook
```

Subscribe at minimum to:

- checkout.session.completed
- customer.subscription.updated
- customer.subscription.deleted
- invoice.payment_failed

Store the webhook signing secret as:

```text
STRIPE_WEBHOOK_SECRET
```

## 4. Configure email

Verify `bluejob.net` with your email provider and set:

```text
EMAIL_FROM=BlueJob <account@bluejob.net>
```

## 5. Configure phone verification

Create a Twilio Verify Service and set the service SID.

Use API Key / API Secret credentials in production.

## 6. Configure private evidence storage

Create a private S3 bucket:

- Block all public access
- Enable versioning
- Encrypt with KMS
- Use a narrowly scoped IAM role
- Do not enable website hosting

Set:

```text
STORAGE_MODE=s3
S3_PRIVATE_BUCKET=...
S3_KMS_KEY_ID=...
```

Connect malware scanning so newly uploaded objects stay `PENDING` until the scanner sends:

```text
POST /api/storage/scan-result
```

Files are not reviewable until scan state is `CLEAN`.

## 7. Database

Run:

```bash
npm run api:migrate
```

Bootstrap the founder only once:

```bash
npm run api:seed-founder
```

Then immediately remove `FOUNDER_TEMP_PASSWORD` from the production environment.

The first founder login forces a password change. Admin MFA must then be enabled.

## 8. Validate release

Run:

```bash
npm run verify:release
```

Then test:

```text
GET /api/healthz
GET /api/readyz
```

Both must succeed.

## 9. Required end-to-end test

Before inviting users:

1. Register fresh account.
2. Verify email.
3. Verify phone.
4. Choose Worker.
5. Activate $15.99 membership.
6. Build Work Passport.
7. Upload evidence.
8. Review evidence from Super Admin.
9. Post a real Chrome Construction job.
10. Bid from a separate worker account.
11. Award bid.
12. Start job.
13. Contractor confirms completion.
14. Worker confirms completion.
15. Confirm both score pipelines create new snapshots.
16. Confirm confidential bid data is never exposed to other bidders.
17. Confirm private evidence cannot be opened by a normal member.

Do not open public registration until this flow passes.