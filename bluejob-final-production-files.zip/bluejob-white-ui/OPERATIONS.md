# BlueJob Operations Runbook

## Every day

Check:

- `/api/readyz`
- failed requests / error monitoring
- verification queue
- disputes
- failed Stripe payments
- malware scan failures/quarantines
- new account growth
- marketplace jobs with low response

## Verification handling

Reviewer choices:

- VERIFIED
- REJECTED
- NEEDS_INFO

Never approve a record simply because a document was uploaded.

The verification decision, reviewer, timestamp, and audit event must remain recorded.

## Work Score integrity

Administrators do not manually set public scores.

Admins may:

- approve/reject evidence
- invalidate fraudulent evidence
- resolve disputes
- correct verified records through audited procedures

The scoring service recalculates scores.

## Security incident

If an admin credential is suspected compromised:

1. Disable/suspend the account.
2. Revoke all sessions.
3. Rotate affected provider/API credentials.
4. Review audit log.
5. Rotate application keys only through a planned migration if required.
6. Preserve evidence/logs required for incident review.

## Document incident

If a file is flagged:

1. Set `scan_status=QUARANTINED`.
2. Do not permit admin viewing.
3. Preserve metadata and audit history.
4. Delete only according to the retention/security policy.

## Billing failure

Stripe webhook sets membership to `PAST_DUE`.

Do not delete the user or Work Passport.

Marketplace access can be restricted while professional history remains intact.

## Low-response job

Use actual BlueJob view/bid data.

Do not automatically lower subcontractor pricing.

Recommend that the contractor reevaluate:

- budget
- scope
- schedule
- requirements
- travel/location constraints