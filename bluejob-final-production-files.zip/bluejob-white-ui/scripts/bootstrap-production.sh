#!/bin/sh
set -eu

echo "BlueJob production bootstrap"

if [ ! -f server/.env ]; then
  echo "ERROR: server/.env is missing."
  exit 1
fi

node scripts/check-production-env.mjs server/.env

echo "Installing frontend dependencies..."
npm ci

echo "Installing backend dependencies..."
npm --prefix server ci

echo "Running database migrations..."
npm run api:migrate

echo "Running backend tests..."
npm --prefix server test

echo "Building frontend..."
npm run build

echo "Bootstrap checks complete."
