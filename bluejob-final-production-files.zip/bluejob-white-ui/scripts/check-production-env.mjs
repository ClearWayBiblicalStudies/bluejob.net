import fs from 'node:fs';

const file = process.argv[2] || 'server/.env';
if (!fs.existsSync(file)) {
  console.error(`Missing ${file}`);
  process.exit(1);
}

const content = fs.readFileSync(file, 'utf8');
const map = Object.fromEntries(
  content.split(/\r?\n/)
    .map(line => line.trim())
    .filter(line => line && !line.startsWith('#') && line.includes('='))
    .map(line => {
      const i = line.indexOf('=');
      return [line.slice(0, i), line.slice(i + 1)];
    })
);

const required = [
  'NODE_ENV','DATABASE_URL','APP_ORIGIN','PUBLIC_APP_URL',
  'FILE_ENCRYPTION_KEY','APP_ENCRYPTION_KEY',
  'RESEND_API_KEY','EMAIL_FROM',
  'TWILIO_ACCOUNT_SID','TWILIO_API_KEY','TWILIO_API_KEY_SECRET','TWILIO_VERIFY_SERVICE_SID',
  'STRIPE_SECRET_KEY','STRIPE_WEBHOOK_SECRET','STRIPE_FOUNDING_PRICE_ID',
  'STRIPE_SUCCESS_URL','STRIPE_CANCEL_URL',
  'STORAGE_MODE','AWS_REGION','S3_PRIVATE_BUCKET','S3_KMS_KEY_ID',
  'MALWARE_SCAN_WEBHOOK_SECRET'
];

const missing = required.filter(k => !map[k]);
const unsafe = [];

if (map.NODE_ENV !== 'production') unsafe.push('NODE_ENV must equal production');
if (map.STORAGE_MODE !== 's3') unsafe.push('STORAGE_MODE must equal s3');
if (map.FOUNDER_TEMP_PASSWORD) unsafe.push('FOUNDER_TEMP_PASSWORD must be removed after bootstrap');
if (map.TWILIO_AUTH_TOKEN) unsafe.push('TWILIO_AUTH_TOKEN should not be used in production');

if (missing.length || unsafe.length) {
  if (missing.length) console.error('Missing:', missing.join(', '));
  for (const item of unsafe) console.error('Unsafe:', item);
  process.exit(1);
}
console.log('BlueJob production environment file passes static checks.');