import { randomBytes } from 'node:crypto';

function key() {
  return randomBytes(32).toString('base64');
}
function token() {
  return randomBytes(32).toString('base64url');
}

console.log('# Copy these ONCE into your production secret manager.');
console.log('# Do NOT commit the values to GitHub.');
console.log(`FILE_ENCRYPTION_KEY=${key()}`);
console.log(`APP_ENCRYPTION_KEY=${key()}`);
console.log(`MALWARE_SCAN_WEBHOOK_SECRET=${token()}`);