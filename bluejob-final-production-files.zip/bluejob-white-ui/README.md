# BlueJob White UI

White/blue BlueJob frontend matching the approved visual direction.

## Run

```bash
npm install
npm run dev
```

## Included routes

- `/` — public landing page
- `/signup` — account creation
- `/signin` — sign in
- `/choose-path` — subcontractor vs contractor path
- `/app/worker` — Work Score / Work Passport worker dashboard
- `/app/contractor` — contractor operations dashboard
- `/app/post-job` — 5-step job posting flow
- `/app/jobs/1/bids` — bid comparison + bidding insights

## Important

This package is the UI/application shell. Replace frontend-only auth and example values with production API/database services before public launch. Passwords, payment data, verification documents, Work Score decisions, and admin authorization must be server-side.


## BlueJob Administration

New private founder/admin routes:

- `/admin` — Operations Command Center
- `/admin/users`
- `/admin/organizations`
- `/admin/jobs`
- `/admin/work-scores`
- `/admin/verification`
- `/admin/disputes`
- `/admin/billing`
- `/admin/analytics`
- `/admin/settings`

The current package includes a local founder-preview session for UI development only.

**Production requirement:** every privileged action must be authenticated and authorized by the backend. Never rely on hidden frontend navigation as security. The initial founder account must force a password change and MFA during real authentication setup. Work Scores cannot be manually assigned by administrators.


## Work Passport + Verification Center

Routes:
- `/app/passport`
- `/app/passport/edit`
- `/app/verification`

This version stores only profile/evidence metadata locally for UI testing and never stores actual uploaded document bytes in localStorage.
Production still requires real authentication, encrypted private file storage, backend verification workflow, audit logs, and database persistence.


# Production Backend Foundation

BlueJob now includes a real PostgreSQL-backed API under `server/`.

## What is real in this build

- Server-side account signup/sign-in
- Scrypt password hashing using Node's built-in crypto
- Opaque HttpOnly database-backed sessions
- Forced first-login founder password change
- Backend role authorization
- SUPER_ADMIN / BLUEJOB_ADMIN route protection
- Users and organization memberships
- Chrome Construction and Gulfside Improvements founder seed
- Persistent Work Passports
- Persistent skills and work history
- Private evidence records
- AES-256-GCM encrypted private evidence files
- Admin verification queue
- Evidence review and Work Score recalculation hook
- Work Score snapshots
- Jobs
- Bids
- Live bid-count privacy endpoint
- Subscription database model
- Dispute database model
- Audit log
- Admin platform metrics

## Local setup

Start PostgreSQL:

```bash
docker compose up -d postgres
```

Configure the server:

```bash
cp server/.env.example server/.env
```

Set these values in `server/.env`:

- `DATABASE_URL`
- `FILE_ENCRYPTION_KEY`
- `FOUNDER_EMAIL`
- `FOUNDER_TEMP_PASSWORD`

Never commit `server/.env`.

Install packages:

```bash
npm install
npm --prefix server install
```

Create database tables:

```bash
npm run api:migrate
```

Create the initial founder account and company workspaces:

```bash
npm run api:seed-founder
```

Start the API:

```bash
npm run dev:api
```

Start the web app in another terminal:

```bash
npm run dev:web
```

The founder account is seeded with `must_change_password=true`. On first sign-in, BlueJob routes the founder through a password-change screen and revokes the temporary session afterward.

## Important before public launch

This package is a serious backend foundation, but public launch still requires production infrastructure decisions:

- Durable PostgreSQL hosting and backups
- Durable private object/file storage or a persistent encrypted volume
- Real transactional email delivery for verification and password reset
- Email/phone verification
- MFA implementation for administrators
- Payment-provider integration for the $15.99 founding membership
- Rate limiting / bot protection at the edge
- Malware scanning for uploaded documents
- Monitoring, error reporting, backup restore testing, and incident logging
- Final Terms, Privacy Policy, and verification/dispute policies

Do not deploy the development `MAIL_MODE=console` setting to production.


# Launch Phase

This build adds the final major application systems for a private beta:

- Email verification with Resend
- SMS phone verification with Twilio Verify
- Administrator TOTP MFA and single-use recovery codes
- $15.99/month Founding Membership checkout and subscription webhooks with Stripe
- Stripe Billing Portal handoff
- Application/API rate limiting on sensitive routes
- S3/KMS private evidence upload hooks
- Malware-scan quarantine state and scanner callback hook
- In-app notification records
- Job award/start/completion lifecycle
- Worker-to-contractor structured feedback
- Contractor-to-worker structured feedback
- Worker Work Score recalculation after verified completion
- Contractor Work Score calculation after enough completed projects
- Marketplace response signal based on real views and bids
- CI build/test workflow
- Launch checklist

## Important deployment boundary

The code is ready to be connected to live vendor accounts, but merely having source code does not make a production deployment complete. The live Resend, Twilio, Stripe, S3/KMS, malware scanning, database backups, monitoring, and legal/policy configuration in `LAUNCH_CHECKLIST.md` must be completed and tested before opening BlueJob to the public.
