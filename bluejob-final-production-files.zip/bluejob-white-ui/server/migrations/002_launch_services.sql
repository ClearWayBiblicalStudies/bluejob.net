ALTER TABLE users ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone_verified_at timestamptz;

ALTER TABLE sessions ADD COLUMN IF NOT EXISTS mfa_verified_at timestamptz;

CREATE TABLE IF NOT EXISTS email_verification_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text UNIQUE NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admin_mfa (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  encrypted_secret text NOT NULL,
  enabled_at timestamptz,
  recovery_code_hashes jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE private_files ADD COLUMN IF NOT EXISTS storage_provider text NOT NULL DEFAULT 'LOCAL'
  CHECK (storage_provider IN ('LOCAL','S3'));
ALTER TABLE private_files ADD COLUMN IF NOT EXISTS object_key text;
ALTER TABLE private_files ADD COLUMN IF NOT EXISTS scan_status text NOT NULL DEFAULT 'PENDING'
  CHECK (scan_status IN ('PENDING','CLEAN','QUARANTINED','FAILED'));

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  entity_type text,
  entity_id text,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notifications_user_time ON notifications(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS job_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  reviewer_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  subject_organization_id uuid REFERENCES organizations(id) ON DELETE CASCADE,
  reviewer_side text NOT NULL CHECK (reviewer_side IN ('WORKER','CONTRACTOR')),
  on_time boolean,
  quality_accepted boolean,
  callback_required boolean,
  scope_accurate boolean,
  materials_ready boolean,
  schedule_organized boolean,
  payment_as_agreed boolean,
  communication_good boolean,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(job_id, reviewer_user_id)
);

CREATE TABLE IF NOT EXISTS organization_score_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  score integer,
  status text NOT NULL CHECK (status IN ('BUILDING','ACTIVE')),
  payment_reliability integer,
  scope_accuracy integer,
  project_readiness integer,
  schedule_organization integer,
  repeat_trust integer,
  evidence_strength integer NOT NULL DEFAULT 0,
  model_version text NOT NULL,
  explanation jsonb NOT NULL DEFAULT '{}'::jsonb,
  calculated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_org_score_time ON organization_score_snapshots(organization_id, calculated_at DESC);

CREATE TABLE IF NOT EXISTS job_views (
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  viewer_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  first_viewed_at timestamptz NOT NULL DEFAULT now(),
  last_viewed_at timestamptz NOT NULL DEFAULT now(),
  view_count integer NOT NULL DEFAULT 1,
  PRIMARY KEY(job_id, viewer_user_id)
);

CREATE TABLE IF NOT EXISTS billing_events (
  stripe_event_id text PRIMARY KEY,
  event_type text NOT NULL,
  processed_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_user_status ON subscriptions(user_id,status);
CREATE INDEX IF NOT EXISTS idx_feedback_job ON job_feedback(job_id);