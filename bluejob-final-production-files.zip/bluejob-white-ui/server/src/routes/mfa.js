import { Router } from 'express';
import QRCode from 'qrcode';
import { query } from '../lib/db.js';
import { requireAuth, requireRole, markCurrentSessionMfaVerified } from '../lib/auth.js';
import { generateTotpSecret, buildOtpAuthUri, encryptSecret, decryptSecret, verifyTotp, generateRecoveryCodes, hashRecoveryCode } from '../lib/mfa.js';
import { audit } from '../lib/audit.js';

const router = Router();
router.use(requireAuth, requireRole('VERIFICATION_REVIEWER','BLUEJOB_ADMIN','SUPER_ADMIN'));

router.post('/setup', async (req,res,next) => {
  try {
    const secret=generateTotpSecret();
    const uri=buildOtpAuthUri(secret,req.user.email);
    const qrDataUrl=await QRCode.toDataURL(uri);
    await query(
      `INSERT INTO admin_mfa(user_id,encrypted_secret,enabled_at,recovery_code_hashes,updated_at)
       VALUES($1,$2,NULL,'[]'::jsonb,now())
       ON CONFLICT(user_id) DO UPDATE SET encrypted_secret=EXCLUDED.encrypted_secret,enabled_at=NULL,recovery_code_hashes='[]'::jsonb,updated_at=now()`,
      [req.user.id,encryptSecret(secret)]
    );
    await audit(req,'MFA_SETUP_STARTED','user',req.user.id);
    res.json({qrDataUrl,manualSecret:secret});
  } catch(e){ next(e); }
});

router.post('/enable', async (req,res,next) => {
  try {
    const rec=await query(`SELECT encrypted_secret FROM admin_mfa WHERE user_id=$1`,[req.user.id]);
    if(!rec.rows[0]) return res.status(400).json({error:'Start MFA setup first'});
    const secret=decryptSecret(rec.rows[0].encrypted_secret);
    if(!verifyTotp(secret,req.body?.code)) return res.status(400).json({error:'Invalid authenticator code'});
    const recovery=generateRecoveryCodes();
    await query(`UPDATE admin_mfa SET enabled_at=now(),recovery_code_hashes=$1,updated_at=now() WHERE user_id=$2`,
      [JSON.stringify(recovery.map(hashRecoveryCode)),req.user.id]);
    await markCurrentSessionMfaVerified(req);
    await audit(req,'MFA_ENABLED','user',req.user.id);
    res.json({ok:true,recoveryCodes:recovery});
  } catch(e){ next(e); }
});

router.post('/verify', async (req,res,next) => {
  try {
    const rec=await query(`SELECT encrypted_secret,enabled_at,recovery_code_hashes FROM admin_mfa WHERE user_id=$1`,[req.user.id]);
    if(!rec.rows[0]?.enabled_at) return res.status(400).json({error:'MFA is not enabled'});
    const secret=decryptSecret(rec.rows[0].encrypted_secret);
    const code=String(req.body?.code||'').trim();
    let approved=verifyTotp(secret,code);

    if(!approved && code){
      const hashed=hashRecoveryCode(code);
      const hashes=Array.isArray(rec.rows[0].recovery_code_hashes)?rec.rows[0].recovery_code_hashes:[];
      const index=hashes.indexOf(hashed);
      if(index>=0){
        approved=true;
        const remaining=hashes.filter((_,i)=>i!==index);
        await query(`UPDATE admin_mfa SET recovery_code_hashes=$1,updated_at=now() WHERE user_id=$2`,
          [JSON.stringify(remaining),req.user.id]);
        await audit(req,'MFA_RECOVERY_CODE_USED','user',req.user.id);
      }
    }

    if(!approved) return res.status(400).json({error:'Invalid authenticator or recovery code'});
    await markCurrentSessionMfaVerified(req);
    await audit(req,'MFA_VERIFIED','user',req.user.id);
    res.json({ok:true});
  } catch(e){ next(e); }
});

export default router;