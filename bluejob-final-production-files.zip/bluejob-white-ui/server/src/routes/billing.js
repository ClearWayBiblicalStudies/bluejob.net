import { Router } from 'express';
import { query } from '../lib/db.js';
import { requireAuth } from '../lib/auth.js';
import { stripe } from '../lib/billing.js';
import { audit } from '../lib/audit.js';

const router=Router();
router.use(requireAuth);

router.get('/status',async(req,res,next)=>{
  try{
    const r=await query(`SELECT * FROM subscriptions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1`,[req.user.id]);
    res.json({subscription:r.rows[0]||null});
  }catch(e){next(e);}
});

router.post('/checkout',async(req,res,next)=>{
  try{
    if(!req.user.email_verified_at || !req.user.phone_verified_at){
      return res.status(403).json({error:'Verify your email and phone before activating membership',code:'CONTACT_VERIFICATION_REQUIRED'});
    }
    const price=process.env.STRIPE_FOUNDING_PRICE_ID;
    if(!price) throw new Error('STRIPE_FOUNDING_PRICE_ID is required');
    const active=await query(`SELECT 1 FROM subscriptions WHERE user_id=$1 AND status IN ('ACTIVE','TRIAL') LIMIT 1`,[req.user.id]);
    if(active.rows[0]) return res.status(409).json({error:'Membership is already active'});
    const session=await stripe().checkout.sessions.create({
      mode:'subscription',
      line_items:[{price,quantity:1}],
      success_url:process.env.STRIPE_SUCCESS_URL,
      cancel_url:process.env.STRIPE_CANCEL_URL,
      customer_email:req.user.email,
      client_reference_id:req.user.id,
      metadata:{bluejobUserId:req.user.id,planCode:'FOUNDING_1599'},
      subscription_data:{metadata:{bluejobUserId:req.user.id,planCode:'FOUNDING_1599'}}
    });
    await audit(req,'BILLING_CHECKOUT_CREATED','user',req.user.id,{sessionId:session.id});
    res.json({url:session.url});
  }catch(e){next(e);}
});

router.post('/portal',async(req,res,next)=>{
  try{
    const r=await query(`SELECT provider_customer_id FROM subscriptions WHERE user_id=$1 AND provider_customer_id IS NOT NULL ORDER BY created_at DESC LIMIT 1`,[req.user.id]);
    if(!r.rows[0]) return res.status(400).json({error:'No billing customer exists yet'});
    const portal=await stripe().billingPortal.sessions.create({
      customer:r.rows[0].provider_customer_id,
      return_url:process.env.PUBLIC_APP_URL || 'http://localhost:5173'
    });
    res.json({url:portal.url});
  }catch(e){next(e);}
});

export default router;