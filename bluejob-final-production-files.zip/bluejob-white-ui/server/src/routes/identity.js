import { Router } from 'express';
import { query, tx } from '../lib/db.js';
import { requireAuth } from '../lib/auth.js';
import { randomToken, sha256 } from '../lib/security.js';
import { sendEmail } from '../lib/email.js';
import { startPhoneVerification, checkPhoneVerification } from '../lib/phone.js';
import { audit } from '../lib/audit.js';

const router = Router();
router.use(requireAuth);

router.post('/email/send', async (req,res,next) => {
  try {
    const token = randomToken();
    await query(
      `INSERT INTO email_verification_tokens(user_id,token_hash,expires_at)
       VALUES($1,$2,now()+interval '30 minutes')`,
      [req.user.id, sha256(token)]
    );
    const base = process.env.PUBLIC_APP_URL || 'http://localhost:5173';
    const url = `${base}/verify-email?token=${encodeURIComponent(token)}`;
    await sendEmail({
      to: req.user.email,
      subject: 'Verify your BlueJob email',
      text: `Verify your BlueJob email: ${url}`,
      html: `<p>Verify your BlueJob email:</p><p><a href="${url}">Verify Email</a></p>`
    });
    await audit(req,'EMAIL_VERIFICATION_SENT','user',req.user.id);
    res.json({ok:true});
  } catch(e){ next(e); }
});

router.post('/email/confirm', async (req,res,next) => {
  try {
    const token = String(req.body?.token || '');
    const rec = await query(
      `SELECT * FROM email_verification_tokens
       WHERE user_id=$1 AND token_hash=$2 AND used_at IS NULL AND expires_at>now()
       ORDER BY created_at DESC LIMIT 1`,
      [req.user.id, sha256(token)]
    );
    if(!rec.rows[0]) return res.status(400).json({error:'Verification link is invalid or expired'});
    await tx(async client => {
      await client.query(`UPDATE users SET email_verified_at=now(),updated_at=now() WHERE id=$1`,[req.user.id]);
      await client.query(`UPDATE email_verification_tokens SET used_at=now() WHERE id=$1`,[rec.rows[0].id]);
    });
    await audit(req,'EMAIL_VERIFIED','user',req.user.id);
    res.json({ok:true});
  } catch(e){ next(e); }
});

router.post('/phone/send', async (req,res,next) => {
  try {
    const phone = String(req.body?.phone || '').trim();
    if(!/^\+[1-9]\d{7,14}$/.test(phone)) return res.status(400).json({error:'Phone must be in international E.164 format'});
    await query(`UPDATE users SET phone=$1,phone_verified_at=NULL,updated_at=now() WHERE id=$2`,[phone,req.user.id]);
    await startPhoneVerification(phone);
    await audit(req,'PHONE_VERIFICATION_SENT','user',req.user.id);
    res.json({ok:true});
  } catch(e){ next(e); }
});

router.post('/phone/confirm', async (req,res,next) => {
  try {
    const code = String(req.body?.code || '').trim();
    const u = await query(`SELECT phone FROM users WHERE id=$1`,[req.user.id]);
    if(!u.rows[0]?.phone) return res.status(400).json({error:'No phone number is awaiting verification'});
    const check = await checkPhoneVerification(u.rows[0].phone,code);
    if(check.status !== 'approved') return res.status(400).json({error:'Verification code was not approved'});
    await query(`UPDATE users SET phone_verified_at=now(),updated_at=now() WHERE id=$1`,[req.user.id]);
    await audit(req,'PHONE_VERIFIED','user',req.user.id);
    res.json({ok:true});
  } catch(e){ next(e); }
});

export default router;