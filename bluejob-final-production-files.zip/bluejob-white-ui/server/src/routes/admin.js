import { Router } from 'express';
import { query } from '../lib/db.js';
import { requireAuth, requireRole, requireAdminMfa } from '../lib/auth.js';

const router = Router();
router.use(requireAuth, requireRole('BLUEJOB_ADMIN','SUPER_ADMIN'), requireAdminMfa);

router.get('/overview', async (_req, res, next) => {
  try {
    const result = await query(`
      SELECT
        (SELECT count(*) FROM users)::int AS users,
        (SELECT count(*) FROM organizations)::int AS organizations,
        (SELECT count(*) FROM jobs WHERE status='OPEN')::int AS open_jobs,
        (SELECT count(*) FROM jobs WHERE status='COMPLETED')::int AS completed_jobs,
        (SELECT count(*) FROM evidence WHERE status IN ('PENDING','NEEDS_INFO'))::int AS verification_queue,
        (SELECT count(*) FROM disputes WHERE status IN ('OPEN','UNDER_REVIEW'))::int AS disputes,
        (SELECT count(*) FROM subscriptions WHERE status='ACTIVE')::int AS active_subscriptions
    `);
    res.json({ metrics: result.rows[0] });
  } catch (e) { next(e); }
});

router.get('/users', async (_req, res, next) => {
  try {
    const result = await query(
      `SELECT u.id,u.email,u.username,u.full_name,u.status,u.must_change_password,u.created_at,
       COALESCE(array_agg(ur.role) FILTER (WHERE ur.role IS NOT NULL), '{}') roles,
       (SELECT json_build_object('score',ws.score,'status',ws.status,'modelVersion',ws.model_version)
        FROM work_score_snapshots ws WHERE ws.user_id=u.id ORDER BY ws.calculated_at DESC LIMIT 1) latest_score
       FROM users u LEFT JOIN user_roles ur ON ur.user_id=u.id GROUP BY u.id ORDER BY u.created_at DESC LIMIT 500`
    );
    res.json({ users: result.rows });
  } catch (e) { next(e); }
});

export default router;