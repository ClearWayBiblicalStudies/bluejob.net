import { query } from '../lib/db.js';
import { stripe } from '../lib/billing.js';

function mapStripeStatus(status){
  if(status==='active'||status==='trialing') return status==='trialing'?'TRIAL':'ACTIVE';
  if(status==='past_due'||status==='unpaid') return 'PAST_DUE';
  if(status==='canceled') return 'CANCELED';
  return 'PENDING_PAYMENT';
}

export async function stripeWebhookHandler(req,res){
  let event;
  try{
    event=stripe().webhooks.constructEvent(
      req.body,
      req.headers['stripe-signature'],
      process.env.STRIPE_WEBHOOK_SECRET
    );
  }catch(e){
    return res.status(400).send(`Webhook Error: ${e.message}`);
  }

  const seen=await query(`SELECT 1 FROM billing_events WHERE stripe_event_id=$1`,[event.id]);
  if(seen.rows[0]) return res.json({received:true,duplicate:true});

  try{
    if(event.type==='checkout.session.completed'){
      const s=event.data.object;
      const userId=s.metadata?.bluejobUserId || s.client_reference_id;
      if(userId && s.subscription){
        const sub=await stripe().subscriptions.retrieve(s.subscription);
        await query(
          `INSERT INTO subscriptions(user_id,plan_code,status,price_cents,provider_customer_id,provider_subscription_id,current_period_end,founding_member)
           VALUES($1,'FOUNDING_1599',$2,1599,$3,$4,to_timestamp($5),true)
           ON CONFLICT DO NOTHING`,
          [userId,mapStripeStatus(sub.status),String(s.customer),String(sub.id),sub.current_period_end]
        );
      }
    }

    if(event.type==='customer.subscription.updated' || event.type==='customer.subscription.deleted'){
      const sub=event.data.object;
      await query(
        `UPDATE subscriptions SET status=$1,current_period_end=to_timestamp($2)
         WHERE provider_subscription_id=$3`,
        [mapStripeStatus(sub.status),sub.current_period_end,String(sub.id)]
      );
    }

    if(event.type==='invoice.payment_failed'){
      const invoice=event.data.object;
      if(invoice.subscription) await query(
        `UPDATE subscriptions SET status='PAST_DUE' WHERE provider_subscription_id=$1`,
        [String(invoice.subscription)]
      );
    }

    await query(`INSERT INTO billing_events(stripe_event_id,event_type) VALUES($1,$2)`,[event.id,event.type]);
    res.json({received:true});
  }catch(e){
    console.error(e);
    res.status(500).json({error:'Webhook processing failed'});
  }
}