import { Router } from 'express';
import { requireAuth, requireRole, requireAdminMfa } from '../lib/auth.js';
import { createPrivateUploadUrl, createPrivateDownloadUrl, isS3Mode } from '../lib/storage.js';
import { query } from '../lib/db.js';
import { audit } from '../lib/audit.js';

const router=Router();

router.post('/upload-intent',requireAuth,async(req,res,next)=>{
  try{
    if(!isS3Mode()) return res.status(409).json({error:'Managed object storage is not enabled'});
    const {fileName,mimeType}=req.body||{};
    const allowed=new Set(['application/pdf','image/jpeg','image/png','image/webp']);
    if(!allowed.has(mimeType)) return res.status(400).json({error:'Unsupported file type'});
    const result=await createPrivateUploadUrl({userId:req.user.id,mimeType,fileName});
    await audit(req,'PRIVATE_UPLOAD_INTENT_CREATED','user',req.user.id,{objectKey:result.objectKey});
    res.json(result);
  }catch(e){next(e);}
});

router.post('/finalize',requireAuth,async(req,res,next)=>{
  try{
    const {evidenceId,objectKey,originalName,mimeType,byteSize}=req.body||{};
    const owned=await query(`SELECT 1 FROM evidence WHERE id=$1 AND user_id=$2`,[evidenceId,req.user.id]);
    if(!owned.rows[0]) return res.status(404).json({error:'Evidence record not found'});
    if(!objectKey?.startsWith(`evidence/${req.user.id}/`)) return res.status(400).json({error:'Invalid object key'});
    const r=await query(
      `INSERT INTO private_files(evidence_id,user_id,original_name,mime_type,byte_size,encrypted_path,iv_base64,auth_tag_base64,sha256,storage_provider,object_key,scan_status)
       VALUES($1,$2,$3,$4,$5,'','','','', 'S3',$6,'PENDING') RETURNING id`,
      [evidenceId,req.user.id,originalName,mimeType,Number(byteSize||0),objectKey]
    );
    await audit(req,'PRIVATE_UPLOAD_FINALIZED','private_file',r.rows[0].id,{evidenceId});
    res.json({fileId:r.rows[0].id,scanStatus:'PENDING'});
  }catch(e){next(e);}
});

router.get('/admin/:fileId/url',requireAuth,requireRole('VERIFICATION_REVIEWER','BLUEJOB_ADMIN','SUPER_ADMIN'),requireAdminMfa,async(req,res,next)=>{
  try{
    const r=await query(`SELECT * FROM private_files WHERE id=$1`,[req.params.fileId]);
    const file=r.rows[0];
    if(!file||file.storage_provider!=='S3'||!file.object_key) return res.status(404).json({error:'Managed file not found'});
    if(file.scan_status!=='CLEAN') return res.status(423).json({error:'File is not cleared for review'});
    const url=await createPrivateDownloadUrl(file.object_key);
    await audit(req,'PRIVATE_FILE_SIGNED_URL_CREATED','private_file',file.id,{evidenceId:file.evidence_id});
    res.json({url,expiresIn:180});
  }catch(e){next(e);}
});


router.post('/scan-result', async (req,res,next)=>{
  try{
    const secret=req.headers['x-bluejob-scan-secret'];
    if(!process.env.MALWARE_SCAN_WEBHOOK_SECRET || secret!==process.env.MALWARE_SCAN_WEBHOOK_SECRET){
      return res.status(401).json({error:'Invalid scanner credential'});
    }
    const {fileId,status}=req.body||{};
    if(!['CLEAN','QUARANTINED','FAILED'].includes(status)) return res.status(400).json({error:'Invalid scan status'});
    await query(`UPDATE private_files SET scan_status=$1 WHERE id=$2`,[status,fileId]);
    res.json({ok:true});
  }catch(e){next(e);}
});

export default router;