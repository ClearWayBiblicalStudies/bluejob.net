import { Router } from 'express';
import { tx, query } from '../lib/db.js';
import { requireAuth, requireActiveMembership } from '../lib/auth.js';
import { audit } from '../lib/audit.js';
import { notify } from '../lib/notifications.js';
import { recalculateWorkScore } from '../lib/score.js';
import { recalculateOrganizationScore } from '../lib/contractorScore.js';

const router=Router();
router.use(requireAuth);

async function orgAdmin(userId, organizationId){
  const r=await query(
    `SELECT role FROM organization_memberships WHERE user_id=$1 AND organization_id=$2`,
    [userId,organizationId]
  );
  return ['OWNER','ADMIN'].includes(r.rows[0]?.role);
}

async function finalizeIfReady(client, jobId){
  const state=await client.query(
    `SELECT jc.*,j.organization_id,b.bidder_id
     FROM job_completions jc
     JOIN jobs j ON j.id=jc.job_id
     JOIN bids b ON b.job_id=j.id AND b.status='AWARDED'
     WHERE jc.job_id=$1`,
    [jobId]
  );
  const s=state.rows[0];
  if(!s?.worker_confirmed_at || !s?.contractor_confirmed_at) return null;

  await client.query(
    `UPDATE job_completions SET completed_at=COALESCE(completed_at,now()) WHERE job_id=$1`,
    [jobId]
  );
  await client.query(`UPDATE jobs SET status='COMPLETED',updated_at=now() WHERE id=$1`,[jobId]);

  const workerScore=await recalculateWorkScore(client,s.bidder_id);
  const contractorScore=await recalculateOrganizationScore(client,s.organization_id);

  const owners=await client.query(
    `SELECT user_id FROM organization_memberships WHERE organization_id=$1 AND role IN ('OWNER','ADMIN')`,
    [s.organization_id]
  );
  await notify(client,s.bidder_id,'JOB_COMPLETED','Job verified complete',
    'Your completed BlueJob has been added to your work record.','job',jobId);
  for(const o of owners.rows){
    await notify(client,o.user_id,'JOB_COMPLETED','Project verified complete',
      'The completed project is now part of your organization history.','job',jobId);
  }
  return {workerScore,contractorScore};
}

router.post('/jobs/:id/award',requireActiveMembership,async(req,res,next)=>{
  try{
    const {bidId}=req.body||{};
    const job=await query(`SELECT * FROM jobs WHERE id=$1`,[req.params.id]);
    if(!job.rows[0]) return res.status(404).json({error:'Job not found'});
    if(!(await orgAdmin(req.user.id,job.rows[0].organization_id))) return res.status(403).json({error:'Organization admin access required'});
    if(!['OPEN','MATCHING'].includes(job.rows[0].status)) return res.status(409).json({error:'Job is not awardable in its current state'});

    const result=await tx(async client=>{
      const bid=await client.query(`SELECT * FROM bids WHERE id=$1 AND job_id=$2 FOR UPDATE`,[bidId,req.params.id]);
      if(!bid.rows[0]) return null;
      await client.query(`UPDATE bids SET status=CASE WHEN id=$1 THEN 'AWARDED' ELSE 'DECLINED' END,updated_at=now() WHERE job_id=$2`,[bidId,req.params.id]);
      await client.query(`UPDATE jobs SET status='AWARDED',updated_at=now() WHERE id=$1`,[req.params.id]);
      await client.query(`INSERT INTO job_completions(job_id) VALUES($1) ON CONFLICT(job_id) DO NOTHING`,[req.params.id]);
      await notify(client,bid.rows[0].bidder_id,'BID_AWARDED','You were awarded a BlueJob',
        job.rows[0].title,'job',req.params.id);
      return bid.rows[0];
    });
    if(!result) return res.status(404).json({error:'Bid not found'});
    await audit(req,'JOB_AWARDED','job',req.params.id,{bidId});
    res.json({ok:true,awardedBidId:bidId});
  }catch(e){next(e);}
});

router.post('/jobs/:id/start',requireActiveMembership,async(req,res,next)=>{
  try{
    const job=await query(`SELECT * FROM jobs WHERE id=$1`,[req.params.id]);
    if(!job.rows[0]) return res.status(404).json({error:'Job not found'});
    const awarded=await query(`SELECT bidder_id FROM bids WHERE job_id=$1 AND status='AWARDED'`,[req.params.id]);
    const allowed=awarded.rows[0]?.bidder_id===req.user.id || await orgAdmin(req.user.id,job.rows[0].organization_id);
    if(!allowed) return res.status(403).json({error:'Not authorized for this job'});
    if(!['AWARDED','SCHEDULED'].includes(job.rows[0].status)) return res.status(409).json({error:'Job cannot start from its current state'});
    await query(`UPDATE jobs SET status='IN_PROGRESS',updated_at=now() WHERE id=$1`,[req.params.id]);
    await audit(req,'JOB_STARTED','job',req.params.id);
    res.json({ok:true,status:'IN_PROGRESS'});
  }catch(e){next(e);}
});

router.post('/jobs/:id/complete/contractor',requireActiveMembership,async(req,res,next)=>{
  try{
    const job=await query(`SELECT * FROM jobs WHERE id=$1`,[req.params.id]);
    if(!job.rows[0]) return res.status(404).json({error:'Job not found'});
    if(!(await orgAdmin(req.user.id,job.rows[0].organization_id))) return res.status(403).json({error:'Organization admin access required'});
    const awarded=await query(`SELECT bidder_id FROM bids WHERE job_id=$1 AND status='AWARDED'`,[req.params.id]);
    const workerId=awarded.rows[0]?.bidder_id;
    if(!workerId) return res.status(409).json({error:'No awarded worker exists'});

    const b=req.body||{};
    const result=await tx(async client=>{
      await client.query(
        `UPDATE job_completions SET contractor_confirmed_at=now(),amount_paid_cents=$1,on_time=$2,callback_required=$3 WHERE job_id=$4`,
        [b.amountPaidCents??null,b.onTime??null,b.callbackRequired??null,req.params.id]
      );
      await client.query(
        `INSERT INTO job_feedback(job_id,reviewer_user_id,subject_user_id,reviewer_side,on_time,quality_accepted,callback_required,communication_good,notes)
         VALUES($1,$2,$3,'CONTRACTOR',$4,$5,$6,$7,$8)
         ON CONFLICT(job_id,reviewer_user_id) DO UPDATE SET
           on_time=EXCLUDED.on_time,quality_accepted=EXCLUDED.quality_accepted,
           callback_required=EXCLUDED.callback_required,communication_good=EXCLUDED.communication_good,notes=EXCLUDED.notes`,
        [req.params.id,req.user.id,workerId,b.onTime??null,b.qualityAccepted??null,b.callbackRequired??null,b.communicationGood??null,b.notes||null]
      );
      await notify(client,workerId,'COMPLETION_CONFIRMATION','Contractor confirmed completion',
        'Confirm the completed work to close the BlueJob.','job',req.params.id);
      return finalizeIfReady(client,req.params.id);
    });
    await audit(req,'CONTRACTOR_COMPLETION_CONFIRMED','job',req.params.id);
    res.json({ok:true,finalized:Boolean(result),scores:result});
  }catch(e){next(e);}
});

router.post('/jobs/:id/complete/worker',requireActiveMembership,async(req,res,next)=>{
  try{
    const job=await query(`SELECT * FROM jobs WHERE id=$1`,[req.params.id]);
    if(!job.rows[0]) return res.status(404).json({error:'Job not found'});
    const awarded=await query(`SELECT bidder_id FROM bids WHERE job_id=$1 AND status='AWARDED'`,[req.params.id]);
    if(awarded.rows[0]?.bidder_id!==req.user.id) return res.status(403).json({error:'Only the awarded worker/subcontractor may confirm this side'});
    const b=req.body||{};
    const result=await tx(async client=>{
      await client.query(`UPDATE job_completions SET worker_confirmed_at=now() WHERE job_id=$1`,[req.params.id]);
      await client.query(
        `INSERT INTO job_feedback(job_id,reviewer_user_id,subject_organization_id,reviewer_side,scope_accurate,materials_ready,schedule_organized,payment_as_agreed,communication_good,notes)
         VALUES($1,$2,$3,'WORKER',$4,$5,$6,$7,$8,$9)
         ON CONFLICT(job_id,reviewer_user_id) DO UPDATE SET
           scope_accurate=EXCLUDED.scope_accurate,materials_ready=EXCLUDED.materials_ready,
           schedule_organized=EXCLUDED.schedule_organized,payment_as_agreed=EXCLUDED.payment_as_agreed,
           communication_good=EXCLUDED.communication_good,notes=EXCLUDED.notes`,
        [req.params.id,req.user.id,job.rows[0].organization_id,b.scopeAccurate??null,b.materialsReady??null,b.scheduleOrganized??null,b.paymentAsAgreed??null,b.communicationGood??null,b.notes||null]
      );
      return finalizeIfReady(client,req.params.id);
    });
    await audit(req,'WORKER_COMPLETION_CONFIRMED','job',req.params.id);
    res.json({ok:true,finalized:Boolean(result),scores:result});
  }catch(e){next(e);}
});

router.get('/jobs/:id/market-response',requireActiveMembership,async(req,res,next)=>{
  try{
    const job=await query(`SELECT * FROM jobs WHERE id=$1`,[req.params.id]);
    if(!job.rows[0]) return res.status(404).json({error:'Job not found'});
    if(!(await orgAdmin(req.user.id,job.rows[0].organization_id))) return res.status(403).json({error:'Organization admin access required'});
    const stats=await query(
      `SELECT
        (SELECT count(*)::int FROM job_views WHERE job_id=$1) qualified_viewers,
        (SELECT count(*)::int FROM bids WHERE job_id=$1 AND status<>'WITHDRAWN') bids`,
      [req.params.id]
    );
    const {qualified_viewers,bids}=stats.rows[0];
    const ratio=qualified_viewers ? bids/qualified_viewers : null;
    let signal='INSUFFICIENT_DATA';
    let recommendation='Allow more qualified members to view the opportunity before changing the terms.';
    if(qualified_viewers>=10){
      if(ratio<0.08){signal='LOW';recommendation='Qualified members are viewing the opportunity but rarely bidding. Reevaluate budget, scope, schedule, or requirements.';}
      else if(ratio<0.20){signal='MODERATE';recommendation='Response is developing. Review the budget and requirements if stronger competition is desired.';}
      else {signal='STRONG';recommendation='Qualified members are responding well to the current opportunity terms.';}
    }
    res.json({qualifiedViewers:qualified_viewers,bids,responseRate:ratio,signal,recommendation});
  }catch(e){next(e);}
});

export default router;