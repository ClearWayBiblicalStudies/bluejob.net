import { Router } from 'express';
import { query } from '../lib/db.js';
import { requireAuth, requireActiveMembership, requireVerifiedContact } from '../lib/auth.js';
import { audit } from '../lib/audit.js';

const router = Router();
router.use(requireAuth);

router.get('/organizations', async (req, res, next) => {
  try {
    const result = await query(
      `SELECT o.*,om.role
       FROM organization_memberships om JOIN organizations o ON o.id=om.organization_id
       WHERE om.user_id=$1 ORDER BY o.display_name`,
      [req.user.id]
    );
    res.json({ organizations: result.rows });
  } catch (e) { next(e); }
});

router.post('/jobs', requireVerifiedContact, requireActiveMembership, async (req, res, next) => {
  try {
    const j = req.body || {};
    const membership = await query(
      `SELECT role FROM organization_memberships WHERE organization_id=$1 AND user_id=$2`,
      [j.organizationId, req.user.id]
    );
    if (!membership.rows[0] || !['OWNER','ADMIN'].includes(membership.rows[0].role)) {
      return res.status(403).json({ error: 'Organization admin access required' });
    }
    if (!j.title || !j.description || !j.trade || !j.city || !j.state) {
      return res.status(400).json({ error: 'Title, scope, trade, city, and state are required' });
    }
    const result = await query(
      `INSERT INTO jobs(
        organization_id,created_by,title,description,trade,city,state,budget_min_cents,
        budget_max_cents,max_budget_cents,start_date,duration_days,workers_needed,minimum_work_score,status
      ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) RETURNING *`,
      [
        j.organizationId, req.user.id, j.title, j.description, j.trade, j.city, j.state,
        j.budgetMinCents ?? null, j.budgetMaxCents ?? null, j.maxBudgetCents ?? null,
        j.startDate || null, j.durationDays ?? null, j.workersNeeded ?? null,
        j.minimumWorkScore ?? null, j.publish ? 'OPEN' : 'DRAFT'
      ]
    );
    await audit(req, 'JOB_CREATED', 'job', result.rows[0].id, { status: result.rows[0].status });
    res.status(201).json({ job: result.rows[0] });
  } catch (e) { next(e); }
});

router.get('/jobs', requireVerifiedContact, requireActiveMembership, async (req, res, next) => {
  try {
    const result = await query(
      `SELECT j.*,o.display_name AS organization_name,
        (SELECT count(*)::int FROM bids b WHERE b.job_id=j.id AND b.status <> 'WITHDRAWN') AS bid_count
       FROM jobs j JOIN organizations o ON o.id=j.organization_id
       WHERE j.status='OPEN'
       ORDER BY j.created_at DESC LIMIT 100`
    );
    res.json({ jobs: result.rows });
  } catch (e) { next(e); }
});


router.get('/jobs/:id', requireVerifiedContact, requireActiveMembership, async (req, res, next) => {
  try {
    const result = await query(
      `SELECT j.*,o.display_name AS organization_name,
        (SELECT count(*)::int FROM bids b WHERE b.job_id=j.id AND b.status <> 'WITHDRAWN') AS bid_count
       FROM jobs j JOIN organizations o ON o.id=j.organization_id
       WHERE j.id=$1`,
      [req.params.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Job not found' });

    await query(
      `INSERT INTO job_views(job_id,viewer_user_id)
       VALUES($1,$2)
       ON CONFLICT(job_id,viewer_user_id) DO UPDATE SET
         last_viewed_at=now(),view_count=job_views.view_count+1`,
      [req.params.id, req.user.id]
    );
    res.json({ job: result.rows[0] });
  } catch (e) { next(e); }
});

router.post('/jobs/:id/bids', requireVerifiedContact, requireActiveMembership, async (req, res, next) => {
  try {
    const b = req.body || {};
    if (!Number.isInteger(Number(b.amountCents)) || Number(b.amountCents) <= 0) {
      return res.status(400).json({ error: 'A valid bid amount is required' });
    }
    const job = await query(`SELECT id,status FROM jobs WHERE id=$1`, [req.params.id]);
    if (!job.rows[0] || job.rows[0].status !== 'OPEN') return res.status(400).json({ error: 'Job is not accepting bids' });

    const result = await query(
      `INSERT INTO bids(job_id,bidder_id,amount_cents,proposed_start_date,estimated_days,message)
       VALUES($1,$2,$3,$4,$5,$6)
       ON CONFLICT(job_id,bidder_id) DO UPDATE SET
         amount_cents=EXCLUDED.amount_cents,proposed_start_date=EXCLUDED.proposed_start_date,
         estimated_days=EXCLUDED.estimated_days,message=EXCLUDED.message,status='SUBMITTED',updated_at=now()
       RETURNING *`,
      [req.params.id, req.user.id, Number(b.amountCents), b.proposedStartDate || null, b.estimatedDays ?? null, b.message || null]
    );
    await audit(req, 'BID_SUBMITTED', 'bid', result.rows[0].id, { jobId: req.params.id });
    res.status(201).json({ bid: result.rows[0] });
  } catch (e) { next(e); }
});

router.get('/jobs/:id/competition', requireVerifiedContact, requireActiveMembership, async (req, res, next) => {
  try {
    const counts = await query(
      `SELECT
         count(*) FILTER (WHERE status <> 'WITHDRAWN')::int AS total_bids,
         count(*) FILTER (
           WHERE bidder_id IN (SELECT user_id FROM work_score_snapshots WHERE status='ACTIVE' AND score >= 800)
           AND status <> 'WITHDRAWN'
         )::int AS score_800_plus
       FROM bids WHERE job_id=$1`,
      [req.params.id]
    );
    res.json({
      competition: counts.rows[0],
      privacy: { competitorNamesVisible: false, competitorBidAmountsVisible: false }
    });
  } catch (e) { next(e); }
});

export default router;