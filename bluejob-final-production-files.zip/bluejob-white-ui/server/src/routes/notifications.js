import { Router } from 'express';
import { query } from '../lib/db.js';
import { requireAuth } from '../lib/auth.js';

const router=Router();
router.use(requireAuth);

router.get('/',async(req,res,next)=>{
  try{
    const r=await query(`SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100`,[req.user.id]);
    res.json({notifications:r.rows});
  }catch(e){next(e);}
});

router.post('/:id/read',async(req,res,next)=>{
  try{
    await query(`UPDATE notifications SET read_at=now() WHERE id=$1 AND user_id=$2`,[req.params.id,req.user.id]);
    res.json({ok:true});
  }catch(e){next(e);}
});

export default router;