import { Router } from 'express';
import { query, tx } from '../lib/db.js';
import { hashPassword, verifyPassword, randomToken, sha256 } from '../lib/security.js';
import { createSession, destroySession, requireAuth, readSession } from '../lib/auth.js';
import { audit } from '../lib/audit.js';
import { sendEmail } from '../lib/email.js';

const router = Router();

function cleanUser(user) {
  return {
    id: user.id,
    email: user.email,
    username: user.username,
    fullName: user.full_name,
    roles: user.roles || [],
    mustChangePassword: user.must_change_password,
    onboardingPath: user.onboarding_path,
    emailVerified: Boolean(user.email_verified_at),
    phone: user.phone || null,
    phoneVerified: Boolean(user.phone_verified_at),
    mfaEnabled: Boolean(user.mfa_enabled),
    mfaVerified: Boolean(user.mfa_verified_at)
  };
}

router.post('/signup', async (req, res, next) => {
  try {
    const { fullName, email, password, username = null } = req.body || {};
    if (!fullName || !email || !password) return res.status(400).json({ error: 'Full name, email, and password are required' });
    const normalizedEmail = String(email).trim().toLowerCase();
    const passwordHash = await hashPassword(password);

    const user = await tx(async client => {
      const created = await client.query(
        `INSERT INTO users(email,username,full_name,password_hash)
         VALUES($1,$2,$3,$4) RETURNING *`,
        [normalizedEmail, username?.trim() || null, fullName.trim(), passwordHash]
      );
      await client.query(`INSERT INTO user_roles(user_id,role) VALUES($1,'USER')`, [created.rows[0].id]);
      await client.query(`INSERT INTO work_passports(user_id,display_name) VALUES($1,$2)`, [created.rows[0].id, fullName.trim()]);
      return created.rows[0];
    });

    await createSession(user.id, req, res);
    const sessionUser = await readSession(req); // cookie isn't on current req, so build response directly
    await audit({ ...req, user }, 'AUTH_SIGNUP', 'user', user.id);
    res.status(201).json({
      user: {
        id: user.id, email: user.email, username: user.username, fullName: user.full_name,
        roles: ['USER'], mustChangePassword: false, onboardingPath: null, emailVerified: false
      }
    });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'An account with that email or username already exists' });
    next(e);
  }
});

router.post('/signin', async (req, res, next) => {
  try {
    const { identifier, password } = req.body || {};
    const result = await query(
      `SELECT * FROM users WHERE lower(email)=lower($1) OR lower(username)=lower($1) LIMIT 1`,
      [String(identifier || '').trim()]
    );
    const user = result.rows[0];
    if (!user || !(await verifyPassword(password || '', user.password_hash))) {
      return res.status(401).json({ error: 'Invalid sign-in credentials' });
    }
    if (user.status !== 'ACTIVE') return res.status(403).json({ error: 'Account is not active' });

    await createSession(user.id, req, res);
    const roles = await query(`SELECT role FROM user_roles WHERE user_id=$1`, [user.id]);
    const mfa = await query(`SELECT enabled_at FROM admin_mfa WHERE user_id=$1`, [user.id]);
    req.user = user;
    await audit(req, 'AUTH_SIGNIN', 'user', user.id);
    res.json({
      user: {
        id: user.id, email: user.email, username: user.username, fullName: user.full_name,
        roles: roles.rows.map(r => r.role), mustChangePassword: user.must_change_password,
        onboardingPath: user.onboarding_path, emailVerified: Boolean(user.email_verified_at),
        phone: user.phone || null, phoneVerified: Boolean(user.phone_verified_at),
        mfaEnabled: Boolean(mfa.rows[0]?.enabled_at), mfaVerified: false
      }
    });
  } catch (e) { next(e); }
});

router.post('/signout', async (req, res, next) => {
  try {
    const user = await readSession(req);
    if (user) req.user = user;
    await destroySession(req, res);
    if (user) await audit(req, 'AUTH_SIGNOUT', 'user', user.id);
    res.status(204).end();
  } catch (e) { next(e); }
});

router.get('/me', requireAuth, async (req, res) => {
  res.json({ user: cleanUser(req.user) });
});

router.post('/change-password', requireAuth, async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body || {};
    const current = await query(`SELECT password_hash FROM users WHERE id=$1`, [req.user.id]);
    if (!(await verifyPassword(currentPassword || '', current.rows[0].password_hash))) {
      return res.status(400).json({ error: 'Current password is incorrect' });
    }
    const passwordHash = await hashPassword(newPassword);
    await tx(async client => {
      await client.query(`UPDATE users SET password_hash=$1,must_change_password=false,updated_at=now() WHERE id=$2`, [passwordHash, req.user.id]);
      await client.query(`UPDATE sessions SET revoked_at=now() WHERE user_id=$1`, [req.user.id]);
    });
    await destroySession(req, res);
    await audit(req, 'PASSWORD_CHANGED', 'user', req.user.id);
    res.json({ ok: true, signInAgain: true });
  } catch (e) { next(e); }
});

router.post('/onboarding-path', requireAuth, async (req, res, next) => {
  try {
    const path = req.body?.path;
    if (!['WORKER','CONTRACTOR'].includes(path)) return res.status(400).json({ error: 'Invalid onboarding path' });
    await query(`UPDATE users SET onboarding_path=$1,updated_at=now() WHERE id=$2`, [path, req.user.id]);
    const role = path === 'WORKER' ? 'WORKER' : 'CONTRACTOR';
    await query(`INSERT INTO user_roles(user_id,role) VALUES($1,$2) ON CONFLICT DO NOTHING`, [req.user.id, role]);
    await audit(req, 'ONBOARDING_PATH_SET', 'user', req.user.id, { path });
    res.json({ ok: true, path });
  } catch (e) { next(e); }
});

router.post('/request-password-reset', async (req, res, next) => {
  try {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const user = await query(`SELECT id,email FROM users WHERE lower(email)=lower($1)`, [email]);
    if (user.rows[0]) {
      const token = randomToken();
      await query(
        `INSERT INTO password_reset_tokens(user_id,token_hash,expires_at) VALUES($1,$2,now()+interval '30 minutes')`,
        [user.rows[0].id, sha256(token)]
      );
      const base = process.env.PUBLIC_APP_URL || 'http://localhost:5173';
      const url = `${base}/reset-password?token=${encodeURIComponent(token)}`;
      await sendEmail({
        to: email,
        subject: 'Reset your BlueJob password',
        text: `Reset your BlueJob password: ${url}`,
        html: `<p>Reset your BlueJob password:</p><p><a href="${url}">Reset Password</a></p>`
      });
    }
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.post('/reset-password', async (req, res, next) => {
  try {
    const { token, newPassword } = req.body || {};
    const record = await query(
      `SELECT * FROM password_reset_tokens
       WHERE token_hash=$1 AND used_at IS NULL AND expires_at > now()`,
      [sha256(token || '')]
    );
    if (!record.rows[0]) return res.status(400).json({ error: 'Reset token is invalid or expired' });

    const passwordHash = await hashPassword(newPassword);
    await tx(async client => {
      await client.query(`UPDATE users SET password_hash=$1,must_change_password=false,updated_at=now() WHERE id=$2`, [passwordHash, record.rows[0].user_id]);
      await client.query(`UPDATE password_reset_tokens SET used_at=now() WHERE id=$1`, [record.rows[0].id]);
      await client.query(`UPDATE sessions SET revoked_at=now() WHERE user_id=$1`, [record.rows[0].user_id]);
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default router;