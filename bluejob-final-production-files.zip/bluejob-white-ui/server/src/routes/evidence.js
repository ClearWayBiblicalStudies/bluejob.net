import { Router } from 'express';
import multer from 'multer';
import fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { query, tx } from '../lib/db.js';
import { requireAuth, requireRole, requireAdminMfa } from '../lib/auth.js';
import { encryptBuffer, decryptBuffer } from '../lib/security.js';
import { audit } from '../lib/audit.js';
import { recalculateWorkScore } from '../lib/score.js';
import { isS3Mode, putPrivateObject, createPrivateDownloadUrl } from '../lib/storage.js';

const router = Router();
const maxBytes = 10 * 1024 * 1024;
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: maxBytes },
  fileFilter: (_req, file, cb) => {
    const allowed = new Set([
      'application/pdf','image/jpeg','image/png','image/webp'
    ]);
    cb(allowed.has(file.mimetype) ? null : new Error('Unsupported document type'), allowed.has(file.mimetype));
  }
});

router.get('/', requireAuth, async (req, res, next) => {
  try {
    const result = await query(
      `SELECT e.*, pf.id AS file_id, pf.original_name, pf.mime_type, pf.byte_size
       FROM evidence e LEFT JOIN private_files pf ON pf.evidence_id=e.id
       WHERE e.user_id=$1 ORDER BY e.created_at DESC`,
      [req.user.id]
    );
    res.json({ evidence: result.rows });
  } catch (e) { next(e); }
});

router.post('/', requireAuth, upload.single('file'), async (req, res, next) => {
  try {
    const { type, title, organization, trade, notes, workHistoryId } = req.body;
    if (!type || !title) return res.status(400).json({ error: 'Evidence type and title are required' });

    const result = await tx(async client => {
      const evidence = await client.query(
        `INSERT INTO evidence(user_id,work_history_id,type,title,organization,trade,notes)
         VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
        [req.user.id, workHistoryId || null, type, title, organization || null, trade || null, notes || null]
      );

      if (req.file) {
        if (isS3Mode()) {
          const stored = await putPrivateObject({
            userId: req.user.id,
            buffer: req.file.buffer,
            mimeType: req.file.mimetype,
            fileName: req.file.originalname
          });
          await client.query(
            `INSERT INTO private_files(
              evidence_id,user_id,original_name,mime_type,byte_size,encrypted_path,
              iv_base64,auth_tag_base64,sha256,storage_provider,object_key,scan_status
            ) VALUES($1,$2,$3,$4,$5,'','','','', 'S3',$6,'PENDING')`,
            [evidence.rows[0].id, req.user.id, req.file.originalname, req.file.mimetype, req.file.size, stored.objectKey]
          );
        } else {
          const encrypted = encryptBuffer(req.file.buffer);
          const dir = path.resolve(process.env.PRIVATE_UPLOAD_DIR || './private_uploads');
          await fs.mkdir(dir, { recursive: true, mode: 0o700 });
          const fileName = `${randomUUID()}.enc`;
          const fullPath = path.join(dir, fileName);
          await fs.writeFile(fullPath, encrypted.encrypted, { mode: 0o600 });

          await client.query(
            `INSERT INTO private_files(
              evidence_id,user_id,original_name,mime_type,byte_size,encrypted_path,
              iv_base64,auth_tag_base64,sha256,storage_provider,scan_status
            ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,'LOCAL',$10)`,
            [
              evidence.rows[0].id, req.user.id, req.file.originalname, req.file.mimetype,
              req.file.size, fullPath, encrypted.ivBase64, encrypted.authTagBase64, encrypted.sha256,
              process.env.NODE_ENV === 'production' ? 'PENDING' : 'CLEAN'
            ]
          );
        }
      }
      return evidence.rows[0];
    });

    await audit(req, 'EVIDENCE_SUBMITTED', 'evidence', result.id, { type });
    res.status(201).json({ evidence: result });
  } catch (e) { next(e); }
});

router.get('/admin/queue', requireAuth, requireRole('VERIFICATION_REVIEWER','BLUEJOB_ADMIN','SUPER_ADMIN'), requireAdminMfa, async (_req, res, next) => {
  try {
    const result = await query(
      `SELECT e.*,u.full_name,u.email,pf.id AS file_id,pf.original_name,pf.mime_type,pf.byte_size
       FROM evidence e
       JOIN users u ON u.id=e.user_id
       LEFT JOIN private_files pf ON pf.evidence_id=e.id
       WHERE e.status IN ('PENDING','NEEDS_INFO')
       ORDER BY e.created_at ASC`
    );
    res.json({ evidence: result.rows });
  } catch (e) { next(e); }
});

router.post('/admin/:id/review', requireAuth, requireRole('VERIFICATION_REVIEWER','BLUEJOB_ADMIN','SUPER_ADMIN'), requireAdminMfa, async (req, res, next) => {
  try {
    const { status, reviewerNotes } = req.body || {};
    if (!['VERIFIED','REJECTED','NEEDS_INFO'].includes(status)) {
      return res.status(400).json({ error: 'Invalid review status' });
    }

    const result = await tx(async client => {
      const updated = await client.query(
        `UPDATE evidence SET status=$1,reviewer_id=$2,reviewer_notes=$3,reviewed_at=now()
         WHERE id=$4 RETURNING *`,
        [status, req.user.id, reviewerNotes || null, req.params.id]
      );
      if (!updated.rows[0]) return null;

      if (updated.rows[0].work_history_id) {
        await client.query(
          `UPDATE work_history SET verification_status=$1 WHERE id=$2`,
          [status === 'VERIFIED' ? 'VERIFIED' : status === 'REJECTED' ? 'REJECTED' : 'PENDING', updated.rows[0].work_history_id]
        );
      }
      const score = await recalculateWorkScore(client, updated.rows[0].user_id);
      return { evidence: updated.rows[0], score };
    });
    if (!result) return res.status(404).json({ error: 'Evidence not found' });
    await audit(req, 'EVIDENCE_REVIEWED', 'evidence', req.params.id, { status });
    res.json(result);
  } catch (e) { next(e); }
});

router.get('/admin/file/:fileId', requireAuth, requireRole('VERIFICATION_REVIEWER','BLUEJOB_ADMIN','SUPER_ADMIN'), requireAdminMfa, async (req, res, next) => {
  try {
    const record = await query(`SELECT * FROM private_files WHERE id=$1`, [req.params.fileId]);
    const file = record.rows[0];
    if (!file) return res.status(404).json({ error: 'File not found' });
    if (file.scan_status !== 'CLEAN') return res.status(423).json({ error: 'File is not cleared for review' });
    await audit(req, 'PRIVATE_FILE_VIEWED', 'private_file', file.id, { evidenceId: file.evidence_id });
    if (file.storage_provider === 'S3') {
      const url = await createPrivateDownloadUrl(file.object_key);
      return res.redirect(302, url);
    }
    const encrypted = await fs.readFile(file.encrypted_path);
    const decrypted = decryptBuffer(encrypted, file.iv_base64, file.auth_tag_base64);
    res.setHeader('Content-Type', file.mime_type);
    res.setHeader('Content-Disposition', `inline; filename*=UTF-8''${encodeURIComponent(file.original_name)}`);
    res.send(decrypted);
  } catch (e) { next(e); }
});

export default router;