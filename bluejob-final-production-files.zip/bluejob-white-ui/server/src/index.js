import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import authRoutes from './routes/auth.js';
import passportRoutes from './routes/passport.js';
import evidenceRoutes from './routes/evidence.js';
import marketplaceRoutes from './routes/marketplace.js';
import lifecycleRoutes from './routes/lifecycle.js';
import adminRoutes from './routes/admin.js';
import identityRoutes from './routes/identity.js';
import mfaRoutes from './routes/mfa.js';
import billingRoutes from './routes/billing.js';
import storageRoutes from './routes/storage.js';
import notificationRoutes from './routes/notifications.js';
import { stripeWebhookHandler } from './routes/stripeWebhook.js';
import { validateEnvironment } from './lib/env.js';
import { readiness } from './lib/readiness.js';

validateEnvironment();

const app = express();
app.set('trust proxy', 1);

app.use(helmet({ crossOriginResourcePolicy: { policy: 'same-site' } }));
app.use(cors({
  origin: process.env.APP_ORIGIN || 'http://localhost:5173',
  credentials: true,
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS']
}));

// Stripe signature verification requires the untouched raw request body.
app.post('/api/billing/webhook', express.raw({ type: 'application/json' }), stripeWebhookHandler);

app.use(express.json({ limit: '1mb' }));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: 'draft-8',
  legacyHeaders: false
});
const sensitiveLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 20,
  standardHeaders: 'draft-8',
  legacyHeaders: false
});

app.use(['/api/auth/signin','/api/auth/signup','/api/auth/request-password-reset'], authLimiter);
app.use(['/api/identity','/api/mfa'], sensitiveLimiter);



app.use((req, res, next) => {
  if (['GET','HEAD','OPTIONS'].includes(req.method)) return next();
  const origin = req.headers.origin;
  const allowed = process.env.APP_ORIGIN;
  if (allowed && origin && origin !== allowed) {
    return res.status(403).json({ error: 'Origin not allowed' });
  }
  next();
});

app.get('/api/healthz', (_req, res) => res.json({ ok: true, service: 'bluejob-api' }));
app.get('/api/readyz', async (_req, res) => {
  try {
    res.json(await readiness());
  } catch (error) {
    res.status(503).json({ ok: false, database: 'unavailable' });
  }
});
app.use('/api/auth', authRoutes);
app.use('/api/identity', identityRoutes);
app.use('/api/mfa', mfaRoutes);
app.use('/api/billing', billingRoutes);
app.use('/api/passport', passportRoutes);
app.use('/api/evidence', evidenceRoutes);
app.use('/api/storage', storageRoutes);
app.use('/api/marketplace', marketplaceRoutes);
app.use('/api/marketplace', lifecycleRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/admin', adminRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  const message = process.env.NODE_ENV === 'production' ? 'Request failed' : err.message;
  res.status(err.status || 500).json({ error: message });
});

const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`BlueJob API listening on :${port}`));