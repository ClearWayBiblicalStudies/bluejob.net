# Security Policy

Never commit:

- passwords
- session tokens
- Stripe secret keys
- Twilio secrets
- Resend API keys
- AWS credentials
- database credentials
- encryption keys
- uploaded verification evidence

Report suspected security problems privately to the BlueJob operator.

Work Score manipulation, unauthorized verification access, access-control bypasses, document exposure, billing bypasses, and account takeover issues are considered high priority.