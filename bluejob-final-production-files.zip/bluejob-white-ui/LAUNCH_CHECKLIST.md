# BlueJob Launch Checklist

## Required service configuration
- [ ] Production PostgreSQL provisioned with automated backups
- [ ] `server/.env` values stored in a secrets manager, not Git
- [ ] Resend domain verified and production API key configured
- [ ] Twilio Verify Service created and production API key configured
- [ ] Stripe product/recurring price created for the $15.99 Founding Membership
- [ ] Stripe webhook endpoint configured and signing secret stored
- [ ] Private S3 bucket created with public access blocked
- [ ] KMS key configured for private evidence objects
- [ ] Malware scanning pipeline connected to `POST /api/storage/scan-result`
- [ ] `APP_ENCRYPTION_KEY` and `FILE_ENCRYPTION_KEY` generated and backed up securely

## Account/security
- [ ] Founder account seeded using environment variables only
- [ ] Founder temporary password changed on first sign-in
- [ ] Founder/Admin MFA enabled
- [ ] Email verification tested end-to-end
- [ ] SMS verification tested end-to-end
- [ ] Password reset tested
- [ ] Session revocation tested
- [ ] Admin endpoints reject non-admin users
- [ ] Admin endpoints reject admins without MFA
- [ ] Private evidence access creates audit events
- [ ] Rate limits verified at the edge and application layer

## Billing
- [ ] Stripe Checkout tested in sandbox
- [ ] `checkout.session.completed` tested
- [ ] subscription update/cancellation tested
- [ ] failed payment handling tested
- [ ] Billing Portal enabled
- [ ] Founding Membership displays $15.99/month
- [ ] Membership status never changes Work Score

## Marketplace
- [ ] Contractor can post a real job
- [ ] Subcontractor can view and bid
- [ ] Bid counts are visible without competitor bid prices
- [ ] Contractor can award one bid
- [ ] Awarded worker can start the job
- [ ] Contractor completion confirmation works
- [ ] Worker completion confirmation works
- [ ] Both confirmations close the job
- [ ] Worker Work Score recalculates
- [ ] Contractor Work Score recalculates
- [ ] Notifications are created
- [ ] Dispute path prevents false clean completion

## Verification
- [ ] Work history starts Claimed/Self Reported
- [ ] Evidence upload is private
- [ ] Uploaded objects remain unavailable until malware scan status is CLEAN
- [ ] Verification reviewer can Verify / Reject / Need Info
- [ ] Reviewer identity and timestamp persist
- [ ] Work Score remains BUILDING until evidence threshold is reached

## Release
- [ ] `npm run build` passes
- [ ] backend tests pass
- [ ] CodeQL passes
- [ ] secret scan passes
- [ ] database migrations tested on clean database
- [ ] database restore drill completed
- [ ] production error monitoring configured
- [ ] uptime/health monitoring configured
- [ ] Privacy Policy published
- [ ] Terms of Service published
- [ ] Work Score explanation / dispute policy published
- [ ] verification document retention policy published
- [ ] first real Chrome Construction / Gulfside Improvements jobs reviewed before publishing