import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';

export default function VerifyEmailPage(){
  const [params]=useSearchParams(); const navigate=useNavigate(); const {refresh}=useAuth();
  const [state,setState]=useState('Verifying your email…');
  useEffect(()=>{
    const token=params.get('token');
    if(!token){setState('Verification token is missing.');return;}
    api('/identity/email/confirm',{method:'POST',body:{token}})
      .then(async()=>{await refresh();setState('Email verified.');setTimeout(()=>navigate('/verify-account',{replace:true}),700);})
      .catch(e=>setState(e.message));
  },[]);
  return <div className="auth-page"><div className="auth-top"><Logo/></div><div className="auth-card white-card"><h1>Email Verification</h1><p>{state}</p></div></div>
}