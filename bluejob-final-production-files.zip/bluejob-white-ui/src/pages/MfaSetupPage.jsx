import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';

export default function MfaSetupPage(){
  const navigate=useNavigate(); const {refresh}=useAuth();
  const [setup,setSetup]=useState(null); const [code,setCode]=useState(''); const [recovery,setRecovery]=useState([]); const [error,setError]=useState('');
  async function begin(){try{setSetup(await api('/mfa/setup',{method:'POST'}));}catch(e){setError(e.message)}}
  async function enable(){try{const d=await api('/mfa/enable',{method:'POST',body:{code}});setRecovery(d.recoveryCodes||[]);await refresh();}catch(e){setError(e.message)}}
  return <div className="auth-page"><div className="auth-top"><Logo/></div><div className="auth-card white-card">
    <span className="kicker">ADMIN SECURITY</span><h1>Protect BlueJob Administration.</h1><p>Super Admin and verification access requires an authenticator app.</p>
    {error&&<div className="form-error">{error}</div>}
    {!setup&&!recovery.length&&<button className="button button-primary button-full" onClick={begin}>Set Up Authenticator</button>}
    {setup&&!recovery.length&&<>
      <img className="mfa-qr" src={setup.qrDataUrl} alt="Authenticator QR code"/>
      <small>Manual key: {setup.manualSecret}</small>
      <label>6-digit code<input value={code} onChange={e=>setCode(e.target.value)} inputMode="numeric"/></label>
      <button className="button button-primary button-full" onClick={enable}>Enable MFA</button>
    </>}
    {recovery.length>0&&<>
      <div className="form-success">MFA enabled. Store these recovery codes securely.</div>
      <div className="recovery-grid">{recovery.map(c=><code key={c}>{c}</code>)}</div>
      <button className="button button-primary button-full" onClick={()=>navigate('/admin')}>Open BlueJob Administration</button>
    </>}
  </div></div>
}