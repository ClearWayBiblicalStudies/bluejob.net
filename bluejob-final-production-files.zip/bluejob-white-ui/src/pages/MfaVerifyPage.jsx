import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';

export default function MfaVerifyPage(){
  const [code,setCode]=useState(''); const [error,setError]=useState(''); const navigate=useNavigate(); const {refresh}=useAuth();
  async function submit(e){e.preventDefault();try{await api('/mfa/verify',{method:'POST',body:{code}});await refresh();navigate('/admin',{replace:true});}catch(e){setError(e.message)}}
  return <div className="auth-page"><div className="auth-top"><Logo/></div><div className="auth-card white-card">
    <span className="kicker">ADMIN SECURITY</span><h1>Enter your authenticator code.</h1>
    {error&&<div className="form-error">{error}</div>}
    <form onSubmit={submit}><label>Authenticator or recovery code<input value={code} onChange={e=>setCode(e.target.value)} inputMode="numeric" autoFocus/></label><button className="button button-primary button-full">Verify</button></form>
  </div></div>
}