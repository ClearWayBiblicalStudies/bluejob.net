import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import Logo from '../components/Logo';
import { useAuth } from '../context/AuthContext';

export default function SignInPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { signIn } = useAuth();
  const [form, setForm] = useState({ identifier: '', password: '' });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError('');
    setSaving(true);
    try {
      const user = await signIn(form.identifier, form.password);
      if (user.mustChangePassword) return navigate('/change-password');
      const isAdmin = user.roles?.includes('SUPER_ADMIN') || user.roles?.includes('BLUEJOB_ADMIN') || user.roles?.includes('VERIFICATION_REVIEWER');
      if (isAdmin && !user.mfaEnabled) return navigate('/mfa/setup');
      if (isAdmin && !user.mfaVerified) return navigate('/mfa');
      if (!user.emailVerified || !user.phoneVerified) return navigate('/verify-account');
      if (!user.onboardingPath) return navigate('/choose-path');
      return navigate('/membership');
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-top"><Logo /><span>New to BlueJob? <Link to="/signup">Create account</Link></span></div>
      <div className="auth-card white-card">
        <h1>Welcome Back</h1>
        <p>Sign in to continue to BlueJob.</p>
        {location.state?.passwordChanged && <div className="form-success">Password updated. Sign in with your new password.</div>}
        {error && <div className="form-error">{error}</div>}
        <form onSubmit={submit}>
          <label>Email or username<input value={form.identifier} onChange={e => setForm(f => ({...f,identifier:e.target.value}))} autoComplete="username" required /></label>
          <label>Password<input type="password" value={form.password} onChange={e => setForm(f => ({...f,password:e.target.value}))} autoComplete="current-password" required /></label>
          <div className="form-inline"><span/><Link to="/forgot-password">Forgot password?</Link></div>
          <button className="button button-primary button-full button-lg" disabled={saving}>{saving ? 'Signing in…' : 'Sign In'}</button>
        </form>
      </div>
    </div>
  );
}