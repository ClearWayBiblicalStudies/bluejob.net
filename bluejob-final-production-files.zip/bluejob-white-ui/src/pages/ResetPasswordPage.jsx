import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';

export default function ResetPasswordPage(){
  const [params]=useSearchParams();const navigate=useNavigate();const [password,setPassword]=useState('');const [error,setError]=useState('');
  async function submit(e){e.preventDefault();try{await api('/auth/reset-password',{method:'POST',body:{token:params.get('token'),newPassword:password}});navigate('/signin',{replace:true});}catch(e){setError(e.message)}}
  return <div className="auth-page"><div className="auth-top"><Logo/></div><div className="auth-card white-card"><h1>Create a new password</h1>{error&&<div className="form-error">{error}</div>}<form onSubmit={submit}><label>New password<input type="password" minLength="12" value={password} onChange={e=>setPassword(e.target.value)} required/></label><button className="button button-primary button-full">Reset Password</button></form></div></div>
}