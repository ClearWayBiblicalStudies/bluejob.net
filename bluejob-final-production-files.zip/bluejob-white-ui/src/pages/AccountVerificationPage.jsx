import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';

export default function AccountVerificationPage(){
  const navigate=useNavigate();
  const {user,refresh}=useAuth();
  const [phone,setPhone]=useState(user?.phone||'');
  const [code,setCode]=useState('');
  const [message,setMessage]=useState('');

  async function sendEmail(){
    setMessage(''); await api('/identity/email/send',{method:'POST'}); setMessage('Verification email sent.');
  }
  async function sendPhone(){
    setMessage(''); await api('/identity/phone/send',{method:'POST',body:{phone}}); setMessage('Verification code sent.');
  }
  async function confirmPhone(){
    setMessage(''); await api('/identity/phone/confirm',{method:'POST',body:{code}}); await refresh(); setMessage('Phone verified.');
  }

  const ready=user?.emailVerified && user?.phoneVerified;
  return <div className="auth-page">
    <div className="auth-top"><Logo/></div>
    <div className="auth-card white-card verification-card">
      <span className="kicker">ACCOUNT VERIFICATION</span>
      <h1>Verify how BlueJob can reach you.</h1>
      <p>Verified contact information protects your account and supports a more credible work network.</p>
      {message&&<div className="form-success">{message}</div>}
      <div className="verify-block">
        <div><strong>Email</strong><span>{user?.email}</span></div>
        {user?.emailVerified?<span className="status-badge status-green">Verified</span>:<button className="button button-outline" onClick={sendEmail}>Send Verification</button>}
      </div>
      <div className="verify-block verify-block-stack">
        <div><strong>Mobile phone</strong><span>Use international format, for example +1...</span></div>
        {user?.phoneVerified?<span className="status-badge status-green">Verified</span>:<>
          <input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="+1 555 555 5555"/>
          <button className="button button-outline" onClick={sendPhone}>Send Code</button>
          <div className="inline-code"><input value={code} onChange={e=>setCode(e.target.value)} placeholder="Verification code"/><button className="button button-primary" onClick={confirmPhone}>Verify Phone</button></div>
        </>}
      </div>
      <button className="button button-primary button-full button-lg" disabled={!ready} onClick={()=>navigate('/choose-path')}>Continue to BlueJob Setup</button>
    </div>
  </div>
}