import { ArrowRight, Building2, HardHat } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';

export default function ChoosePathPage() {
  const navigate = useNavigate();
  const { refresh } = useAuth();

  async function choose(path) {
    await api('/auth/onboarding-path', { method: 'POST', body: { path } });
    await refresh();
    navigate('/membership');
  }

  return (
    <div className="choose-page">
      <header><Logo /></header>
      <section className="choose-content">
        <span className="kicker">ACCOUNT SETUP</span>
        <h1>How will you use BlueJob?</h1>
        <p>Choose where you want to begin. Additional workspaces can be added later.</p>
        <div className="choice-grid">
          <button onClick={() => choose('WORKER')} className="choice-card choice-card-blue">
            <HardHat size={48}/><h2>I Need Work</h2><strong>Subcontractor / Skilled Professional / Crew</strong>
            <p>Build your Work Passport, verify your history, strengthen your Work Score, and get matched with better opportunities.</p><ArrowRight/>
          </button>
          <button onClick={() => choose('CONTRACTOR')} className="choice-card choice-card-green">
            <Building2 size={48}/><h2>I Need Work Done</h2><strong>Contractor / GC / Company</strong>
            <p>Build your company workspace, post work, grow your subcontractor network, and manage projects from one place.</p><ArrowRight/>
          </button>
        </div>
      </section>
    </div>
  );
}