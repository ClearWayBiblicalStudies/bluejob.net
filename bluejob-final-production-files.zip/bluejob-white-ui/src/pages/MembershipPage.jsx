import { useEffect, useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import Logo from '../components/Logo';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';

export default function MembershipPage(){
  const {user}=useAuth(); const [subscription,setSubscription]=useState(null); const [error,setError]=useState('');
  useEffect(()=>{api('/billing/status').then(d=>setSubscription(d.subscription)).catch(e=>setError(e.message));},[]);
  const active=['ACTIVE','TRIAL'].includes(subscription?.status);

  async function checkout(){
    try{const d=await api('/billing/checkout',{method:'POST'}); window.location.assign(d.url);}
    catch(e){setError(e.message);}
  }
  function continueSetup(){
    window.location.assign(user?.onboardingPath==='CONTRACTOR'?'/app/contractor':'/app/passport/edit');
  }

  return <div className="membership-page">
    <header><Logo/></header>
    <section className="membership-card card">
      <span className="kicker">BLUEJOB FOUNDING MEMBERSHIP</span>
      <h1>Build your reputation. Access the network.</h1>
      <div className="membership-price"><strong>$15.99</strong><span>/month</span></div>
      <p>Founding membership activates BlueJob marketplace access while the platform grows.</p>
      <div className="membership-benefits">
        <span><CheckCircle2/> Work Passport & Work Score</span>
        <span><CheckCircle2/> Job and subcontractor network access</span>
        <span><CheckCircle2/> Bidding, matching, and verified work history</span>
        <span><CheckCircle2/> Founding Member designation</span>
      </div>
      {error&&<div className="form-error">{error}</div>}
      {active?<button className="button button-primary button-full button-lg" onClick={continueSetup}>Continue Setup</button>:
        <button className="button button-primary button-full button-lg" onClick={checkout}>Activate Membership — $15.99/mo</button>}
      <small>Work Score is never increased by membership status or payment.</small>
    </section>
  </div>
}