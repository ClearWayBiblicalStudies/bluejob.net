import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';

export default function MembershipSuccessPage(){
  const navigate=useNavigate(); const {user}=useAuth(); const [state,setState]=useState('Confirming your membership…');
  useEffect(()=>{
    let tries=0;
    const poll=async()=>{
      tries++;
      const d=await api('/billing/status');
      if(['ACTIVE','TRIAL'].includes(d.subscription?.status)){
        setState('Membership active.');
        setTimeout(()=>navigate(user?.onboardingPath==='CONTRACTOR'?'/app/contractor':'/app/passport/edit',{replace:true}),700);
        return;
      }
      if(tries<10) setTimeout(poll,1200); else setState('Payment was received but membership activation is still processing. Refresh shortly.');
    };
    poll().catch(e=>setState(e.message));
  },[]);
  return <div className="auth-page"><div className="auth-top"><Logo/></div><div className="auth-card white-card"><h1>BlueJob Membership</h1><p>{state}</p></div></div>
}