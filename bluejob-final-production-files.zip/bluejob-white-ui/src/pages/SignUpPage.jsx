import { Check, Eye } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import Logo from '../components/Logo';
import { useAuth } from '../context/AuthContext';

export default function SignUpPage() {
  const navigate = useNavigate();
  const { signUp } = useAuth();
  const [show, setShow] = useState(false);
  const [form, setForm] = useState({ fullName: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError('');
    setSaving(true);
    try {
      await signUp(form.fullName, form.email, form.password);
      navigate('/verify-account');
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-top"><Logo /><span>Already have an account? <Link to="/signin">Log in</Link></span></div>
      <div className="auth-card white-card">
        <h1>Create Your BlueJob Account</h1>
        <p>Create your account first. Your professional setup begins immediately after.</p>
        {error && <div className="form-error">{error}</div>}
        <form onSubmit={submit}>
          <label>Full Name<input value={form.fullName} onChange={e => setForm(f => ({...f,fullName:e.target.value}))} autoComplete="name" required /></label>
          <label>Email<input type="email" value={form.email} onChange={e => setForm(f => ({...f,email:e.target.value}))} autoComplete="email" required /></label>
          <label>Password
            <div className="password-field">
              <input type={show ? 'text' : 'password'} value={form.password} onChange={e => setForm(f => ({...f,password:e.target.value}))} minLength="12" autoComplete="new-password" required />
              <button className="password-eye" type="button" onClick={() => setShow(v => !v)} aria-label={show ? 'Hide password' : 'Show password'}><Eye size={18}/></button>
            </div>
          </label>
          <div className="password-rules">
            <span><Check/> At least 12 characters</span>
            <span><Check/> Use a password unique to BlueJob</span>
          </div>
          <button className="button button-primary button-full button-lg" disabled={saving}>{saving ? 'Creating…' : 'Create Account'}</button>
        </form>
        <small>By creating an account, you agree to BlueJob’s Terms of Service and Privacy Policy.</small>
      </div>
    </div>
  );
}