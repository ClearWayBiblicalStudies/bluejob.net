import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function AdminRoute() {
  const { user, loading } = useAuth();

  if (loading) return <div className="route-loading">Checking permissions…</div>;
  if (!user) return <Navigate to="/signin" replace />;
  if (user.mustChangePassword) return <Navigate to="/change-password" replace />;

  const allowed = user.roles?.includes('SUPER_ADMIN') || user.roles?.includes('BLUEJOB_ADMIN') || user.roles?.includes('VERIFICATION_REVIEWER');
  if (!allowed) return <Navigate to="/app/worker" replace />;
  if (!user.mfaEnabled) return <Navigate to="/mfa/setup" replace />;
  if (!user.mfaVerified) return <Navigate to="/mfa" replace />;
  return <Outlet />;
}