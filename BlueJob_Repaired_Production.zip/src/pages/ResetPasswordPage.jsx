import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';

export default function ResetPasswordPage() {
  const [params] = useSearchParams(); const navigate = useNavigate(); const [error, setError] = useState('');
  const token = params.get('token');
  return <div className="auth-page"><div className="auth-top"><Logo/></div><div className="auth-card white-card"><h1>Choose a New Password</h1><p>Use at least 12 characters with upper-case, lower-case, and a number.</p>{!token ? <p role="alert">This reset link is incomplete.</p> : <form onSubmit={async (event) => { event.preventDefault(); const password = new FormData(event.currentTarget).get('password'); try { const { user } = await api.resetPassword({ token, password }); navigate(user.role === 'CONTRACTOR' ? '/app/contractor' : user.role === 'SUPER_ADMIN' || user.role === 'ADMIN' ? '/app/admin' : '/app/worker'); } catch (value) { setError(value.message); } }}><label>New password<input name="password" type="password" minLength="12" autoComplete="new-password" required/></label><button className="button button-primary button-full button-lg">Set Password</button>{error && <p role="alert">{error}</p>}</form>}</div></div>;
}
