import { Check } from 'lucide-react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useState } from 'react';
import Logo from '../components/Logo';
import { api } from '../lib/api';

export default function SignUpPage() {
  const navigate = useNavigate(); const [params] = useSearchParams();
  const [accountType, setAccountType] = useState(params.get('role') === 'contractor' ? 'CONTRACTOR' : 'WORKER');
  const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  return <div className="auth-page"><div className="auth-top"><Logo/><span>Already have an account? <Link to="/signin">Log in</Link></span></div><div className="auth-card white-card"><h1>Create Your BlueJob Account</h1><p>Choose how you will use BlueJob.</p><form onSubmit={async (event) => { event.preventDefault(); setError(''); setBusy(true); const form = new FormData(event.currentTarget); try { const { user } = await api.signup({ name:form.get('name'),email:form.get('email'),password:form.get('password'),accountType,companyName:form.get('companyName') }); navigate(user.role === 'CONTRACTOR' ? '/app/contractor' : '/app/worker'); } catch (value) { setError(value.message); setBusy(false); } }}>
    <label>Account type<select value={accountType} onChange={(event) => setAccountType(event.target.value)}><option value="WORKER">I need work</option><option value="CONTRACTOR">I need to hire</option></select></label>
    <label>Full name<input name="name" autoComplete="name" required/></label>
    {accountType === 'CONTRACTOR' && <label>Company name<input name="companyName" autoComplete="organization" required/></label>}
    <label>Email<input name="email" type="email" autoComplete="email" required/></label>
    <label>Password<input name="password" type="password" minLength="12" autoComplete="new-password" required/></label>
    <div className="password-rules"><span><Check/> At least 12 characters</span><span><Check/> Upper-case and lower-case letters</span><span><Check/> At least one number</span></div>
    <button className="button button-primary button-full button-lg" disabled={busy}>{busy ? 'Creating account…' : 'Create Account'}</button>{error && <p role="alert">{error}</p>}
  </form><small>By creating an account, you agree to BlueJob’s Terms of Service and Privacy Policy.</small></div></div>;
}
