import { useState } from 'react';
import { Link } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';

export default function ForgotPasswordPage() {
  const [message, setMessage] = useState('');
  return <div className="auth-page"><div className="auth-top"><Logo/><Link to="/signin">Back to login</Link></div><div className="auth-card white-card"><h1>Reset Your Password</h1><p>Enter your BlueJob account email.</p><form onSubmit={async (event) => { event.preventDefault(); const email = new FormData(event.currentTarget).get('email'); try { const result = await api.forgotPassword({ email }); setMessage(result.message); } catch (error) { setMessage(error.message); } }}><label>Email<input name="email" type="email" required autoComplete="email"/></label><button className="button button-primary button-full button-lg">Send Secure Reset Link</button>{message && <p role="status">{message}</p>}</form></div></div>;
}
