import { useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';

export default function MfaSignInPage() {
  const location = useLocation(); const navigate = useNavigate(); const [error, setError] = useState('');
  const challenge = location.state?.challenge;
  if (!challenge) return <Navigate to="/signin" replace/>;
  return <div className="auth-page"><div className="auth-top"><Logo/></div><div className="auth-card white-card"><h1>Security Verification</h1><p>Enter the six-digit code from your authenticator.</p><form onSubmit={async (event) => { event.preventDefault(); const code = new FormData(event.currentTarget).get('code'); try { const { user } = await api.verifyMfaLogin({ challenge, code }); navigate(user.role === 'SUPER_ADMIN' || user.role === 'ADMIN' ? '/app/admin' : user.role === 'CONTRACTOR' ? '/app/contractor' : '/app/worker'); } catch (value) { setError(value.message); } }}><label>Authenticator code<input name="code" inputMode="numeric" pattern="[0-9]{6}" autoComplete="one-time-code" required/></label><button className="button button-primary button-full button-lg">Verify</button>{error && <p role="alert">{error}</p>}</form></div></div>;
}
