import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import AppShell from '../components/AppShell';
import { api } from '../lib/api';

export default function BidDetailPage(){
  const {jobId}=useParams(); const [job,setJob]=useState(null); const [bids,setBids]=useState([]); const [user,setUser]=useState(null); const [error,setError]=useState('');
  const load=()=>Promise.all([api.job(jobId),api.bids(jobId),api.me()]).then(([jobResult,bidResult,userResult])=>{setJob(jobResult.job);setBids(bidResult.bids);setUser(userResult.user);}).catch((value)=>setError(value.message));
  useEffect(load,[jobId]);
  return <AppShell user={user?{name:user.name,initials:user.name.slice(0,2).toUpperCase()}:undefined} role={user?.role==='CONTRACTOR'?'contractor':'worker'}><div className="page-heading"><div><Link to={user?.role==='CONTRACTOR'?'/app/contractor':'/app/worker'} className="back-link">← Back</Link><h1>{job?.title||'Job bids'}</h1><p>{job?.location||''}</p></div>{job&&<span className="open-pill">{job.status}</span>}</div>{error&&<p role="alert">{error}</p>}
    {user?.role==='WORKER'&&job?.status==='OPEN'&&<form className="card bj-admin-form" onSubmit={async(event)=>{event.preventDefault();const form=new FormData(event.currentTarget);try{await api.submitBid(jobId,{amount:Number(form.get('amount')),message:form.get('message'),estimatedDuration:form.get('duration')});setError('Bid submitted.');load();}catch(value){setError(value.message);}}}><h2>Submit or update your bid</h2><input name="amount" type="number" min="1" placeholder="Bid amount" required/><input name="duration" placeholder="Estimated duration"/><textarea name="message" placeholder="Scope notes"/><button className="button button-primary">Submit bid</button></form>}
    <section className="card bid-table"><div className="section-heading"><div><h2>{bids.length} verified bid{bids.length===1?'':'s'}</h2><p>Only real database records appear here.</p></div></div>{bids.length?<>{<div className="table-head"><span>Subcontractor</span><span>Work Score</span><span>Bid Amount</span><span>Submitted</span></div>}{bids.map((bid)=><div className="bid-row" key={bid.id}><strong>{bid.worker_name||'Your bid'}</strong><span>{bid.work_score||'UNRATED'}</span><strong>${Number(bid.amount).toLocaleString()}</strong><span>{new Date(bid.created_at).toLocaleDateString()}</span></div>)}</>:<div className="empty-state"><strong>No bids yet</strong><span>Qualified responses will appear here.</span></div>}</section>
  </AppShell>;
}
