import { Navigate, Route, Routes } from 'react-router-dom';
import React from 'react';
import LandingPage from './pages/LandingPage';
import SignUpPage from './pages/SignUpPage';
import SignInPage from './pages/SignInPage';
import ChoosePathPage from './pages/ChoosePathPage';
import WorkerDashboard from './pages/WorkerDashboard';
import ContractorDashboard from './pages/ContractorDashboard';
import PostJobPage from './pages/PostJobPage';
import BidDetailPage from './pages/BidDetailPage';
import AdminJobs from './pages/AdminJobs';
import PassportPage from './pages/PassportPage';
import PassportEditPage from './pages/PassportEditPage';
import VerificationPage from './pages/VerificationPage';
import AccountSecurityPage from './pages/AccountSecurityPage';
import RatingPage from './pages/RatingPage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';
import ResetPasswordPage from './pages/ResetPasswordPage';
import MfaSignInPage from './pages/MfaSignInPage';
import AuthGate from './components/AuthGate';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/signup" element={<SignUpPage />} />
      <Route path="/signin" element={<SignInPage />} />
      <Route path="/signin/mfa" element={<MfaSignInPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      <Route path="/login.html" element={<Navigate to="/signin" replace />} />
      <Route path="/choose-path" element={<ChoosePathPage />} />
      <Route path="/app/worker" element={<AuthGate roles={['WORKER']}><WorkerDashboard /></AuthGate>} />
      <Route path="/app/passport" element={<AuthGate><PassportPage /></AuthGate>} />
      <Route path="/app/passport/edit" element={<AuthGate><PassportEditPage /></AuthGate>} />
      <Route path="/app/verification" element={<AuthGate><VerificationPage /></AuthGate>} />
      <Route path="/app/security" element={<AuthGate><AccountSecurityPage /></AuthGate>} />
      <Route path="/app/contractor" element={<AuthGate roles={['CONTRACTOR','ADMIN','SUPER_ADMIN']}><ContractorDashboard /></AuthGate>} />
      <Route path="/app/post-job" element={<AuthGate roles={['CONTRACTOR','ADMIN','SUPER_ADMIN']}><PostJobPage /></AuthGate>} />
      <Route path="/app/jobs/:jobId/bids" element={<AuthGate><BidDetailPage /></AuthGate>} />
      <Route path="/app/jobs/:jobId/rating" element={<AuthGate><RatingPage /></AuthGate>} />
      <Route path="/app/admin" element={<AuthGate roles={['ADMIN','SUPER_ADMIN']}><AdminJobs /></AuthGate>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
