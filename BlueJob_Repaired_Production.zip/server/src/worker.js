import { Client } from "pg";
import { createHash, randomBytes } from "node:crypto";

const encoder = new TextEncoder();
const SESSION_COOKIE = "bj_session";
const SESSION_SECONDS = 60 * 60 * 24 * 7;
const securityHeaders = { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff", "referrer-policy": "no-referrer" };

function json(body, status = 200, headers = {}) {
  return new Response(JSON.stringify(body), { status, headers: { ...securityHeaders, ...headers } });
}

function withCors(request, response, env) {
  const origin = request.headers.get("Origin");
  const allowed = new Set([env.APP_ORIGIN || "https://bluejob.net", "https://bluejob.net", "http://localhost:5173"]);
  if (origin && allowed.has(origin)) {
    response.headers.set("Access-Control-Allow-Origin", origin);
    response.headers.set("Access-Control-Allow-Credentials", "true");
    response.headers.set("Vary", "Origin");
  }
  return response;
}

function sessionCookie(token, maxAge = SESSION_SECONDS) {
  return `${SESSION_COOKIE}=${token}; Max-Age=${maxAge}; Path=/; HttpOnly; Secure; SameSite=Lax`;
}

function sha256(value) { return createHash("sha256").update(value).digest("hex"); }
function constantTimeEqual(left, right) {
  if (typeof left !== "string" || typeof right !== "string" || left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return difference === 0;
}
function requirePepper(env) {
  if (!env.PASSWORD_PEPPER || env.PASSWORD_PEPPER.length < 32) throw new Error("PASSWORD_PEPPER is not configured");
  return env.PASSWORD_PEPPER;
}

export async function passwordHash(password, pepper) {
  const salt = randomBytes(16).toString("base64url");
  const iterations = 600000;
  const key = await crypto.subtle.importKey("raw", encoder.encode(`${pepper}:${password}`), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: encoder.encode(salt), iterations }, key, 256);
  const digest = [...new Uint8Array(bits)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  return `pbkdf2$${iterations}$${salt}$${digest}`;
}

export async function passwordMatches(password, storedHash, pepper) {
  if (!storedHash?.startsWith("pbkdf2$")) return false;
  const [algorithm, rawIterations, salt, expected] = storedHash.split("$");
  if (algorithm !== "pbkdf2" || !/^\d+$/.test(rawIterations) || !salt || !/^[0-9a-f]{64}$/.test(expected)) return false;
  const iterations = Number(rawIterations);
  if (iterations < 100000 || iterations > 1000000) return false;
  const key = await crypto.subtle.importKey("raw", encoder.encode(`${pepper}:${password}`), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: encoder.encode(salt), iterations }, key, 256);
  const actual = [...new Uint8Array(bits)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  return constantTimeEqual(actual, expected);
}

function base32Encode(bytes) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = "";
  for (const byte of bytes) bits += byte.toString(2).padStart(8, "0");
  let output = "";
  for (let index = 0; index < bits.length; index += 5) output += alphabet[parseInt(bits.slice(index, index + 5).padEnd(5, "0"), 2)];
  return output;
}
function base32Decode(value) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = "";
  for (const character of value.replace(/=+$/g, "").toUpperCase()) {
    const index = alphabet.indexOf(character);
    if (index < 0) return new Uint8Array();
    bits += index.toString(2).padStart(5, "0");
  }
  const bytes = [];
  for (let index = 0; index + 8 <= bits.length; index += 8) bytes.push(parseInt(bits.slice(index, index + 8), 2));
  return new Uint8Array(bytes);
}
async function totpAt(secret, counter) {
  const key = await crypto.subtle.importKey("raw", base32Decode(secret), { name: "HMAC", hash: "SHA-1" }, false, ["sign"]);
  const buffer = new ArrayBuffer(8);
  new DataView(buffer).setBigUint64(0, BigInt(counter));
  const digest = new Uint8Array(await crypto.subtle.sign("HMAC", key, buffer));
  const offset = digest[digest.length - 1] & 15;
  const number = (((digest[offset] & 127) << 24) | (digest[offset + 1] << 16) | (digest[offset + 2] << 8) | digest[offset + 3]) % 1000000;
  return String(number).padStart(6, "0");
}
export async function verifyTotp(secret, code, timestamp = Date.now()) {
  if (!/^\d{6}$/.test(String(code || ""))) return false;
  const counter = Math.floor(timestamp / 30000);
  for (const offset of [-1, 0, 1]) if (constantTimeEqual(await totpAt(secret, counter + offset), String(code))) return true;
  return false;
}

async function readJson(request) {
  if (!(request.headers.get("content-type") || "").includes("application/json")) return {};
  return request.json().catch(() => ({}));
}
async function withDb(env, callback) {
  if (!env.HYPERDRIVE?.connectionString) throw new Error("Database binding is not configured");
  const client = new Client({ connectionString: env.HYPERDRIVE.connectionString, ssl: { rejectUnauthorized: false } });
  await client.connect();
  try { await client.query("SET search_path TO bluejob, public"); return await callback(client); }
  finally { await client.end().catch(() => {}); }
}
function primaryRole(roles = []) { return ["SUPER_ADMIN", "ADMIN", "CONTRACTOR", "WORKER", "USER"].find((role) => roles.includes(role)) || "USER"; }

async function loadSession(request, db) {
  const token = request.headers.get("Cookie")?.match(new RegExp(`(?:^|;\\s*)${SESSION_COOKIE}=([^;]+)`))?.[1];
  if (!token) return null;
  const result = await db.query(
    `SELECT u.*,s.id session_id,s.mfa_verified_at,COALESCE(array_agg(r.name) FILTER (WHERE r.name IS NOT NULL),'{}') roles
       FROM sessions s JOIN users u ON u.id=s.user_id
       LEFT JOIN user_roles ur ON ur.user_id=u.id LEFT JOIN roles r ON r.id=ur.role_id
      WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>now() GROUP BY u.id,s.id`, [sha256(token)]);
  return result.rows[0] || null;
}
async function createSession(db, userId, mfaVerified = false) {
  const token = randomBytes(32).toString("base64url");
  await db.query("INSERT INTO sessions(user_id,token_hash,mfa_verified_at,expires_at) VALUES($1,$2,CASE WHEN $3 THEN now() ELSE NULL END,now()+interval '7 days')", [userId, sha256(token), mfaVerified]);
  return token;
}
async function publicUser(db, user) {
  const metrics = await db.query(`SELECT count(DISTINCT j.id)::integer completed_jobs,COALESCE(sum(DISTINCT j.budget),0)::numeric verified_work_value FROM jobs j LEFT JOIN job_awards a ON a.job_id=j.id LEFT JOIN bids b ON b.id=a.bid_id WHERE j.status='COMPLETED' AND (j.created_by=$1 OR b.worker_id=$1)`, [user.id]);
  return { id:user.id,email:user.email,name:user.display_name,displayName:user.display_name,role:primaryRole(user.roles),roles:user.roles,onboardingPath:user.onboarding_path,email_verified:user.email_verified,phone_verified:user.phone_verified,mfa_enabled:user.mfa_enabled,membership_status:user.membership_status,work_score:user.work_score,work_score_rating_count:user.work_score_rating_count,completed_jobs:metrics.rows[0].completed_jobs,verified_work_value:metrics.rows[0].verified_work_value };
}
function roleDenied(user, ...roles) { return !user || !roles.some((role) => user.roles.includes(role)); }
function membershipDenied(user, env) { return env.MEMBERSHIP_ENFORCEMENT === "true" && !["ACTIVE", "TRIAL", "COMPED"].includes(user.membership_status); }

async function sendEmail(env, { to, subject, html }) {
  if (!env.RESEND_API_KEY || !env.PASSWORD_RESET_FROM) throw new Error("Email delivery is not configured");
  const response = await fetch("https://api.resend.com/emails", { method:"POST", headers:{ Authorization:`Bearer ${env.RESEND_API_KEY}`, "content-type":"application/json" }, body:JSON.stringify({ from:env.PASSWORD_RESET_FROM,to,subject,html }) });
  if (!response.ok) throw new Error("Email delivery failed");
}
async function sendResetEmail(env, email, token) {
  const origin = new URL(env.APP_ORIGIN || "https://bluejob.net");
  if (origin.protocol !== "https:") throw new Error("APP_ORIGIN must use HTTPS");
  const url = new URL("/reset-password", origin); url.searchParams.set("token", token);
  await sendEmail(env, { to:email,subject:"Set your BlueJob password",html:`<p>Use this one-time link to set your BlueJob password:</p><p><a href="${url.href}">Set password</a></p><p>This link expires in one hour.</p>` });
}

async function hmacHex(secret, value) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name:"HMAC", hash:"SHA-256" }, false, ["sign"]);
  return [...new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(value)))].map((byte) => byte.toString(16).padStart(2,"0")).join("");
}

async function stripeWebhook(request, env, db) {
  if (!env.STRIPE_WEBHOOK_SECRET) return json({ error:"Billing webhook is not configured" },503);
  const raw = await request.text(); const signature = request.headers.get("stripe-signature") || "";
  const parts = Object.fromEntries(signature.split(",").map((part) => part.split("=",2))); const timestamp = Number(parts.t);
  if (!timestamp || !parts.v1 || Math.abs(Date.now()/1000-timestamp)>300 || !constantTimeEqual(await hmacHex(env.STRIPE_WEBHOOK_SECRET,`${timestamp}.${raw}`),parts.v1)) return json({ error:"Invalid webhook signature" },400);
  const event = JSON.parse(raw); const object = event.data?.object || {}; const userId = object.client_reference_id || object.metadata?.user_id;
  const recorded = await db.query("INSERT INTO billing_events(stripe_event_id,event_type) VALUES($1,$2) ON CONFLICT DO NOTHING RETURNING stripe_event_id",[event.id,event.type]);
  if (!recorded.rowCount) return json({ received:true,duplicate:true });
  if (event.type === "checkout.session.completed" && userId) await db.query("UPDATE users SET membership_status='ACTIVE',updated_at=now() WHERE id=$1",[userId]);
  if (event.type === "customer.subscription.updated" && userId) await db.query("UPDATE users SET membership_status=$1,updated_at=now() WHERE id=$2",[["active","trialing"].includes(object.status)?"ACTIVE":object.status==="past_due"?"PAST_DUE":"CANCELED",userId]);
  if (event.type === "customer.subscription.deleted" && userId) await db.query("UPDATE users SET membership_status='CANCELED',updated_at=now() WHERE id=$1",[userId]);
  return json({ received:true });
}

async function authRoute(request, env, db, path) {
  if (path === "/api/billing/webhook" && request.method === "POST") return stripeWebhook(request,env,db);
  if (["/api/auth/signup", "/api/auth/register"].includes(path) && request.method === "POST") {
    const input = await readJson(request); const displayName = String(input.displayName || input.name || "").trim(); const email = String(input.email || "").trim().toLowerCase(); const password = String(input.password || ""); const accountType = input.accountType === "CONTRACTOR" ? "CONTRACTOR" : "WORKER"; const companyName = String(input.companyName || "").trim();
    if (!displayName || displayName.length > 120 || !/^\S+@\S+\.\S+$/.test(email)) return json({ error:"Enter a valid name and email address" },400);
    if (password.length < 12 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) return json({ error:"Password must be at least 12 characters and include upper-case, lower-case, and a number" },400);
    if (accountType === "CONTRACTOR" && !companyName) return json({ error:"Company name is required for contractor accounts" },400);
    const storedPassword = await passwordHash(password, requirePepper(env));
    try {
      await db.query("BEGIN");
      const inserted = await db.query("INSERT INTO users(email,password_hash,display_name,onboarding_path) VALUES($1,$2,$3,$4) RETURNING *", [email,storedPassword,displayName,accountType]); const user = inserted.rows[0];
      await db.query("INSERT INTO user_roles(user_id,role_id) SELECT $1,id FROM roles WHERE name IN ('USER',$2) ON CONFLICT DO NOTHING", [user.id,accountType]);
      if (accountType === "CONTRACTOR") {
        const slug = `${companyName.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,50) || "company"}-${randomBytes(3).toString("hex")}`;
        const company = await db.query("INSERT INTO companies(name,slug,created_by) VALUES($1,$2,$3) RETURNING id", [companyName,slug,user.id]);
        await db.query("INSERT INTO company_memberships(company_id,user_id,role) VALUES($1,$2,'OWNER')", [company.rows[0].id,user.id]);
      }
      const token = await createSession(db,user.id); await db.query("COMMIT"); user.roles=["USER",accountType];
      return json({ user:await publicUser(db,user) },201,{ "set-cookie":sessionCookie(token) });
    } catch (error) { await db.query("ROLLBACK").catch(()=>{}); if (error.code === "23505") return json({ error:"An account with that email already exists" },409); throw error; }
  }
  if (["/api/auth/login", "/api/auth/signin"].includes(path) && request.method === "POST") {
    const input=await readJson(request); const result=await db.query("SELECT * FROM users WHERE lower(email)=lower($1)",[String(input.email||"").trim()]); const user=result.rows[0];
    if (!user || !await passwordMatches(String(input.password||""),user.password_hash,requirePepper(env))) return json({ error:"Invalid email or password" },401);
    if (user.mfa_enabled) { const challenge=randomBytes(32).toString("base64url"); await db.query("INSERT INTO mfa_challenges(user_id,token_hash,expires_at) VALUES($1,$2,now()+interval '5 minutes')",[user.id,sha256(challenge)]); return json({ mfaRequired:true,challenge }); }
    const token=await createSession(db,user.id); const current=await loadSession(new Request(request.url,{headers:{Cookie:`${SESSION_COOKIE}=${token}`}}),db);
    return json({ user:await publicUser(db,current),requiresPasswordChange:user.force_password_change },200,{ "set-cookie":sessionCookie(token) });
  }
  if (path === "/api/auth/mfa/verify-login" && request.method === "POST") {
    const input=await readJson(request); const challenge=await db.query(`SELECT c.id,c.user_id,u.mfa_secret FROM mfa_challenges c JOIN users u ON u.id=c.user_id WHERE c.token_hash=$1 AND c.used_at IS NULL AND c.expires_at>now()`,[sha256(String(input.challenge||""))]);
    if (!challenge.rowCount || !await verifyTotp(challenge.rows[0].mfa_secret,input.code)) return json({ error:"Invalid or expired verification code" },401);
    await db.query("UPDATE mfa_challenges SET used_at=now() WHERE id=$1",[challenge.rows[0].id]); const token=await createSession(db,challenge.rows[0].user_id,true); const current=await loadSession(new Request(request.url,{headers:{Cookie:`${SESSION_COOKIE}=${token}`}}),db);
    return json({ user:await publicUser(db,current) },200,{ "set-cookie":sessionCookie(token) });
  }
  if (["/api/auth/forgot-password","/api/auth/password-reset/request"].includes(path) && request.method === "POST") {
    const input=await readJson(request); const result=await db.query("SELECT id,email FROM users WHERE lower(email)=lower($1)",[String(input.email||"").trim()]);
    if (result.rowCount && env.RESEND_API_KEY && env.PASSWORD_RESET_FROM) { const token=randomBytes(32).toString("base64url"); await db.query("DELETE FROM password_reset_tokens WHERE user_id=$1 OR expires_at<=now()",[result.rows[0].id]); await db.query("INSERT INTO password_reset_tokens(user_id,token_hash,expires_at) VALUES($1,$2,now()+interval '1 hour')",[result.rows[0].id,sha256(token)]); try { await sendResetEmail(env,result.rows[0].email,token); } catch { await db.query("DELETE FROM password_reset_tokens WHERE token_hash=$1",[sha256(token)]); } }
    return json({ ok:true,message:"If that account exists, a reset link has been sent" });
  }
  if (["/api/auth/reset-password","/api/auth/password-reset/confirm"].includes(path) && request.method === "POST") {
    const input=await readJson(request); const password=String(input.password||"");
    if (!input.token || password.length<12 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) return json({ error:"Enter a valid reset link and a compliant password" },400);
    await db.query("BEGIN"); try { const reset=await db.query("UPDATE password_reset_tokens SET used_at=now() WHERE token_hash=$1 AND used_at IS NULL AND expires_at>now() RETURNING user_id",[sha256(input.token)]); if(!reset.rowCount){await db.query("ROLLBACK");return json({error:"This reset link is invalid or expired"},400);} await db.query("UPDATE users SET password_hash=$1,force_password_change=false,updated_at=now() WHERE id=$2",[await passwordHash(password,requirePepper(env)),reset.rows[0].user_id]); await db.query("UPDATE sessions SET revoked_at=now() WHERE user_id=$1",[reset.rows[0].user_id]); const token=await createSession(db,reset.rows[0].user_id); await db.query("COMMIT"); const current=await loadSession(new Request(request.url,{headers:{Cookie:`${SESSION_COOKIE}=${token}`}}),db); return json({user:await publicUser(db,current)},200,{"set-cookie":sessionCookie(token)}); } catch(error){await db.query("ROLLBACK").catch(()=>{});throw error;}
  }
  if (path === "/api/auth/logout" && request.method === "POST") { const token=request.headers.get("Cookie")?.match(new RegExp(`(?:^|;\\s*)${SESSION_COOKIE}=([^;]+)`))?.[1]; if(token)await db.query("UPDATE sessions SET revoked_at=now() WHERE token_hash=$1",[sha256(token)]); return json({ok:true},200,{"set-cookie":sessionCookie("",0)}); }
  return null;
}

async function recalculateScore(db,userId){const result=await db.query(`SELECT count(*)::integer rating_count,avg((showed_up_as_agreed+completed_agreed_scope+quality_right_first_time+stayed_on_schedule+communicated_early+handled_changes_fairly+respected_agreed_budget+professional_and_reliable+trust_with_larger_job+work_together_again)/10.0)::numeric average FROM job_ratings WHERE rated_user_id=$1`,[userId]);if(!result.rows[0].rating_count)return;const score=Math.round(300+((Number(result.rows[0].average)-1)/4)*600);await db.query("UPDATE users SET work_score=$1,work_score_rating_count=$2,updated_at=now() WHERE id=$3",[score,result.rows[0].rating_count,userId]);await db.query("INSERT INTO work_score_events(user_id,score,rating_count,explanation) VALUES($1,$2,$3,jsonb_build_object('source','verified_job_ratings'))",[userId,score,result.rows[0].rating_count]);}

async function applicationRoute(request,env,db,user,path){
  if(["/api/me","/api/auth/me"].includes(path)&&request.method==="GET"){if(!user)return json({error:"Authentication required"},401);return json({user:await publicUser(db,user)});} if(!user)return json({error:"Authentication required"},401);
  if(path==="/api/auth/settings"&&request.method==="GET")return json({settings:{email:user.email,email_verified:user.email_verified,phone:user.phone,phone_verified:user.phone_verified,mfa_enabled:user.mfa_enabled}});
  if(path==="/api/auth/mfa/setup"&&request.method==="POST"){const secret=base32Encode(randomBytes(20));await db.query("UPDATE users SET mfa_secret=$1,mfa_enabled=false,updated_at=now() WHERE id=$2",[secret,user.id]);return json({secret,otpauth:`otpauth://totp/BlueJob:${encodeURIComponent(user.email)}?secret=${secret}&issuer=BlueJob`});}
  if(path==="/api/auth/mfa/enable"&&request.method==="POST"){const input=await readJson(request);const secret=(await db.query("SELECT mfa_secret FROM users WHERE id=$1",[user.id])).rows[0]?.mfa_secret;if(!secret||!await verifyTotp(secret,input.code))return json({error:"Invalid authenticator code"},400);await db.query("UPDATE users SET mfa_enabled=true,updated_at=now() WHERE id=$1",[user.id]);await db.query("UPDATE sessions SET mfa_verified_at=now() WHERE id=$1",[user.session_id]);return json({enabled:true});}
  if(path==="/api/verification/email/send"&&request.method==="POST"){if(!env.RESEND_API_KEY||!env.PASSWORD_RESET_FROM)return json({error:"Email verification is not configured"},503);const code=String(randomBytes(4).readUInt32BE(0)%1000000).padStart(6,"0");await db.query("DELETE FROM verification_codes WHERE user_id=$1 AND type='EMAIL'",[user.id]);await db.query("INSERT INTO verification_codes(user_id,type,target,code_hash,expires_at) VALUES($1,'EMAIL',$2,$3,now()+interval '15 minutes')",[user.id,user.email,sha256(code)]);await sendEmail(env,{to:user.email,subject:"Verify your BlueJob email",html:`<p>Your BlueJob verification code is <strong>${code}</strong>.</p><p>It expires in 15 minutes.</p>`});return json({ok:true});}
  if(path==="/api/verification/email/confirm"&&request.method==="POST"){const input=await readJson(request);const result=await db.query("UPDATE verification_codes SET consumed_at=now() WHERE user_id=$1 AND type='EMAIL' AND code_hash=$2 AND consumed_at IS NULL AND expires_at>now() RETURNING id",[user.id,sha256(String(input.code||""))]);if(!result.rowCount)return json({error:"Invalid or expired email code"},400);await db.query("UPDATE users SET email_verified=true,updated_at=now() WHERE id=$1",[user.id]);return json({verified:true});}
  if(path==="/api/verification/phone/send"&&request.method==="POST"){if(!env.SMS_PROVIDER_URL)return json({error:"Phone verification is not configured"},503);const input=await readJson(request);const phone=String(input.phone||"").trim();if(!/^\+[1-9]\d{7,14}$/.test(phone))return json({error:"Enter a phone number in international format"},400);const code=String(randomBytes(4).readUInt32BE(0)%1000000).padStart(6,"0");await db.query("DELETE FROM verification_codes WHERE user_id=$1 AND type='PHONE'",[user.id]);await db.query("INSERT INTO verification_codes(user_id,type,target,code_hash,expires_at) VALUES($1,'PHONE',$2,$3,now()+interval '10 minutes')",[user.id,phone,sha256(code)]);const response=await fetch(env.SMS_PROVIDER_URL,{method:"POST",headers:{"content-type":"application/json",...(env.SMS_PROVIDER_TOKEN?{Authorization:`Bearer ${env.SMS_PROVIDER_TOKEN}`}:{})},body:JSON.stringify({to:phone,body:`Your BlueJob verification code is ${code}`})});if(!response.ok)return json({error:"Unable to send phone code"},502);await db.query("UPDATE users SET phone=$1,phone_verified=false,updated_at=now() WHERE id=$2",[phone,user.id]);return json({ok:true});}
  if(path==="/api/verification/phone/confirm"&&request.method==="POST"){const input=await readJson(request);const result=await db.query("UPDATE verification_codes SET consumed_at=now() WHERE user_id=$1 AND type='PHONE' AND code_hash=$2 AND consumed_at IS NULL AND expires_at>now() RETURNING id",[user.id,sha256(String(input.code||""))]);if(!result.rowCount)return json({error:"Invalid or expired phone code"},400);await db.query("UPDATE users SET phone_verified=true,updated_at=now() WHERE id=$1",[user.id]);return json({verified:true});}
  if(path==="/api/onboarding"&&request.method==="POST"){const input=await readJson(request);if(!["WORKER","CONTRACTOR"].includes(input.path))return json({error:"Invalid account path"},400);await db.query("UPDATE users SET onboarding_path=$1,updated_at=now() WHERE id=$2",[input.path,user.id]);await db.query("INSERT INTO user_roles(user_id,role_id) SELECT $1,id FROM roles WHERE name=$2 ON CONFLICT DO NOTHING",[user.id,input.path]);return json({ok:true,path:input.path});}
  if(path==="/api/passport"&&request.method==="GET"){const passport=(await db.query("SELECT * FROM work_passports WHERE user_id=$1",[user.id])).rows[0]||null;const history=(await db.query("SELECT id,title,company,details description,dates,status,created_at FROM work_history WHERE user_id=$1 ORDER BY created_at DESC",[user.id])).rows;return json({passport:passport?{...passport,history}:null});}
  if(path==="/api/passport"&&request.method==="PUT"){const input=await readJson(request);const skills=Array.isArray(input.skills)?input.skills:String(input.skills||"").split(",").map(v=>v.trim()).filter(Boolean);await db.query("BEGIN");try{const passport=await db.query(`INSERT INTO work_passports(user_id,trade,skills,years_experience,service_area,profile_summary,travel_radius,worker_type,crew_size,availability,tools,transportation) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) ON CONFLICT(user_id) DO UPDATE SET trade=EXCLUDED.trade,skills=EXCLUDED.skills,years_experience=EXCLUDED.years_experience,service_area=EXCLUDED.service_area,profile_summary=EXCLUDED.profile_summary,travel_radius=EXCLUDED.travel_radius,worker_type=EXCLUDED.worker_type,crew_size=EXCLUDED.crew_size,availability=EXCLUDED.availability,tools=EXCLUDED.tools,transportation=EXCLUDED.transportation,updated_at=now() RETURNING *`,[user.id,input.trade||null,JSON.stringify(skills),input.yearsExperience||null,input.location||input.serviceArea||null,input.profileSummary||null,input.travelRadius||null,input.workerType||null,input.crewSize||null,input.availability||null,input.tools||null,input.transportation||null]);if(Array.isArray(input.history)){await db.query("DELETE FROM work_history WHERE user_id=$1",[user.id]);for(const item of input.history.slice(0,50))if(item.title)await db.query("INSERT INTO work_history(user_id,title,company,details,dates) VALUES($1,$2,$3,$4,$5)",[user.id,String(item.title).slice(0,160),String(item.company||"").slice(0,160)||null,String(item.description||item.details||"").slice(0,4000)||null,String(item.dates||"").slice(0,80)||null]);}await db.query("UPDATE users SET display_name=COALESCE(NULLIF($1,''),display_name),updated_at=now() WHERE id=$2",[String(input.name||"").trim(),user.id]);await db.query("COMMIT");return json({passport:passport.rows[0]});}catch(error){await db.query("ROLLBACK").catch(()=>{});throw error;}}
  if(path==="/api/passport/evidence"&&request.method==="GET")return json({evidence:(await db.query("SELECT id,type,original_name file,status,submitted_at FROM evidence WHERE user_id=$1 ORDER BY submitted_at DESC",[user.id])).rows});
  if(path==="/api/passport/evidence"&&request.method==="POST"){if(!env.EVIDENCE_BUCKET)return json({error:"Private evidence storage is not configured"},503);const form=await request.formData();const file=form.get("file");const type=String(form.get("type")||"").slice(0,120);if(!(file instanceof File)||!type||file.size>5*1024*1024)return json({error:"Choose a document no larger than 5 MB"},400);const bytes=await file.arrayBuffer();const digest=[...new Uint8Array(await crypto.subtle.digest("SHA-256",bytes))].map(b=>b.toString(16).padStart(2,"0")).join("");const key=`${user.id}/${crypto.randomUUID()}`;await env.EVIDENCE_BUCKET.put(key,bytes,{httpMetadata:{contentType:file.type||"application/octet-stream"},customMetadata:{sha256:digest}});const result=await db.query("INSERT INTO evidence(user_id,type,original_name,stored_name,mime_type,size_bytes,sha256,status) VALUES($1,$2,$3,$4,$5,$6,$7,'PENDING') RETURNING id,type,original_name file,status,submitted_at",[user.id,type,file.name.slice(0,255),key,file.type,file.size,digest]);return json({evidence:result.rows[0]},201);}
  if(path==="/api/jobs"&&request.method==="GET"){const jobs=(await db.query(`SELECT j.id,j.title,j.trade,j.description,j.location,j.budget,j.status,j.created_at,count(b.id)::integer bid_count FROM jobs j LEFT JOIN bids b ON b.job_id=j.id WHERE j.status<>'CANCELLED' AND (j.status='OPEN' OR j.created_by=$1) GROUP BY j.id ORDER BY j.created_at DESC LIMIT 100`,[user.id])).rows;return json({jobs});}
  if(path==="/api/jobs"&&request.method==="POST"){if(roleDenied(user,"CONTRACTOR","ADMIN","SUPER_ADMIN"))return json({error:"Contractor access required"},403);if(membershipDenied(user,env))return json({error:"Active membership required"},402);const input=await readJson(request);const budget=Number(input.budget||input.budget_min);if(!String(input.title||"").trim()||!String(input.description||"").trim()||!Number.isFinite(budget)||budget<=0)return json({error:"Title, scope, and a positive budget are required"},400);const company=(await db.query("SELECT company_id FROM company_memberships WHERE user_id=$1 ORDER BY created_at LIMIT 1",[user.id])).rows[0];const result=await db.query(`INSERT INTO jobs(owner_id,company_id,created_by,title,trade,description,location,budget,desired_start_date,estimated_duration,minimum_work_score,status) VALUES($1,$2,$1,$3,$4,$5,$6,$7,$8,$9,$10,'OPEN') RETURNING *`,[user.id,company?.company_id||null,String(input.title).trim().slice(0,160),String(input.trade||"General Construction").slice(0,100),String(input.description).trim().slice(0,8000),String(input.location||"").slice(0,200)||null,budget,input.start_date||input.desiredStartDate||null,String(input.duration||input.estimatedDuration||"").slice(0,100)||null,input.minimum_score||null]);return json({job:result.rows[0]},201);}
  const jobMatch=path.match(/^\/api\/jobs\/([0-9a-f-]{36})$/i);if(jobMatch&&request.method==="GET"){const result=await db.query("SELECT * FROM jobs WHERE id=$1 AND (status='OPEN' OR created_by=$2)",[jobMatch[1],user.id]);return result.rowCount?json({job:result.rows[0]}):json({error:"Job not found"},404);}
  const bidsMatch=path.match(/^\/api\/jobs\/([0-9a-f-]{36})\/bids$/i);if(bidsMatch&&request.method==="GET"){const job=(await db.query("SELECT * FROM jobs WHERE id=$1",[bidsMatch[1]])).rows[0];if(!job)return json({error:"Job not found"},404);const bids=(await db.query(`SELECT b.id,b.amount,b.message,b.estimated_duration,b.status,b.created_at,u.display_name worker_name,u.work_score FROM bids b JOIN users u ON u.id=b.worker_id WHERE b.job_id=$1 AND ($2 OR b.worker_id=$3) ORDER BY b.amount,b.created_at`,[bidsMatch[1],job.created_by===user.id,user.id])).rows;return json({bids});}
  if(bidsMatch&&request.method==="POST"){if(roleDenied(user,"WORKER"))return json({error:"Worker access required"},403);if(membershipDenied(user,env))return json({error:"Active membership required"},402);const input=await readJson(request);const amount=Number(input.amount);if(!Number.isFinite(amount)||amount<=0)return json({error:"A positive bid amount is required"},400);const result=await db.query(`INSERT INTO bids(job_id,bidder_id,worker_id,amount,message,estimated_duration) SELECT $1,$2,$2,$3,$4,$5 WHERE EXISTS(SELECT 1 FROM jobs WHERE id=$1 AND status='OPEN' AND created_by<>$2) ON CONFLICT(job_id,worker_id) DO UPDATE SET amount=EXCLUDED.amount,message=EXCLUDED.message,estimated_duration=EXCLUDED.estimated_duration,updated_at=now() RETURNING *`,[bidsMatch[1],user.id,amount,String(input.message||"").slice(0,2000),String(input.estimatedDuration||"").slice(0,100)]);return result.rowCount?json({bid:result.rows[0]},201):json({error:"Job is not open or you own this job"},409);}
  const statusMatch=path.match(/^\/api\/jobs\/([0-9a-f-]{36})\/status$/i);if(statusMatch&&request.method==="PATCH"){const input=await readJson(request);const transitions={OPEN:["CANCELLED"],AWARDED:["IN_PROGRESS","CANCELLED"],IN_PROGRESS:["COMPLETED","CANCELLED"]};const current=(await db.query("SELECT status FROM jobs WHERE id=$1 AND created_by=$2",[statusMatch[1],user.id])).rows[0];if(!current||!transitions[current.status]?.includes(input.status))return json({error:"Invalid job transition"},409);return json({job:(await db.query("UPDATE jobs SET status=$1,updated_at=now() WHERE id=$2 RETURNING *",[input.status,statusMatch[1]])).rows[0]});}
  if(path==="/api/ratings/pending"&&request.method==="GET")return json({pending:(await db.query(`SELECT j.id,j.title FROM jobs j JOIN job_awards a ON a.job_id=j.id JOIN bids b ON b.id=a.bid_id WHERE j.status='COMPLETED' AND (j.created_by=$1 OR b.worker_id=$1) AND NOT EXISTS(SELECT 1 FROM job_ratings r WHERE r.job_id=j.id AND r.rated_by_user_id=$1)`,[user.id])).rows});
  const ratingMatch=path.match(/^\/api\/jobs\/([0-9a-f-]{36})\/rating$/i);if(ratingMatch&&request.method==="POST"){const input=await readJson(request);const job=(await db.query("SELECT j.created_by,b.worker_id FROM jobs j JOIN job_awards a ON a.job_id=j.id JOIN bids b ON b.id=a.bid_id WHERE j.id=$1 AND j.status='COMPLETED'",[ratingMatch[1]])).rows[0];if(!job||(job.created_by!==user.id&&job.worker_id!==user.id))return json({error:"Rating requires completed work"},409);const ratedUserId=user.id===job.created_by?job.worker_id:job.created_by;const values=["showedUpAsAgreed","completedAgreedScope","qualityRightFirstTime","stayedOnSchedule","communicatedEarly","handledChangesFairly","respectedAgreedBudget","professionalAndReliable","trustWithLargerJob","workTogetherAgain"].map(k=>Number(input[k]));if(values.some(v=>!Number.isInteger(v)||v<1||v>5))return json({error:"Every rating must be between 1 and 5"},400);await db.query(`INSERT INTO job_ratings(job_id,rated_by_user_id,rated_user_id,rater_role,showed_up_as_agreed,completed_agreed_scope,quality_right_first_time,stayed_on_schedule,communicated_early,handled_changes_fairly,respected_agreed_budget,professional_and_reliable,trust_with_larger_job,work_together_again,private_note) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`,[ratingMatch[1],user.id,ratedUserId,user.id===job.created_by?"CONTRACTOR":"WORKER",...values,String(input.privateNote||"").slice(0,4000)||null]);await recalculateScore(db,ratedUserId);return json({ok:true},201);}
  if(path==="/api/billing/checkout"&&request.method==="POST"){if(!env.STRIPE_SECRET_KEY||!env.STRIPE_PRICE_ID)return json({error:"Secure checkout is not configured"},503);const origin=env.APP_ORIGIN||"https://bluejob.net";const form=new URLSearchParams({mode:"subscription","line_items[0][price]":env.STRIPE_PRICE_ID,"line_items[0][quantity]":"1",success_url:`${origin}/app/security?membership=success`,cancel_url:`${origin}/app/security?membership=canceled`,client_reference_id:user.id,"metadata[user_id]":user.id,"subscription_data[metadata][user_id]":user.id});const response=await fetch("https://api.stripe.com/v1/checkout/sessions",{method:"POST",headers:{Authorization:`Bearer ${env.STRIPE_SECRET_KEY}`,"content-type":"application/x-www-form-urlencoded"},body:form});const result=await response.json();return response.ok?json({url:result.url}):json({error:"Unable to open secure checkout"},502);}
  if(path==="/api/admin/jobs"&&request.method==="GET"){if(roleDenied(user,"ADMIN","SUPER_ADMIN"))return json({error:"Forbidden"},403);return json({jobs:(await db.query("SELECT j.*,count(b.id)::integer bid_count FROM jobs j LEFT JOIN bids b ON b.job_id=j.id GROUP BY j.id ORDER BY j.created_at DESC LIMIT 200")).rows});}
  if(path==="/api/admin/jobs"&&request.method==="POST"){if(roleDenied(user,"ADMIN","SUPER_ADMIN"))return json({error:"Forbidden"},403);const input=await readJson(request);const budget=Number(input.budget);if(!input.title||!input.description||!Number.isFinite(budget)||budget<=0)return json({error:"Title, scope, and budget are required"},400);const result=await db.query("INSERT INTO jobs(owner_id,created_by,title,trade,description,location,budget,status) VALUES($1,$1,$2,'General Construction',$3,$4,$5,'OPEN') RETURNING *",[user.id,String(input.title).slice(0,160),String(input.description).slice(0,8000),String(input.location||"").slice(0,200),budget]);await db.query("INSERT INTO admin_audit_log(admin_user_id,action,target_type,target_id) VALUES($1,'CREATE_JOB','JOB',$2)",[user.id,result.rows[0].id]);return json({job:result.rows[0]},201);}
  const adminDelete=path.match(/^\/api\/admin\/jobs\/([0-9a-f-]{36})$/i);if(adminDelete&&request.method==="DELETE"){if(roleDenied(user,"ADMIN","SUPER_ADMIN"))return json({error:"Forbidden"},403);await db.query("UPDATE jobs SET status='CANCELLED',updated_at=now() WHERE id=$1",[adminDelete[1]]);await db.query("INSERT INTO admin_audit_log(admin_user_id,action,target_type,target_id) VALUES($1,'CANCEL_JOB','JOB',$2)",[user.id,adminDelete[1]]);return json({ok:true});}
  return json({error:"Not found"},404);
}

export default { async fetch(request,env){if(request.method==="OPTIONS")return withCors(request,new Response(null,{status:204,headers:{"Access-Control-Allow-Methods":"GET,POST,PUT,PATCH,DELETE,OPTIONS","Access-Control-Allow-Headers":"content-type"}}),env);const path=new URL(request.url).pathname;try{return withCors(request,await withDb(env,async(db)=>{if(["/api/healthz","/api/health","/healthz"].includes(path)&&request.method==="GET"){const tables=await db.query("SELECT to_regclass('bluejob.users') users");return tables.rows[0].users?json({ok:true,service:"bluejob-api",database:"ready"}):json({ok:false,error:"Database schema is not migrated"},503);}if(["/api/readyz","/api/readiness"].includes(path)&&request.method==="GET"){const result=await db.query("SELECT to_regclass('bluejob.users') users,to_regclass('bluejob.sessions') sessions,to_regclass('bluejob.jobs') jobs");return Object.values(result.rows[0]).every(Boolean)?json({ok:true,database:"ready"}):json({ok:false,error:"Required tables are missing"},503);}if(path==="/api/public/platform"&&request.method==="GET")return json({name:"BlueJob",foundingPrice:"$15.99/month",membershipEnforced:env.MEMBERSHIP_ENFORCEMENT==="true"});const authResponse=await authRoute(request,env,db,path);if(authResponse)return authResponse;return applicationRoute(request,env,db,await loadSession(request,db),path);}),env);}catch(error){console.error("BlueJob request failed",error?.message||"Unknown error");return withCors(request,json({error:"Service temporarily unavailable"},503),env);}} };
