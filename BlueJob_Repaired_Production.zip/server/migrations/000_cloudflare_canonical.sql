CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  display_name text NOT NULL,
  onboarding_path text CHECK (onboarding_path IS NULL OR onboarding_path IN ('WORKER','CONTRACTOR')),
  email_verified boolean NOT NULL DEFAULT false,
  phone text,
  phone_verified boolean NOT NULL DEFAULT false,
  mfa_secret text,
  mfa_enabled boolean NOT NULL DEFAULT false,
  membership_status text NOT NULL DEFAULT 'TRIAL'
    CHECK (membership_status IN ('NONE','TRIAL','ACTIVE','PAST_DUE','CANCELED','COMPED')),
  force_password_change boolean NOT NULL DEFAULT false,
  work_score integer CHECK (work_score IS NULL OR work_score BETWEEN 300 AND 900),
  work_score_rating_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Reconcile earlier BlueJob prototypes without deleting existing users.
ALTER TABLE users ADD COLUMN IF NOT EXISTS display_name text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS onboarding_path text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone_verified boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS mfa_secret text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS mfa_enabled boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS membership_status text NOT NULL DEFAULT 'TRIAL';
ALTER TABLE users ADD COLUMN IF NOT EXISTS force_password_change boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS work_score integer;
ALTER TABLE users ADD COLUMN IF NOT EXISTS work_score_rating_count integer NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE users ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema=current_schema() AND table_name='users' AND column_name='name') THEN
    EXECUTE 'UPDATE users SET display_name=COALESCE(display_name,NULLIF(name,'''') ,split_part(email,''@'',1))';
    EXECUTE 'ALTER TABLE users ALTER COLUMN name DROP NOT NULL';
  ELSIF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema=current_schema() AND table_name='users' AND column_name='full_name') THEN
    EXECUTE 'UPDATE users SET display_name=COALESCE(display_name,NULLIF(full_name,'''') ,split_part(email,''@'',1))';
    EXECUTE 'ALTER TABLE users ALTER COLUMN full_name DROP NOT NULL';
  ELSE
    UPDATE users SET display_name=COALESCE(display_name,split_part(email,'@',1),'BlueJob Member');
  END IF;
END $$;

ALTER TABLE users ALTER COLUMN display_name SET NOT NULL;

CREATE TABLE IF NOT EXISTS roles (
  id smallserial PRIMARY KEY,
  name text UNIQUE NOT NULL CHECK (name IN ('USER','WORKER','CONTRACTOR','ADMIN','SUPER_ADMIN'))
);
INSERT INTO roles(name) VALUES ('USER'),('WORKER'),('CONTRACTOR'),('ADMIN'),('SUPER_ADMIN')
ON CONFLICT (name) DO NOTHING;

CREATE TABLE IF NOT EXISTS user_roles (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id smallint NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  PRIMARY KEY(user_id,role_id)
);

ALTER TABLE user_roles ADD COLUMN IF NOT EXISTS role_id smallint REFERENCES roles(id) ON DELETE CASCADE;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema=current_schema() AND table_name='user_roles' AND column_name='role') THEN
    EXECUTE 'UPDATE user_roles ur SET role_id=r.id FROM roles r WHERE ur.role_id IS NULL AND r.name=ur.role';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema=current_schema() AND table_name='users' AND column_name='role') THEN
    EXECUTE $migrate$
      INSERT INTO user_roles(user_id,role_id)
      SELECT u.id,r.id FROM users u JOIN roles r ON r.name=CASE WHEN u.role='SUPER_ADMIN' THEN 'SUPER_ADMIN' WHEN u.role='ADMIN' THEN 'ADMIN' WHEN u.role='CONTRACTOR' THEN 'CONTRACTOR' ELSE 'WORKER' END
      ON CONFLICT DO NOTHING
    $migrate$;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text UNIQUE NOT NULL,
  mfa_verified_at timestamptz,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions(user_id);
CREATE INDEX IF NOT EXISTS sessions_token_idx ON sessions(token_hash);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text UNIQUE NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS password_reset_tokens_user_idx ON password_reset_tokens(user_id);

CREATE TABLE IF NOT EXISTS verification_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('EMAIL','PHONE')),
  target text NOT NULL,
  code_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  consumed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS mfa_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text UNIQUE NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE,
  created_by uuid NOT NULL REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS company_memberships (
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'OWNER' CHECK (role IN ('MEMBER','ADMIN','OWNER')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(company_id,user_id)
);

CREATE TABLE IF NOT EXISTS work_passports (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  trade text,
  skills jsonb NOT NULL DEFAULT '[]'::jsonb,
  years_experience numeric(5,2),
  service_area text,
  profile_summary text,
  travel_radius integer CHECK (travel_radius IS NULL OR travel_radius >= 0),
  worker_type text,
  crew_size integer CHECK (crew_size IS NULL OR crew_size > 0),
  availability text,
  tools text,
  transportation text,
  verification_status text NOT NULL DEFAULT 'UNVERIFIED'
    CHECK (verification_status IN ('UNVERIFIED','PENDING','VERIFIED','REJECTED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS work_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL,
  company text,
  details text,
  dates text,
  started_on date,
  ended_on date,
  status text NOT NULL DEFAULT 'CLAIMED',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS work_history_user_idx ON work_history(user_id,created_at DESC);

CREATE TABLE IF NOT EXISTS evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type text NOT NULL,
  original_name text NOT NULL,
  stored_name text NOT NULL,
  mime_type text,
  size_bytes bigint,
  sha256 text,
  status text NOT NULL DEFAULT 'PENDING',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  submitted_at timestamptz NOT NULL DEFAULT now(),
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE evidence ADD COLUMN IF NOT EXISTS original_name text;
ALTER TABLE evidence ADD COLUMN IF NOT EXISTS stored_name text;
ALTER TABLE evidence ADD COLUMN IF NOT EXISTS mime_type text;
ALTER TABLE evidence ADD COLUMN IF NOT EXISTS size_bytes bigint;
ALTER TABLE evidence ADD COLUMN IF NOT EXISTS sha256 text;
ALTER TABLE evidence ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE evidence ADD COLUMN IF NOT EXISTS submitted_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE evidence ADD COLUMN IF NOT EXISTS reviewed_at timestamptz;
ALTER TABLE evidence ADD COLUMN IF NOT EXISTS reviewed_by uuid REFERENCES users(id);

CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES users(id),
  company_id uuid REFERENCES companies(id),
  created_by uuid NOT NULL REFERENCES users(id),
  title text NOT NULL,
  trade text NOT NULL DEFAULT 'General Construction',
  description text NOT NULL,
  location text,
  budget numeric(12,2) NOT NULL CHECK (budget > 0),
  budget_type text NOT NULL DEFAULT 'FIXED',
  desired_start_date date,
  estimated_duration text,
  requirements jsonb NOT NULL DEFAULT '[]'::jsonb,
  verification_requirements jsonb NOT NULL DEFAULT '[]'::jsonb,
  minimum_work_score integer,
  status text NOT NULL DEFAULT 'OPEN',
  response_signal text NOT NULL DEFAULT 'INSUFFICIENT_DATA',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE jobs ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES companies(id);
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES users(id);
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS trade text NOT NULL DEFAULT 'General Construction';
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS budget_type text NOT NULL DEFAULT 'FIXED';
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS desired_start_date date;
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS estimated_duration text;
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS requirements jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS verification_requirements jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS minimum_work_score integer;
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS response_signal text NOT NULL DEFAULT 'INSUFFICIENT_DATA';
UPDATE jobs SET created_by=owner_id WHERE created_by IS NULL;
CREATE INDEX IF NOT EXISTS jobs_status_idx ON jobs(status,created_at DESC);

CREATE TABLE IF NOT EXISTS bids (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  bidder_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  worker_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount numeric(12,2) NOT NULL CHECK (amount > 0),
  message text NOT NULL DEFAULT '',
  estimated_duration text,
  status text NOT NULL DEFAULT 'PENDING',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(job_id,worker_id)
);

ALTER TABLE bids ADD COLUMN IF NOT EXISTS bidder_id uuid REFERENCES users(id);
ALTER TABLE bids ADD COLUMN IF NOT EXISTS worker_id uuid REFERENCES users(id);
ALTER TABLE bids ADD COLUMN IF NOT EXISTS estimated_duration text;
UPDATE bids SET worker_id=COALESCE(worker_id,bidder_id), bidder_id=COALESCE(bidder_id,worker_id);
CREATE UNIQUE INDEX IF NOT EXISTS bids_job_worker_idx ON bids(job_id,worker_id);

CREATE TABLE IF NOT EXISTS job_awards (
  job_id uuid PRIMARY KEY REFERENCES jobs(id) ON DELETE CASCADE,
  bid_id uuid UNIQUE NOT NULL REFERENCES bids(id) ON DELETE CASCADE,
  awarded_by uuid NOT NULL REFERENCES users(id),
  awarded_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS job_completions (
  job_id uuid PRIMARY KEY REFERENCES jobs(id) ON DELETE CASCADE,
  worker_confirmed_at timestamptz,
  contractor_confirmed_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS job_ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  rated_by_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rated_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rater_role text NOT NULL CHECK (rater_role IN ('CONTRACTOR','WORKER')),
  showed_up_as_agreed smallint NOT NULL CHECK (showed_up_as_agreed BETWEEN 1 AND 5),
  completed_agreed_scope smallint NOT NULL CHECK (completed_agreed_scope BETWEEN 1 AND 5),
  quality_right_first_time smallint NOT NULL CHECK (quality_right_first_time BETWEEN 1 AND 5),
  stayed_on_schedule smallint NOT NULL CHECK (stayed_on_schedule BETWEEN 1 AND 5),
  communicated_early smallint NOT NULL CHECK (communicated_early BETWEEN 1 AND 5),
  handled_changes_fairly smallint NOT NULL CHECK (handled_changes_fairly BETWEEN 1 AND 5),
  respected_agreed_budget smallint NOT NULL CHECK (respected_agreed_budget BETWEEN 1 AND 5),
  professional_and_reliable smallint NOT NULL CHECK (professional_and_reliable BETWEEN 1 AND 5),
  trust_with_larger_job smallint NOT NULL CHECK (trust_with_larger_job BETWEEN 1 AND 5),
  work_together_again smallint NOT NULL CHECK (work_together_again BETWEEN 1 AND 5),
  private_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(job_id,rated_by_user_id),
  CHECK (rated_by_user_id <> rated_user_id)
);

CREATE TABLE IF NOT EXISTS work_score_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  score integer NOT NULL CHECK (score BETWEEN 300 AND 900),
  rating_count integer NOT NULL,
  explanation jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS work_score_events_user_idx ON work_score_events(user_id,created_at DESC);

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS payload jsonb NOT NULL DEFAULT '{}'::jsonb;

CREATE TABLE IF NOT EXISTS disputes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES jobs(id) ON DELETE SET NULL,
  opened_by uuid NOT NULL REFERENCES users(id),
  category text NOT NULL DEFAULT 'OTHER',
  summary text NOT NULL,
  status text NOT NULL DEFAULT 'OPEN',
  resolution text,
  resolved_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);

CREATE TABLE IF NOT EXISTS billing_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider_customer_id text,
  provider_subscription_id text UNIQUE,
  status text NOT NULL,
  current_period_end timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS billing_events (
  stripe_event_id text PRIMARY KEY,
  event_type text NOT NULL,
  processed_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admin_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_user_id uuid NOT NULL REFERENCES users(id),
  action text NOT NULL,
  target_type text NOT NULL,
  target_id text,
  reason text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO users(email,password_hash,display_name,force_password_change,membership_status)
VALUES ('director@clearestway.org','!','BlueJob Director',true,'COMPED')
ON CONFLICT (email) DO UPDATE SET display_name=EXCLUDED.display_name,updated_at=now();

INSERT INTO user_roles(user_id,role_id)
SELECT u.id,r.id FROM users u CROSS JOIN roles r
WHERE u.email='director@clearestway.org' AND r.name IN ('ADMIN','SUPER_ADMIN')
ON CONFLICT DO NOTHING;
