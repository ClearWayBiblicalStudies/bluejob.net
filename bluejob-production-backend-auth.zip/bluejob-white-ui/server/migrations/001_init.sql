
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  username text UNIQUE,
  full_name text NOT NULL,
  password_hash text NOT NULL,
  status text NOT NULL DEFAULT 'ACTIVE'
    CHECK (status IN ('ACTIVE','SUSPENDED','DISABLED')),
  email_verified_at timestamptz,
  must_change_password boolean NOT NULL DEFAULT false,
  onboarding_path text
    CHECK (onboarding_path IS NULL OR onboarding_path IN ('WORKER','CONTRACTOR')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_roles (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN (
    'USER','WORKER','CONTRACTOR','ORGANIZATION_MEMBER','ORGANIZATION_ADMIN',
    'ORGANIZATION_OWNER','VERIFICATION_REVIEWER','BLUEJOB_ADMIN','SUPER_ADMIN'
  )),
  PRIMARY KEY(user_id, role)
);

CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text UNIQUE NOT NULL,
  user_agent text,
  ip_address inet,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text UNIQUE NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_name text NOT NULL,
  display_name text NOT NULL,
  slug text UNIQUE NOT NULL,
  verification_status text NOT NULL DEFAULT 'PENDING'
    CHECK (verification_status IN ('PENDING','VERIFIED','REJECTED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS organization_memberships (
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('MEMBER','ADMIN','OWNER')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(organization_id, user_id)
);

CREATE TABLE IF NOT EXISTS work_passports (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  display_name text,
  city text,
  state text,
  travel_radius integer NOT NULL DEFAULT 25 CHECK (travel_radius >= 0),
  primary_trade text,
  worker_type text CHECK (worker_type IS NULL OR worker_type IN ('INDIVIDUAL','SUBCONTRACTOR','CREW')),
  crew_size integer NOT NULL DEFAULT 1 CHECK (crew_size > 0),
  years_experience numeric(5,2),
  has_tools boolean NOT NULL DEFAULT false,
  has_transportation boolean NOT NULL DEFAULT false,
  availability text NOT NULL DEFAULT 'AVAILABLE'
    CHECK (availability IN ('AVAILABLE','LIMITED','UNAVAILABLE')),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name text NOT NULL,
  verification_status text NOT NULL DEFAULT 'SELF_REPORTED'
    CHECK (verification_status IN ('SELF_REPORTED','PENDING','VERIFIED','REJECTED')),
  UNIQUE(user_id, name)
);

CREATE TABLE IF NOT EXISTS work_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  company text NOT NULL,
  role text NOT NULL,
  start_date date,
  end_date date,
  location text,
  responsibilities text,
  project_type text,
  project_value_cents bigint,
  verification_status text NOT NULL DEFAULT 'CLAIMED'
    CHECK (verification_status IN ('CLAIMED','PENDING','VERIFIED','REJECTED')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  work_history_id uuid REFERENCES work_history(id) ON DELETE SET NULL,
  type text NOT NULL,
  title text NOT NULL,
  organization text,
  trade text,
  notes text,
  source text NOT NULL DEFAULT 'USER_SUBMISSION',
  status text NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING','VERIFIED','REJECTED','NEEDS_INFO')),
  reviewer_id uuid REFERENCES users(id) ON DELETE SET NULL,
  reviewer_notes text,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS private_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  evidence_id uuid NOT NULL REFERENCES evidence(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  original_name text NOT NULL,
  mime_type text NOT NULL,
  byte_size bigint NOT NULL,
  encrypted_path text NOT NULL,
  iv_base64 text NOT NULL,
  auth_tag_base64 text NOT NULL,
  sha256 text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_private_files_evidence ON private_files(evidence_id);

CREATE TABLE IF NOT EXISTS work_score_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  score integer,
  status text NOT NULL CHECK (status IN ('BUILDING','ACTIVE')),
  reliability integer,
  completion integer,
  experience integer,
  repeat_trust integer,
  compliance integer,
  evidence_strength integer NOT NULL DEFAULT 0,
  model_version text NOT NULL,
  explanation jsonb NOT NULL DEFAULT '{}'::jsonb,
  calculated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_score_user_time ON work_score_snapshots(user_id, calculated_at DESC);

CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  created_by uuid NOT NULL REFERENCES users(id),
  title text NOT NULL,
  description text NOT NULL,
  trade text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  budget_min_cents bigint,
  budget_max_cents bigint,
  max_budget_cents bigint,
  start_date date,
  duration_days integer,
  workers_needed integer,
  minimum_work_score integer,
  status text NOT NULL DEFAULT 'DRAFT'
    CHECK (status IN ('DRAFT','OPEN','MATCHING','AWARDED','SCHEDULED','IN_PROGRESS','COMPLETED','CANCELLED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_jobs_status_trade ON jobs(status, trade);

CREATE TABLE IF NOT EXISTS bids (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  bidder_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount_cents bigint NOT NULL CHECK (amount_cents > 0),
  proposed_start_date date,
  estimated_days integer,
  message text,
  status text NOT NULL DEFAULT 'SUBMITTED'
    CHECK (status IN ('SUBMITTED','VIEWED','SHORTLISTED','DECLINED','WITHDRAWN','AWARDED')),
  submitted_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(job_id, bidder_id)
);

CREATE TABLE IF NOT EXISTS job_completions (
  job_id uuid PRIMARY KEY REFERENCES jobs(id) ON DELETE CASCADE,
  worker_confirmed_at timestamptz,
  contractor_confirmed_at timestamptz,
  completed_at timestamptz,
  amount_paid_cents bigint,
  on_time boolean,
  callback_required boolean,
  dispute_open boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS disputes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES jobs(id) ON DELETE SET NULL,
  opened_by uuid NOT NULL REFERENCES users(id),
  against_user_id uuid REFERENCES users(id),
  status text NOT NULL DEFAULT 'OPEN'
    CHECK (status IN ('OPEN','UNDER_REVIEW','RESOLVED','DISMISSED')),
  category text NOT NULL,
  summary text NOT NULL,
  resolution text,
  resolved_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);

CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  organization_id uuid REFERENCES organizations(id) ON DELETE CASCADE,
  plan_code text NOT NULL,
  status text NOT NULL CHECK (status IN ('TRIAL','PENDING_PAYMENT','ACTIVE','PAST_DUE','CANCELED','SUSPENDED')),
  price_cents integer NOT NULL,
  provider_customer_id text,
  provider_subscription_id text,
  current_period_end timestamptz,
  founding_member boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_log (
  id bigserial PRIMARY KEY,
  actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip_address inet,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at DESC);
