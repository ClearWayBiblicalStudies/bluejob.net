import { Router } from 'express';
import { query, tx } from '../lib/db.js';
import { requireAuth } from '../lib/auth.js';
import { audit } from '../lib/audit.js';

const router = Router();
router.use(requireAuth);

router.get('/', async (req, res, next) => {
  try {
    const [passport, skills, history, latestScore] = await Promise.all([
      query(`SELECT * FROM work_passports WHERE user_id=$1`, [req.user.id]),
      query(`SELECT id,name,verification_status FROM skills WHERE user_id=$1 ORDER BY name`, [req.user.id]),
      query(`SELECT * FROM work_history WHERE user_id=$1 ORDER BY start_date DESC NULLS LAST, created_at DESC`, [req.user.id]),
      query(`SELECT * FROM work_score_snapshots WHERE user_id=$1 ORDER BY calculated_at DESC LIMIT 1`, [req.user.id])
    ]);
    res.json({
      passport: passport.rows[0] || null,
      skills: skills.rows,
      workHistory: history.rows,
      workScore: latestScore.rows[0] || { status: 'BUILDING', score: null }
    });
  } catch (e) { next(e); }
});

router.put('/', async (req, res, next) => {
  try {
    const p = req.body || {};
    const row = await query(
      `INSERT INTO work_passports(
        user_id,display_name,city,state,travel_radius,primary_trade,worker_type,crew_size,
        years_experience,has_tools,has_transportation,availability,updated_at
      ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,now())
      ON CONFLICT(user_id) DO UPDATE SET
        display_name=EXCLUDED.display_name,city=EXCLUDED.city,state=EXCLUDED.state,
        travel_radius=EXCLUDED.travel_radius,primary_trade=EXCLUDED.primary_trade,
        worker_type=EXCLUDED.worker_type,crew_size=EXCLUDED.crew_size,
        years_experience=EXCLUDED.years_experience,has_tools=EXCLUDED.has_tools,
        has_transportation=EXCLUDED.has_transportation,availability=EXCLUDED.availability,updated_at=now()
      RETURNING *`,
      [
        req.user.id, p.displayName || null, p.city || null, p.state || null, Number(p.travelRadius ?? 25),
        p.primaryTrade || null, p.workerType || null, Number(p.crewSize ?? 1),
        p.yearsExperience === '' || p.yearsExperience == null ? null : Number(p.yearsExperience),
        Boolean(p.hasTools), Boolean(p.hasTransportation), p.availability || 'AVAILABLE'
      ]
    );

    if (Array.isArray(p.skills)) {
      await tx(async client => {
        await client.query(`DELETE FROM skills WHERE user_id=$1 AND verification_status='SELF_REPORTED'`, [req.user.id]);
        for (const name of p.skills) {
          if (String(name).trim()) {
            await client.query(
              `INSERT INTO skills(user_id,name) VALUES($1,$2) ON CONFLICT(user_id,name) DO NOTHING`,
              [req.user.id, String(name).trim()]
            );
          }
        }
      });
    }
    await audit(req, 'PASSPORT_UPDATED', 'work_passport', req.user.id);
    res.json({ passport: row.rows[0] });
  } catch (e) { next(e); }
});

router.post('/history', async (req, res, next) => {
  try {
    const h = req.body || {};
    if (!h.company || !h.role) return res.status(400).json({ error: 'Company and position/trade are required' });
    const result = await query(
      `INSERT INTO work_history(
        user_id,company,role,start_date,end_date,location,responsibilities,project_type,project_value_cents
      ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [
        req.user.id, h.company, h.role, h.startDate || null, h.endDate || null, h.location || null,
        h.responsibilities || null, h.projectType || null,
        h.projectValueCents == null ? null : Number(h.projectValueCents)
      ]
    );
    await audit(req, 'WORK_HISTORY_ADDED', 'work_history', result.rows[0].id);
    res.status(201).json({ workHistory: result.rows[0] });
  } catch (e) { next(e); }
});

export default router;