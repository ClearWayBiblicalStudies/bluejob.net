import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import authRoutes from './routes/auth.js';
import passportRoutes from './routes/passport.js';
import evidenceRoutes from './routes/evidence.js';
import marketplaceRoutes from './routes/marketplace.js';
import adminRoutes from './routes/admin.js';

const app = express();
app.set('trust proxy', 1);
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'same-site' }
}));
app.use(cors({
  origin: process.env.APP_ORIGIN || 'http://localhost:5173',
  credentials: true,
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS']
}));
app.use(express.json({ limit: '1mb' }));

// Basic same-origin protection for cookie-authenticated mutations.
app.use((req, res, next) => {
  if (['GET','HEAD','OPTIONS'].includes(req.method)) return next();
  const origin = req.headers.origin;
  const allowed = process.env.APP_ORIGIN;
  if (allowed && origin && origin !== allowed) {
    return res.status(403).json({ error: 'Origin not allowed' });
  }
  next();
});

app.get('/api/healthz', (_req, res) => res.json({ ok: true, service: 'bluejob-api' }));
app.use('/api/auth', authRoutes);
app.use('/api/passport', passportRoutes);
app.use('/api/evidence', evidenceRoutes);
app.use('/api/marketplace', marketplaceRoutes);
app.use('/api/admin', adminRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  const message = process.env.NODE_ENV === 'production' ? 'Request failed' : err.message;
  res.status(err.status || 500).json({ error: message });
});

const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`BlueJob API listening on :${port}`));