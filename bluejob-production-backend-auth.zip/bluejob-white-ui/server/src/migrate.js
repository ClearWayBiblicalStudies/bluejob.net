import fs from 'node:fs/promises';
import path from 'node:path';
import { pool } from './lib/db.js';

const dir = new URL('../migrations/', import.meta.url);
const names = (await fs.readdir(dir)).filter(n => n.endsWith('.sql')).sort();

await pool.query(`CREATE TABLE IF NOT EXISTS schema_migrations(name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`);

for (const name of names) {
  const done = await pool.query(`SELECT 1 FROM schema_migrations WHERE name=$1`, [name]);
  if (done.rowCount) continue;
  const sql = await fs.readFile(new URL(name, dir), 'utf8');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(sql);
    await client.query(`INSERT INTO schema_migrations(name) VALUES($1)`, [name]);
    await client.query('COMMIT');
    console.log(`Applied ${name}`);
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}
await pool.end();