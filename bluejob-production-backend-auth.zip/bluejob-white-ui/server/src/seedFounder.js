import { pool } from './lib/db.js';
import { hashPassword } from './lib/security.js';

const displayName = process.env.FOUNDER_DISPLAY_NAME || 'Austin Alfonsi';
const username = process.env.FOUNDER_USERNAME || 'Chrome Construction';
const email = process.env.FOUNDER_EMAIL;
const tempPassword = process.env.FOUNDER_TEMP_PASSWORD;

if (!email || !tempPassword) {
  throw new Error('FOUNDER_EMAIL and FOUNDER_TEMP_PASSWORD must be set in the environment');
}

const client = await pool.connect();
try {
  await client.query('BEGIN');
  const passwordHash = await hashPassword(tempPassword);
  const created = await client.query(
    `INSERT INTO users(email,username,full_name,password_hash,must_change_password,email_verified_at)
     VALUES($1,$2,$3,$4,true,now())
     ON CONFLICT(email) DO UPDATE SET username=EXCLUDED.username,full_name=EXCLUDED.full_name
     RETURNING id`,
    [email.toLowerCase(), username, displayName, passwordHash]
  );
  const userId = created.rows[0].id;

  for (const role of ['USER','WORKER','CONTRACTOR','ORGANIZATION_OWNER','BLUEJOB_ADMIN','SUPER_ADMIN']) {
    await client.query(`INSERT INTO user_roles(user_id,role) VALUES($1,$2) ON CONFLICT DO NOTHING`, [userId, role]);
  }
  await client.query(`INSERT INTO work_passports(user_id,display_name) VALUES($1,$2) ON CONFLICT(user_id) DO NOTHING`, [userId, displayName]);

  const companies = [
    ['Chrome Construction', 'chrome-construction'],
    ['Gulfside Improvements', 'gulfside-improvements']
  ];
  for (const [name, slug] of companies) {
    const org = await client.query(
      `INSERT INTO organizations(legal_name,display_name,slug)
       VALUES($1,$1,$2) ON CONFLICT(slug) DO UPDATE SET display_name=EXCLUDED.display_name
       RETURNING id`,
      [name, slug]
    );
    await client.query(
      `INSERT INTO organization_memberships(organization_id,user_id,role)
       VALUES($1,$2,'OWNER') ON CONFLICT(organization_id,user_id) DO UPDATE SET role='OWNER'`,
      [org.rows[0].id, userId]
    );
  }

  await client.query('COMMIT');
  console.log('Founder account and initial organizations are ready.');
  console.log('The founder is required to change the temporary password on first activation.');
} catch (e) {
  await client.query('ROLLBACK');
  throw e;
} finally {
  client.release();
  await pool.end();
}