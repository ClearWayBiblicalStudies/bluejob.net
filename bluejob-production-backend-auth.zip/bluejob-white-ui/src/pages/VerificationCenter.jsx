import { useEffect, useMemo, useState } from 'react';
import { FileCheck2, LockKeyhole, UploadCloud } from 'lucide-react';
import AppShell from '../components/AppShell';
import VerificationBadge from '../components/VerificationBadge';
import { api } from '../lib/api';

const evidenceTypes = [
  ['EMPLOYMENT', 'Employment Record / W-2 / 1099'], ['PAY_STUB', 'Pay Stub'],
  ['CONTRACT', 'Contract / Work Order'], ['INVOICE', 'Invoice'], ['PAYMENT', 'Payment Record'],
  ['EMPLOYER_CONFIRMATION', 'Employer / Contractor Confirmation'], ['LICENSE', 'License'],
  ['CERTIFICATION', 'Certification'], ['INSURANCE', 'Insurance'], ['PROJECT_PHOTO', 'Project Photos'], ['OTHER', 'Other Approved Evidence'],
];

export default function VerificationCenter() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ type: 'EMPLOYMENT', title: '', organization: '', trade: '', notes: '' });
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');

  async function refresh() {
    const data = await api('/evidence');
    setItems(data.evidence || []);
  }
  useEffect(() => { refresh().catch(e => setMessage(e.message)); }, []);

  const pending = useMemo(() => items.filter(x => x.status === 'PENDING' || x.status === 'NEEDS_INFO').length, [items]);

  async function submit(e) {
    e.preventDefault();
    setMessage('');
    const body = new FormData();
    Object.entries(form).forEach(([k,v]) => body.append(k, v));
    if (file) body.append('file', file);
    try {
      await api('/evidence', { method: 'POST', body });
      setForm({ type: 'EMPLOYMENT', title: '', organization: '', trade: '', notes: '' });
      setFile(null);
      setMessage('Evidence submitted for review.');
      await refresh();
    } catch (e) { setMessage(e.message); }
  }

  return (
    <AppShell active="passport">
      <div className="page-heading">
        <div><span className="kicker">VERIFICATION CENTER</span><h1>Turn work history into verified proof.</h1><p>Supporting records are uploaded privately and routed to BlueJob verification. Public profiles receive the result, not the document.</p></div>
        <div className="verification-count"><strong>{pending}</strong><span>Pending review</span></div>
      </div>
      {message && <div className={message.includes('submitted') ? 'form-success' : 'form-error'}>{message}</div>}

      <div className="verification-layout">
        <section className="card form-section">
          <div className="section-title"><div><span className="kicker">SUBMIT EVIDENCE</span><h2>Add proof of experience</h2></div><UploadCloud size={22}/></div>
          <form onSubmit={submit}>
            <div className="form-grid two">
              <label>Evidence type<select value={form.type} onChange={e => setForm(f => ({...f,type:e.target.value}))}>{evidenceTypes.map(([v,l]) => <option key={v} value={v}>{l}</option>)}</select></label>
              <label>Title / description<input value={form.title} onChange={e => setForm(f => ({...f,title:e.target.value}))} required/></label>
              <label>Company / organization<input value={form.organization} onChange={e => setForm(f => ({...f,organization:e.target.value}))}/></label>
              <label>Trade<input value={form.trade} onChange={e => setForm(f => ({...f,trade:e.target.value}))}/></label>
              <label className="span-two">Notes<textarea rows="3" value={form.notes} onChange={e => setForm(f => ({...f,notes:e.target.value}))}/></label>
              <label className="span-two file-drop">
                <input type="file" accept=".pdf,.jpg,.jpeg,.png,.webp" onChange={e => setFile(e.target.files?.[0] || null)}/>
                <FileCheck2 size={22}/><strong>{file?.name || 'Choose supporting document'}</strong><span>PDF, JPG, PNG or WEBP · max 10 MB</span>
              </label>
            </div>
            <button className="button button-primary" type="submit">Submit for Verification</button>
          </form>
        </section>

        <aside className="card privacy-panel">
          <LockKeyhole size={25}/><span className="kicker">PRIVATE BY DESIGN</span><h2>Your documents are not your public profile.</h2>
          <p>BlueJob encrypts uploaded evidence at rest. Only authorized verification personnel can access it through an audited admin route.</p>
          <div className="privacy-example"><span>Public result</span><strong>Employment Verified ✓</strong></div>
        </aside>
      </div>

      <section className="card admin-table-card">
        <div className="admin-table-head evidence-grid"><span>Evidence</span><span>Organization</span><span>Trade</span><span>Status</span><span>Submitted</span></div>
        {items.map(item => (
          <div className="admin-table-row evidence-grid" key={item.id}>
            <div><strong>{item.title}</strong><span>{item.original_name || item.type}</span></div>
            <span>{item.organization || '—'}</span><span>{item.trade || '—'}</span>
            <VerificationBadge status={item.status}/><span>{new Date(item.created_at).toLocaleDateString()}</span>
          </div>
        ))}
      </section>
    </AppShell>
  );
}