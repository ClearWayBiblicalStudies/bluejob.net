import AdminShell from '../../components/AdminShell';
import EmptyState from '../../components/EmptyState';

export default function AdminDisputes() {
  return (
    <AdminShell title="Disputes & Resolution" subtitle="Review job disputes, payment complaints, completion conflicts, callbacks, and evidence challenges.">
      <section className="card admin-panel">
        <EmptyState title="No open disputes" copy="Every future dispute should preserve both sides of the record, supporting evidence, timestamps, admin actions, and resolution history."/>
      </section>
    </AdminShell>
  );
}
