import { useEffect, useState } from 'react';
import { BadgeDollarSign, BriefcaseBusiness, Building2, FileCheck2, Scale, Users, WalletCards } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import AdminMetric from '../../components/AdminMetric';
import { api } from '../../lib/api';

export default function AdminOverview() {
  const [m, setM] = useState({ users:0, organizations:0, open_jobs:0, completed_jobs:0, verification_queue:0, disputes:0, active_subscriptions:0 });
  useEffect(() => { api('/admin/overview').then(d => setM(d.metrics)).catch(console.error); }, []);
  return (
    <AdminShell title="Operations Command Center" subtitle="Private control for BlueJob operations, verification, marketplace health, and growth.">
      <div className="admin-metric-grid">
        <AdminMetric label="Registered Users" value={m.users} detail="Real accounts" icon={Users}/>
        <AdminMetric label="Organizations" value={m.organizations} detail="Company workspaces" icon={Building2}/>
        <AdminMetric label="Open Jobs" value={m.open_jobs} detail="Marketplace opportunities" icon={BriefcaseBusiness}/>
        <AdminMetric label="Verification Queue" value={m.verification_queue} detail="Awaiting review" icon={FileCheck2}/>
        <AdminMetric label="Completed Jobs" value={m.completed_jobs} detail="Verified completed work" icon={BriefcaseBusiness}/>
        <AdminMetric label="Disputes" value={m.disputes} detail="Open cases" icon={Scale}/>
        <AdminMetric label="Subscriptions" value={m.active_subscriptions} detail="Active memberships" icon={WalletCards}/>
        <AdminMetric label="Verified Work Volume" value="—" detail="Connect completion/payments next" icon={BadgeDollarSign}/>
      </div>
    </AdminShell>
  );
}