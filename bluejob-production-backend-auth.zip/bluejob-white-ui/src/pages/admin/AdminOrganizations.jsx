import { Building2, Plus } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import { organizations } from '../../data/adminData';

export default function AdminOrganizations() {
  return (
    <AdminShell
      title="Organizations"
      subtitle="Company workspaces, owners, verification status, memberships, and job activity."
      actions={<button className="button button-primary"><Plus size={16}/> Add Organization</button>}
    >
      <div className="organization-grid">
        {organizations.map((org) => (
          <article className="card organization-card" key={org.id}>
            <div className="org-card-top">
              <div className="org-large-icon"><Building2 size={24}/></div>
              <span className="status-badge status-amber">{org.verification}</span>
            </div>
            <h2>{org.name}</h2>
            <p>{org.relationship} access · {org.activeMembers} active member</p>
            <div className="org-stats">
              <div><strong>{org.jobs}</strong><span>Jobs</span></div>
              <div><strong>{org.activeMembers}</strong><span>Members</span></div>
            </div>
            <button className="button button-outline button-full">Manage Organization</button>
          </article>
        ))}
      </div>
    </AdminShell>
  );
}
