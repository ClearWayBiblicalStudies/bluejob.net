import { Search, ShieldCheck } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import { founderUser } from '../../data/adminData';

export default function AdminUsers() {
  return (
    <AdminShell title="Users" subtitle="Manage user status, roles, Work Passports, account access, and platform permissions.">
      <div className="admin-toolbar card">
        <div className="search-box"><Search size={16}/><input placeholder="Search users by name, email, company, or ID"/></div>
        <button className="button button-outline">Filters</button>
      </div>

      <section className="card admin-table-card">
        <div className="admin-table-head users-table">
          <span>User</span><span>Roles</span><span>Work Score</span><span>Status</span><span>Action</span>
        </div>
        <div className="admin-table-row users-table">
          <div className="table-user">
            <div className="avatar">AA</div>
            <div><strong>{founderUser.name}</strong><span>{founderUser.username}</span></div>
          </div>
          <span><span className="status-badge status-blue"><ShieldCheck size={12}/> Super Admin</span></span>
          <strong>{founderUser.workScoreStatus}</strong>
          <span className="status-badge status-green">Active</span>
          <button className="button button-outline">View</button>
        </div>
      </section>
    </AdminShell>
  );
}
