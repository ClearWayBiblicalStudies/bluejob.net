import { LockKeyhole, Save, ShieldCheck } from 'lucide-react';
import AdminShell from '../../components/AdminShell';

export default function AdminSettings() {
  return (
    <AdminShell title="System Settings" subtitle="Private platform configuration. Production changes should be audited and enforced by backend permissions.">
      <div className="settings-grid">
        <section className="card settings-section">
          <div className="settings-icon"><ShieldCheck size={20}/></div>
          <h2>Administration</h2>
          <label>Founder username<input value="Chrome Construction" readOnly/></label>
          <label>Founder display name<input value="Austin Alfonsi" readOnly/></label>
          <label>Default admin role<input value="SUPER_ADMIN" readOnly/></label>
          <p className="settings-note">Passwords are never configured here or committed to source control.</p>
        </section>

        <section className="card settings-section">
          <div className="settings-icon"><LockKeyhole size={20}/></div>
          <h2>Security Requirements</h2>
          <label className="setting-toggle"><input type="checkbox" defaultChecked/> Require MFA for BlueJob administrators</label>
          <label className="setting-toggle"><input type="checkbox" defaultChecked/> Record privileged actions in audit log</label>
          <label className="setting-toggle"><input type="checkbox" defaultChecked/> Re-authenticate before destructive actions</label>
          <label className="setting-toggle"><input type="checkbox" defaultChecked/> Force password reset on initial founder activation</label>
          <button className="button button-primary"><Save size={15}/> Save Security Policy</button>
        </section>
      </div>
    </AdminShell>
  );
}
