import { Activity, BriefcaseBusiness, UserPlus, Users } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import AdminMetric from '../../components/AdminMetric';

export default function AdminAnalytics() {
  return (
    <AdminShell title="Growth & Analytics" subtitle="Track the marketplace by real user behavior, completed work, retention, coverage, and successful matches.">
      <div className="admin-metric-grid admin-metric-grid--3">
        <AdminMetric label="New Registrations" value="1" detail="Initial founder account" icon={UserPlus}/>
        <AdminMetric label="Jobs Completed" value="0" detail="Verified through BlueJob" icon={BriefcaseBusiness}/>
        <AdminMetric label="Returning Members" value="0" detail="Retention signal" icon={Users}/>
      </div>
      <section className="card analytics-placeholder">
        <Activity size={30}/>
        <h2>Analytics starts with real activity.</h2>
        <p>As BlueJob grows, this area should show registrations, subscription conversion, posted jobs, bid response, project coverage, match success, completion rate, verified work volume, Work Score distribution, and retention.</p>
      </section>
    </AdminShell>
  );
}
