import { BadgeDollarSign, CreditCard, Users } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import AdminMetric from '../../components/AdminMetric';

export default function AdminBilling() {
  return (
    <AdminShell title="Billing & Memberships" subtitle="Subscription status, founding memberships, failed payments, plan configuration, and revenue operations.">
      <div className="admin-metric-grid admin-metric-grid--3">
        <AdminMetric label="Active Members" value="0" detail="Paid memberships" icon={Users}/>
        <AdminMetric label="Monthly Recurring Revenue" value="$0" detail="Posted subscription revenue" icon={BadgeDollarSign}/>
        <AdminMetric label="Failed Payments" value="0" detail="Needs attention" icon={CreditCard}/>
      </div>
      <section className="card admin-panel">
        <div className="panel-heading"><div><span className="kicker">LAUNCH PLAN</span><h2>BlueJob Founding Membership</h2></div><span className="price-large">$15.99<span>/mo</span></span></div>
        <div className="detail-list">
          <div><span>Plan state</span><strong>Configured for launch</strong></div>
          <div><span>Future pricing</span><strong>Database/config driven</strong></div>
          <div><span>Card storage</span><strong>External payment provider only</strong></div>
          <div><span>Founding Member effect on Work Score</span><strong>None</strong></div>
        </div>
      </section>
    </AdminShell>
  );
}
