import { Plus } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import EmptyState from '../../components/EmptyState';

export default function AdminJobs() {
  return (
    <AdminShell
      title="Jobs"
      subtitle="Platform-wide job moderation, activity, bidding, awards, completions, and marketplace quality."
      actions={<button className="button button-primary"><Plus size={16}/> Post Chrome Construction Job</button>}
    >
      <div className="admin-status-tabs">
        <button className="active">All Jobs <span>0</span></button>
        <button>Open <span>0</span></button>
        <button>In Progress <span>0</span></button>
        <button>Completed <span>0</span></button>
        <button>Flagged <span>0</span></button>
      </div>
      <section className="card admin-panel">
        <EmptyState
          title="No jobs have been posted"
          copy="Chrome Construction or Gulfside Improvements can publish the first legitimate opportunities when you are ready. BlueJob should never manufacture fake marketplace inventory."
          action={<button className="button button-primary">Post First Job</button>}
        />
      </section>
    </AdminShell>
  );
}
