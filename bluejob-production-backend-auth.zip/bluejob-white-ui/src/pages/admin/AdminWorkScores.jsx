import { Gauge, LockKeyhole } from 'lucide-react';
import AdminShell from '../../components/AdminShell';

export default function AdminWorkScores() {
  return (
    <AdminShell title="Work Scores" subtitle="Audit score status, evidence strength, score versions, changes, and integrity controls.">
      <div className="score-admin-banner card">
        <div className="score-admin-icon"><LockKeyhole size={24}/></div>
        <div>
          <span className="kicker">SCORE INTEGRITY</span>
          <h2>Public Work Scores cannot be manually assigned.</h2>
          <p>Administrators may review evidence, resolve disputes, and invalidate fraudulent records. The scoring engine recalculates the result from verified evidence.</p>
        </div>
      </div>
      <section className="card admin-table-card">
        <div className="admin-table-head score-table"><span>Account</span><span>Score</span><span>Status</span><span>Evidence</span><span>Version</span></div>
        <div className="admin-table-row score-table">
          <div className="table-user"><div className="avatar">AA</div><div><strong>Austin Alfonsi</strong><span>Chrome Construction</span></div></div>
          <strong>—</strong>
          <span className="status-badge status-amber">BUILDING</span>
          <span>Insufficient verified evidence</span>
          <span>BJWS-0.2</span>
        </div>
      </section>
    </AdminShell>
  );
}
