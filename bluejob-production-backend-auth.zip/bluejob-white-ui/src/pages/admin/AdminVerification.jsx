import { useEffect, useState } from 'react';
import AdminShell from '../../components/AdminShell';
import VerificationBadge from '../../components/VerificationBadge';
import { api } from '../../lib/api';

export default function AdminVerification() {
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');

  async function refresh() {
    try { const d = await api('/evidence/admin/queue'); setItems(d.evidence || []); }
    catch (e) { setError(e.message); }
  }
  useEffect(() => { refresh(); }, []);

  async function review(id, status) {
    await api(`/evidence/admin/${id}/review`, { method:'POST', body:{ status } });
    await refresh();
  }

  return (
    <AdminShell title="Verification Queue" subtitle="Review work evidence and make verification decisions that feed Work Passport records and score recalculation.">
      {error && <div className="form-error">{error}</div>}
      <section className="card admin-table-card">
        <div className="admin-table-head verification-admin-grid"><span>Member</span><span>Evidence</span><span>Status</span><span>Document</span><span>Decision</span></div>
        {items.map(item => (
          <div className="admin-table-row verification-admin-grid" key={item.id}>
            <div><strong>{item.full_name}</strong><span>{item.email}</span></div>
            <div><strong>{item.title}</strong><span>{item.type} · {item.organization || 'No organization'}</span></div>
            <VerificationBadge status={item.status}/>
            <span>{item.file_id ? <a href={`${import.meta.env.VITE_API_BASE || 'http://localhost:4000/api'}/evidence/admin/file/${item.file_id}`} target="_blank">Open private file</a> : 'No file'}</span>
            <div className="review-actions">
              <button className="button button-primary" onClick={() => review(item.id,'VERIFIED')}>Verify</button>
              <button className="button button-outline" onClick={() => review(item.id,'NEEDS_INFO')}>Need Info</button>
              <button className="button button-danger" onClick={() => review(item.id,'REJECTED')}>Reject</button>
            </div>
          </div>
        ))}
        {!items.length && <div className="empty-state"><h3>Verification queue is clear.</h3><p>New private evidence submissions will appear here.</p></div>}
      </section>
    </AdminShell>
  );
}