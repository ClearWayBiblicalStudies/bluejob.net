import { useEffect, useState } from 'react';
import { BriefcaseBusiness, CheckCircle2, MapPin, ShieldCheck } from 'lucide-react';
import AppShell from '../components/AppShell';
import VerificationBadge from '../components/VerificationBadge';
import { api } from '../lib/api';

export default function WorkPassportPage() {
  const [data, setData] = useState({ passport: {}, skills: [], workHistory: [], workScore: { status:'BUILDING', score:null } });
  useEffect(() => { api('/passport').then(setData).catch(console.error); }, []);
  const p = data.passport || {};
  const verifiedHistory = data.workHistory.filter(h => h.verification_status === 'VERIFIED').length;

  return (
    <AppShell active="passport">
      <section className="passport-hero card">
        <div className="passport-avatar">{(p.display_name || 'BJ').slice(0,2).toUpperCase()}</div>
        <div className="passport-identity">
          <span className="kicker">BLUEJOB WORK PASSPORT</span><h1>{p.display_name || 'Complete your Work Passport'}</h1>
          <p><MapPin size={14}/> {p.city && p.state ? `${p.city}, ${p.state}` : 'Location not added'} · {p.primary_trade || 'Trade not added'}</p>
        </div>
        <div className="passport-score-box">
          <span>WORK SCORE</span><strong>{data.workScore?.status === 'ACTIVE' ? data.workScore.score : 'BUILDING'}</strong>
          <small>{data.workScore?.status === 'ACTIVE' ? data.workScore.model_version : 'Verified evidence required'}</small>
        </div>
      </section>

      <div className="passport-stats-grid">
        <article className="card passport-stat"><BriefcaseBusiness size={19}/><strong>{data.workHistory.length}</strong><span>Work history records</span></article>
        <article className="card passport-stat"><CheckCircle2 size={19}/><strong>{verifiedHistory}</strong><span>Verified work records</span></article>
        <article className="card passport-stat"><ShieldCheck size={19}/><strong>{data.skills.length}</strong><span>Skills listed</span></article>
        <article className="card passport-stat"><MapPin size={19}/><strong>{p.travel_radius || 0}</strong><span>Travel radius</span></article>
      </div>

      <div className="passport-columns">
        <section className="card passport-section">
          <div className="section-title"><div><span className="kicker">SKILLS</span><h2>Professional capabilities</h2></div></div>
          <div className="selected-skills">{data.skills.map(s => <span className="skill-pill" key={s.id}>{s.name} <VerificationBadge status={s.verification_status}/></span>)}</div>
        </section>
        <section className="card passport-section">
          <div className="section-title"><div><span className="kicker">WORK HISTORY</span><h2>Professional record</h2></div></div>
          <div className="history-list">{data.workHistory.map(item => <div className="history-card" key={item.id}><div><strong>{item.role}</strong><span>{item.company}</span></div><VerificationBadge status={item.verification_status}/></div>)}</div>
        </section>
      </div>
    </AppShell>
  );
}