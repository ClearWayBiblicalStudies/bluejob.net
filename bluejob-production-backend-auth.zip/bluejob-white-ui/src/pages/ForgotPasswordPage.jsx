import { useState } from 'react';
import { Link } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  async function submit(e) {
    e.preventDefault();
    await api('/auth/request-password-reset', { method: 'POST', body: { email } });
    setSent(true);
  }
  return (
    <div className="auth-page">
      <div className="auth-top"><Logo /></div>
      <div className="auth-card white-card">
        <h1>Reset your password</h1>
        <p>Enter the email attached to your BlueJob account.</p>
        {sent ? <div className="form-success">If that account exists, reset instructions have been sent.</div> : (
          <form onSubmit={submit}>
            <label>Email<input type="email" value={email} onChange={e => setEmail(e.target.value)} required /></label>
            <button className="button button-primary button-full button-lg">Send Reset Instructions</button>
          </form>
        )}
        <small><Link to="/signin">Return to sign in</Link></small>
      </div>
    </div>
  );
}