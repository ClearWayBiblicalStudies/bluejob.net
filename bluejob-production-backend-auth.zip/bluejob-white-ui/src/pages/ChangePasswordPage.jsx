import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from '../components/Logo';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';

export default function ChangePasswordPage() {
  const navigate = useNavigate();
  const { signOut } = useAuth();
  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError('');
    if (form.newPassword.length < 12) return setError('New password must be at least 12 characters.');
    if (form.newPassword !== form.confirm) return setError('New passwords do not match.');
    setSaving(true);
    try {
      await api('/auth/change-password', {
        method: 'POST',
        body: { currentPassword: form.currentPassword, newPassword: form.newPassword }
      });
      await signOut().catch(() => {});
      navigate('/signin', { replace: true, state: { passwordChanged: true } });
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-top"><Logo /></div>
      <div className="auth-card white-card">
        <span className="kicker">SECURITY REQUIRED</span>
        <h1>Create your private BlueJob password.</h1>
        <p>Your temporary founder password cannot be used after activation.</p>
        {error && <div className="form-error">{error}</div>}
        <form onSubmit={submit}>
          <label>Temporary/current password<input type="password" value={form.currentPassword} onChange={e => setForm(f => ({...f,currentPassword:e.target.value}))} autoComplete="current-password" required /></label>
          <label>New password<input type="password" value={form.newPassword} onChange={e => setForm(f => ({...f,newPassword:e.target.value}))} autoComplete="new-password" required /></label>
          <label>Confirm new password<input type="password" value={form.confirm} onChange={e => setForm(f => ({...f,confirm:e.target.value}))} autoComplete="new-password" required /></label>
          <button className="button button-primary button-full button-lg" disabled={saving}>{saving ? 'Updating…' : 'Set New Password'}</button>
        </form>
      </div>
    </div>
  );
}