export default function AdminMetric({ label, value, detail, icon: Icon, tone = 'blue' }) {
  return (
    <article className="card admin-metric">
      <div className={`admin-metric-icon tone-${tone}`}>{Icon && <Icon size={18}/>}</div>
      <div>
        <span>{label}</span>
        <strong>{value}</strong>
        {detail && <small>{detail}</small>}
      </div>
    </article>
  );
}
