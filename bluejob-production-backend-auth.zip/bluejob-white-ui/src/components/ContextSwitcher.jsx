import { Building2, ChevronDown, HardHat, ShieldCheck, UserRound } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';

export default function ContextSwitcher({ compact = false }) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [organizations, setOrganizations] = useState([]);

  useEffect(() => {
    if (!user) return;
    api('/marketplace/organizations').then(d => setOrganizations(d.organizations || [])).catch(() => {});
  }, [user]);

  const contexts = useMemo(() => {
    const items = [
      { id: 'PERSONAL', label: 'Personal Work Passport', detail: user?.fullName || 'Personal', icon: UserRound, to: '/app/worker' }
    ];
    for (const org of organizations) {
      items.push({
        id: `ORG:${org.id}`,
        label: org.display_name,
        detail: `${org.role} workspace`,
        icon: org.slug === 'chrome-construction' ? HardHat : Building2,
        to: '/app/contractor'
      });
    }
    if (user?.roles?.includes('SUPER_ADMIN') || user?.roles?.includes('BLUEJOB_ADMIN')) {
      items.push({ id: 'BLUEJOB_ADMIN', label: 'BlueJob Administration', detail: 'Private administration', icon: ShieldCheck, to: '/admin' });
    }
    return items;
  }, [organizations, user]);

  const current = contexts[0];
  const Icon = current?.icon || UserRound;

  function changeContext(event) {
    const next = contexts.find(item => item.id === event.target.value);
    if (next) navigate(next.to);
  }

  if (!user) return null;

  return (
    <div className={`context-switcher ${compact ? 'context-switcher--compact' : ''}`}>
      <div className="context-switcher-icon"><Icon size={16} /></div>
      <div className="context-switcher-copy"><span>Workspace</span><strong>{current.label}</strong></div>
      <select aria-label="Switch BlueJob workspace" value={current.id} onChange={changeContext}>
        {contexts.map(item => <option key={item.id} value={item.id}>{item.label} — {item.detail}</option>)}
      </select>
      <ChevronDown size={14} />
    </div>
  );
}