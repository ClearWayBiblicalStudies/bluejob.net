import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function AdminRoute() {
  const { user, loading } = useAuth();

  if (loading) return <div className="route-loading">Checking permissions…</div>;
  if (!user) return <Navigate to="/signin" replace />;
  if (user.mustChangePassword) return <Navigate to="/change-password" replace />;

  const allowed = user.roles?.includes('SUPER_ADMIN') || user.roles?.includes('BLUEJOB_ADMIN');
  return allowed ? <Outlet /> : <Navigate to="/app/worker" replace />;
}