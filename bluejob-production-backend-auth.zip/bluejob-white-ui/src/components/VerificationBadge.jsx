export default function VerificationBadge({ status = 'CLAIMED' }) {
  const normalized = String(status).toUpperCase();
  const map = {
    VERIFIED: ['Verified', 'status-green'],
    PENDING: ['Pending Verification', 'status-amber'],
    REJECTED: ['Rejected', 'status-red'],
    CLAIMED: ['Claimed', 'status-gray'],
    SELF_REPORTED: ['Self Reported', 'status-gray'],
  };
  const [label, cls] = map[normalized] || [status, 'status-gray'];
  return <span className={`status-badge ${cls}`}>{label}</span>;
}