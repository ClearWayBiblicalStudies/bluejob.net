import {
  Activity, BadgeDollarSign, Bell, BriefcaseBusiness, Building2, FileCheck2,
  Gauge, LayoutDashboard, Scale, Settings, ShieldCheck, Users
} from 'lucide-react';
import { NavLink } from 'react-router-dom';
import Logo from './Logo';
import ContextSwitcher from './ContextSwitcher';

const adminNav = [
  ['Overview', '/admin', LayoutDashboard],
  ['Users', '/admin/users', Users],
  ['Organizations', '/admin/organizations', Building2],
  ['Jobs', '/admin/jobs', BriefcaseBusiness],
  ['Work Scores', '/admin/work-scores', Gauge],
  ['Verification', '/admin/verification', FileCheck2],
  ['Disputes', '/admin/disputes', Scale],
  ['Billing', '/admin/billing', BadgeDollarSign],
  ['Analytics', '/admin/analytics', Activity],
  ['System Settings', '/admin/settings', Settings],
];

export default function AdminShell({ title, subtitle, actions, children }) {
  return (
    <div className="app-layout admin-layout">
      <aside className="sidebar admin-sidebar">
        <Logo />
        <div className="admin-badge"><ShieldCheck size={14}/> BlueJob Operations</div>
        <nav>
          {adminNav.map(([label, to, Icon]) => (
            <NavLink key={label} end={to === '/admin'} to={to} className={({ isActive }) => isActive ? 'active' : ''}>
              <Icon size={17} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>
      </aside>

      <div className="app-main">
        <header className="topbar admin-topbar">
          <ContextSwitcher compact />
          <div className="topbar-actions">
            <button className="icon-button" aria-label="Notifications"><Bell size={19}/></button>
            <div className="account-pill">
              <div className="avatar">AA</div>
              <div>
                <strong>Austin A.</strong>
                <span>Super Admin</span>
              </div>
            </div>
          </div>
        </header>

        <main className="page-content admin-content">
          <div className="page-heading">
            <div>
              <span className="kicker">BLUEJOB ADMINISTRATION</span>
              <h1>{title}</h1>
              {subtitle && <p>{subtitle}</p>}
            </div>
            {actions && <div className="page-actions">{actions}</div>}
          </div>
          {children}
        </main>
      </div>
    </div>
  );
}
