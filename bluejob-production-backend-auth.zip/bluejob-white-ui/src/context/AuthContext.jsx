import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { api } from '../lib/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  async function refresh() {
    try {
      const data = await api('/auth/me');
      setUser(data.user);
      return data.user;
    } catch (error) {
      if (error.status === 401) setUser(null);
      else console.error(error);
      return null;
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { refresh(); }, []);

  const value = useMemo(() => ({
    user,
    loading,
    refresh,
    async signIn(identifier, password) {
      const data = await api('/auth/signin', { method: 'POST', body: { identifier, password } });
      setUser(data.user);
      return data.user;
    },
    async signUp(fullName, email, password) {
      const data = await api('/auth/signup', { method: 'POST', body: { fullName, email, password } });
      setUser(data.user);
      return data.user;
    },
    async signOut() {
      await api('/auth/signout', { method: 'POST' });
      setUser(null);
    }
  }), [user, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used inside AuthProvider');
  return value;
}