export const founderUser = {
  id: 'founder-austin',
  name: 'Austin Alfonsi',
  username: 'Chrome Construction',
  email: 'Not connected',
  roles: ['SUPER_ADMIN', 'ORGANIZATION_OWNER'],
  status: 'Active',
  workScore: null,
  workScoreStatus: 'BUILDING',
};

export const organizations = [
  {
    id: 'chrome-construction',
    name: 'Chrome Construction',
    relationship: 'Owner',
    verification: 'Pending verification',
    jobs: 0,
    activeMembers: 1,
  },
  {
    id: 'gulfside-improvements',
    name: 'Gulfside Improvements',
    relationship: 'Admin',
    verification: 'Pending verification',
    jobs: 0,
    activeMembers: 1,
  },
];

export const platformMetrics = {
  users: 1,
  organizations: organizations.length,
  openJobs: 0,
  completedJobs: 0,
  verificationQueue: 0,
  disputes: 0,
  activeSubscriptions: 0,
  verifiedWorkVolumeCents: 0,
};

export const verificationQueue = [];
export const disputes = [];
export const jobs = [];
export const subscriptions = [];
