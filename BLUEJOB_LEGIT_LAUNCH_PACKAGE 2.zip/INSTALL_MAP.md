# BlueJob Launch Package — Save Paths

Use these exact save paths. Merge into existing production code; do not blindly overwrite working files.

Backend:
- server/migrations/004_work_score_ratings.sql
- server/migrations/005_membership_admin.sql
- server/src/services/workScore.js
- server/src/middleware/requireRatingClearance.js
- server/src/middleware/requireActiveMembership.js
- server/src/routes/ratings.js
- server/src/routes/admin.js
- server/src/routes/public.js
- server/src/config/bluejob.js

Frontend:
- src/components/BlueJobHeader.jsx
- src/components/WorkScoreCard.jsx
- src/components/RatingGate.jsx
- src/components/FoundingPrice.jsx
- src/pages/LandingPage.jsx
- src/pages/AdminJobs.jsx
- src/styles/bluejob.css

Business/product:
- docs/BLUEJOB_PRODUCT_RULES.md
- docs/WORK_SCORE_SPEC.md
- docs/LAUNCH_CHECKLIST.md
- docs/LEGAL_COPY_STARTER.md

Environment:
- .env.production.example.additions
