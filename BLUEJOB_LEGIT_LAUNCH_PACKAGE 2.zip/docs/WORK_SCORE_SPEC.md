# My Work Score — v1
Range: 300–900 once legitimate data exists. Before that: UNRATED.

Supporting metrics:
- Verified Work Value
- Completed Jobs
- Reliability
- Quality
- Schedule
- Communication
- Repeat-Work Confidence

Mandatory post-job questions:
1. Showed up/performed when agreed?
2. Completed agreed scope?
3. Work right the first time?
4. Stayed on schedule?
5. Communicated problems early?
6. Handled changes fairly?
7. Respected agreed budget/scope?
8. Professional and reliable?
9. Trust with a larger job?
10. Work together again?

No self-ratings. One rating per side per completed job. No demo data. Admin moderation must be auditable.
