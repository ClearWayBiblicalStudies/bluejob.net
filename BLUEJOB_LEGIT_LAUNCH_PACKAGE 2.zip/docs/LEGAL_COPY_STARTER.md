# BlueJob Legal Copy Starter
Product copy only; have a qualified attorney review final legal documents.

Footer:
© 2026 BlueJob. All rights reserved.

Founding membership:
BlueJob Founding Membership: $15.99/month. Subscription automatically renews until canceled. Future membership pricing may change for new members. Billing and cancellation terms apply.

Work Score disclosure:
My Work Score is a BlueJob platform reputation metric based on information available to BlueJob, including verified job activity and structured post-job evaluations. It is not a consumer credit score, credit report, employment guarantee, government score, or promise of future work.

Recommended pages:
- /terms
- /privacy
- /subscription-terms
- /work-score-methodology
- /community-standards
