# BlueJob Product Rules
1. Budget is mandatory.
2. BlueJob is a structured match system, not a phone-number lead list.
3. Consumer-facing reputation product is **My Work Score**, not Work Passport.
4. Mutual post-job rating is mandatory before either party can start another BlueJob job.
5. No fake jobs, fake bids, fake matches, fake earnings or fake scores in production.
6. New users begin UNRATED.
7. Membership is enforced server-side.
8. Admin privileges are enforced server-side and score-affecting manual actions are audited.
9. Verified Work Value is displayed separately from Work Score.
10. BlueJob does not guarantee continuous employment.
