export function requireRatingClearance(db) {
  return async function(req,res,next) {
    const pending = await db.query(`
      SELECT j.id FROM jobs j
      WHERE j.status='COMPLETED'
      AND ($1=j.gc_user_id OR $1=j.subcontractor_user_id)
      AND NOT EXISTS (
        SELECT 1 FROM job_ratings r
        WHERE r.job_id=j.id AND r.rated_by_user_id=$1
      )
      LIMIT 1
    `,[req.user.id]);

    if (pending.rows.length) return res.status(423).json({
      error:'RATING_REQUIRED',
      jobId:pending.rows[0].id,
      message:'Complete your required Work Score rating before starting new work.'
    });
    next();
  };
}
