export function requireActiveMembership(db) {
  return async function(req,res,next) {
    const r = await db.query(`SELECT membership_status,membership_expires_at FROM users WHERE id=$1 LIMIT 1`, [req.user.id]);
    if (!r.rows.length) return res.status(401).json({error:'Authentication required'});
    const m = r.rows[0];
    const okStatus = ['ACTIVE','TRIAL','COMPED'].includes(m.membership_status);
    const okDate = !m.membership_expires_at || new Date(m.membership_expires_at).getTime() > Date.now();
    if (!okStatus || !okDate) return res.status(402).json({error:'MEMBERSHIP_REQUIRED'});
    next();
  };
}
