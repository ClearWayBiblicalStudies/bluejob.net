function requireAdmin(req,res,next){
  if(!req.user || !['ADMIN','SUPER_ADMIN'].includes(req.user.role))
    return res.status(403).json({error:'Admin access required'});
  next();
}

export function registerAdminRoutes(app,{db,requireAuth}){
  app.get('/api/admin/jobs',requireAuth,requireAdmin,async(req,res)=>{
    const r=await db.query(`SELECT * FROM jobs ORDER BY created_at DESC LIMIT 250`);
    res.json({jobs:r.rows});
  });

  app.post('/api/admin/jobs',requireAuth,requireAdmin,async(req,res)=>{
    const {title,description,location,budgetMin,budgetMax,startDate}=req.body;
    if(!title||!description||!location||!budgetMax)
      return res.status(400).json({error:'title, description, location and budgetMax are required'});
    const r=await db.query(`
      INSERT INTO jobs(title,description,location,budget_min,budget_max,start_date,status,created_by_user_id)
      VALUES($1,$2,$3,$4,$5,$6,'PUBLISHED',$7) RETURNING *
    `,[title,description,location,budgetMin||null,budgetMax,startDate||null,req.user.id]);
    res.status(201).json({job:r.rows[0]});
  });

  app.delete('/api/admin/jobs/:jobId',requireAuth,requireAdmin,async(req,res)=>{
    const r=await db.query(`DELETE FROM jobs WHERE id=$1 RETURNING id`,[req.params.jobId]);
    if(!r.rows.length) return res.status(404).json({error:'Job not found'});
    res.json({success:true});
  });
}
