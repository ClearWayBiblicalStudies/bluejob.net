import { BLUEJOB } from '../config/bluejob.js';

export function registerPublicRoutes(app,{db}){
  app.get('/healthz',async(_req,res)=>{
    try{
      await db.query('SELECT 1');
      res.status(200).json({ok:true,database:'connected'});
    }catch(e){
      console.error(e);
      res.status(503).json({ok:false,database:'unavailable'});
    }
  });

  app.get('/api/public/platform',(_req,res)=>res.json({
    brand:BLUEJOB.BRAND_NAME,
    scoreName:BLUEJOB.SCORE_NAME,
    foundingPrice:BLUEJOB.FOUNDING_MONTHLY_PRICE_LABEL,
    promise:'Know the budget. Match with the right people. Get to work.'
  }));
}
