import { recalculateWorkScore } from '../services/workScore.js';

const FIELDS=['showedUpAsAgreed','completedAgreedScope','qualityRightFirstTime','stayedOnSchedule','communicatedEarly','handledChangesFairly','respectedAgreedBudget','professionalAndReliable','trustWithLargerJob','workTogetherAgain'];

export function registerRatingRoutes(app,{db,requireAuth}) {
  app.get('/api/ratings/pending',requireAuth,async(req,res)=>{
    const r=await db.query(`
      SELECT j.id,j.title FROM jobs j
      WHERE j.status='COMPLETED'
      AND ($1=j.gc_user_id OR $1=j.subcontractor_user_id)
      AND NOT EXISTS (SELECT 1 FROM job_ratings x WHERE x.job_id=j.id AND x.rated_by_user_id=$1)
    `,[req.user.id]);
    res.json({pending:r.rows});
  });

  app.post('/api/jobs/:jobId/rating',requireAuth,async(req,res)=>{
    for(const f of FIELDS){
      if(!Number.isInteger(req.body[f]) || req.body[f]<1 || req.body[f]>5)
        return res.status(400).json({error:`${f} must be 1-5`});
    }

    const jr=await db.query(`
      SELECT id,gc_user_id,subcontractor_user_id FROM jobs
      WHERE id=$1 AND status='COMPLETED'
      AND ($2=gc_user_id OR $2=subcontractor_user_id)
      LIMIT 1
    `,[req.params.jobId,req.user.id]);

    if(!jr.rows.length) return res.status(403).json({error:'You cannot rate this job.'});

    const j=jr.rows[0];
    const isGc=String(j.gc_user_id)===String(req.user.id);
    const ratedUserId=isGc?j.subcontractor_user_id:j.gc_user_id;
    const role=isGc?'GC':'SUB';
    const vals=FIELDS.map(f=>req.body[f]);

    await db.query('BEGIN');
    try{
      const ins=await db.query(`
        INSERT INTO job_ratings (
          job_id,rated_by_user_id,rated_user_id,rater_role,
          showed_up_as_agreed,completed_agreed_scope,quality_right_first_time,
          stayed_on_schedule,communicated_early,handled_changes_fairly,
          respected_agreed_budget,professional_and_reliable,
          trust_with_larger_job,work_together_again,private_note
        )
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
        ON CONFLICT(job_id,rated_by_user_id) DO NOTHING RETURNING id
      `,[req.params.jobId,req.user.id,ratedUserId,role,...vals,req.body.privateNote||null]);

      if(!ins.rows.length){
        await db.query('ROLLBACK');
        return res.status(409).json({error:'Already rated.'});
      }

      const score=await recalculateWorkScore(db,ratedUserId);
      await db.query('COMMIT');
      res.status(201).json({success:true,workScore:score});
    }catch(e){
      await db.query('ROLLBACK');
      console.error(e);
      res.status(500).json({error:'Unable to save rating.'});
    }
  });
}
