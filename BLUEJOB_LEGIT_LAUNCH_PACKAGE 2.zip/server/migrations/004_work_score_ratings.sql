-- Change BIGINT to UUID if your existing IDs are UUID.
CREATE TABLE IF NOT EXISTS job_ratings (
  id BIGSERIAL PRIMARY KEY,
  job_id BIGINT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  rated_by_user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rated_user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rater_role TEXT NOT NULL CHECK (rater_role IN ('GC','SUB')),
  showed_up_as_agreed SMALLINT NOT NULL CHECK (showed_up_as_agreed BETWEEN 1 AND 5),
  completed_agreed_scope SMALLINT NOT NULL CHECK (completed_agreed_scope BETWEEN 1 AND 5),
  quality_right_first_time SMALLINT NOT NULL CHECK (quality_right_first_time BETWEEN 1 AND 5),
  stayed_on_schedule SMALLINT NOT NULL CHECK (stayed_on_schedule BETWEEN 1 AND 5),
  communicated_early SMALLINT NOT NULL CHECK (communicated_early BETWEEN 1 AND 5),
  handled_changes_fairly SMALLINT NOT NULL CHECK (handled_changes_fairly BETWEEN 1 AND 5),
  respected_agreed_budget SMALLINT NOT NULL CHECK (respected_agreed_budget BETWEEN 1 AND 5),
  professional_and_reliable SMALLINT NOT NULL CHECK (professional_and_reliable BETWEEN 1 AND 5),
  trust_with_larger_job SMALLINT NOT NULL CHECK (trust_with_larger_job BETWEEN 1 AND 5),
  work_together_again SMALLINT NOT NULL CHECK (work_together_again BETWEEN 1 AND 5),
  private_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(job_id, rated_by_user_id),
  CHECK (rated_by_user_id <> rated_user_id)
);
CREATE INDEX IF NOT EXISTS job_ratings_rated_user_idx ON job_ratings(rated_user_id);
CREATE INDEX IF NOT EXISTS job_ratings_job_idx ON job_ratings(job_id);
ALTER TABLE users ADD COLUMN IF NOT EXISTS work_score INTEGER;
ALTER TABLE users ADD COLUMN IF NOT EXISTS work_score_rating_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS work_score_updated_at TIMESTAMPTZ;
