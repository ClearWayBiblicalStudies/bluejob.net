START HERE
1. Read INSTALL_MAP.md.
2. Do not overwrite production blindly.
3. Match BIGINT/UUID SQL ID types to your current database.
4. Test in staging first.
5. Remove demo/fake data only after real admin job publishing works.
6. Do not buy ads until signup → payment → login → job → completion → mandatory rating passes end-to-end.
