import BlueJobHeader from '../components/BlueJobHeader.jsx';
import FoundingPrice from '../components/FoundingPrice.jsx';

export default function LandingPage({onLogin,onJoin}){
  return <main className="bj-page">
    <BlueJobHeader onLogin={onLogin} onJoin={onJoin}/>
    <section className="bj-hero">
      <p className="bj-eyebrow">BUILT FOR BLUE COLLAR</p>
      <h1>Know the budget. Match with the right people. Get to work.</h1>
      <p className="bj-hero-copy">
        BlueJob connects general contractors who need dependable work completed
        with hard-working subcontractors ready to perform it. Every job starts
        with a real scope and a real budget.
      </p>
      <div className="bj-actions">
        <button className="bj-primary-button" onClick={onJoin}>I Need Work</button>
        <button className="bj-secondary-button" onClick={onJoin}>I Need To Hire</button>
      </div>
      <FoundingPrice/>
    </section>

    <section className="bj-three">
      <article><h2>Post the real job</h2><p>Scope, location, schedule, requirements and budget.</p></article>
      <article><h2>Match, don't chase</h2><p>BlueJob surfaces people who fit the work instead of creating a phone-number hunt.</p></article>
      <article><h2>Build My Work Score</h2><p>Every completed job requires both sides to evaluate the work before starting another BlueJob job.</p></article>
    </section>

    <section className="bj-score-explainer">
      <p className="bj-eyebrow">YOUR WORK SHOULD COUNT FOR SOMETHING</p>
      <h2>Your credit score tells one story. Your Work Score tells another.</h2>
    </section>

    <footer className="bj-footer">
      <span>© 2026 BlueJob. All rights reserved.</span>
      <a href="/terms">Terms</a><a href="/privacy">Privacy</a>
    </footer>
  </main>;
}
