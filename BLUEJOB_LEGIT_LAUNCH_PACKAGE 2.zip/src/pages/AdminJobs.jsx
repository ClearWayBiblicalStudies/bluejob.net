import {useEffect,useState} from 'react';

export default function AdminJobs(){
  const [jobs,setJobs]=useState([]);
  const [form,setForm]=useState({title:'',description:'',location:'',budgetMin:'',budgetMax:'',startDate:''});

  async function load(){
    const r=await fetch('/api/admin/jobs',{credentials:'include'});
    const d=await r.json();
    setJobs(d.jobs||[]);
  }
  useEffect(()=>{load().catch(console.error)},[]);

  async function create(e){
    e.preventDefault();
    const r=await fetch('/api/admin/jobs',{
      method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({...form,budgetMin:form.budgetMin?Number(form.budgetMin):null,budgetMax:Number(form.budgetMax)})
    });
    if(!r.ok) throw new Error('Unable to create job');
    setForm({title:'',description:'',location:'',budgetMin:'',budgetMax:'',startDate:''});
    await load();
  }

  async function remove(id){
    if(!confirm('Delete this job?')) return;
    const r=await fetch(`/api/admin/jobs/${id}`,{method:'DELETE',credentials:'include'});
    if(!r.ok) throw new Error('Unable to delete job');
    await load();
  }

  return <main className="bj-admin">
    <h1>BlueJob Admin — Real Work</h1>
    <form className="bj-admin-form" onSubmit={create}>
      <input placeholder="Job title" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} required/>
      <textarea placeholder="Real scope" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} required/>
      <input placeholder="Location" value={form.location} onChange={e=>setForm({...form,location:e.target.value})} required/>
      <input type="number" placeholder="Minimum budget" value={form.budgetMin} onChange={e=>setForm({...form,budgetMin:e.target.value})}/>
      <input type="number" placeholder="Maximum budget" value={form.budgetMax} onChange={e=>setForm({...form,budgetMax:e.target.value})} required/>
      <input type="date" value={form.startDate} onChange={e=>setForm({...form,startDate:e.target.value})}/>
      <button className="bj-primary-button">Publish Real Job</button>
    </form>
    {jobs.map(j=><article className="bj-admin-job" key={j.id}>
      <div><strong>{j.title}</strong><p>{j.location} · Budget up to ${Number(j.budget_max||0).toLocaleString()}</p></div>
      <button onClick={()=>remove(j.id)}>Delete</button>
    </article>)}
  </main>;
}
