export default function BlueJobHeader({onLogin,onJoin}) {
  return <header className="bj-header">
    <a className="bj-brand" href="/">
      <span className="bj-brand-mark">BJ</span>
      <span className="bj-brand-name">BLUEJOB</span>
    </a>
    <nav className="bj-nav">
      <button className="bj-link-button" onClick={onLogin}>Log in</button>
      <button className="bj-primary-button" onClick={onJoin}>Join BlueJob</button>
    </nav>
  </header>;
}
