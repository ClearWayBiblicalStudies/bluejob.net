export default function RatingGate({job,onStartRating}) {
  if(!job) return null;
  return <div className="bj-gate">
    <p className="bj-eyebrow">ONE THING BEFORE YOUR NEXT JOB</p>
    <h2>Keep BlueJob trustworthy.</h2>
    <p>Rate your completed work for <strong>{job.title||'your last job'}</strong>. Your marketplace access unlocks after you submit it.</p>
    <button className="bj-primary-button" onClick={()=>onStartRating(job.id)}>Complete Work Score Rating</button>
  </div>;
}
