export default function FoundingPrice(){
  return <aside className="bj-price">
    <strong>$15.99/month</strong>
    <span>Founding Member Price</span>
    <small>Price may increase for future members. Billing and cancellation terms apply.</small>
  </aside>;
}
