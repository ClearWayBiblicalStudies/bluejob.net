import { BriefcaseBusiness, CheckCircle2, MapPin, ShieldCheck } from 'lucide-react';
import AppShell from '../components/AppShell';
import VerificationBadge from '../components/VerificationBadge';
import { loadPassport, loadEvidence } from '../lib/profileStore';

export default function WorkPassportPage() {
  const passport = loadPassport();
  const evidence = loadEvidence();
  const verifiedCount = evidence.filter(e => e.status === 'VERIFIED').length;

  return (
    <AppShell active="passport">
      <section className="passport-hero card">
        <div className="passport-avatar">{(passport.displayName || passport.legalName || 'BJ').slice(0,2).toUpperCase()}</div>
        <div className="passport-identity">
          <span className="kicker">BLUEJOB WORK PASSPORT</span>
          <h1>{passport.displayName || passport.legalName || 'Complete your Work Passport'}</h1>
          <p><MapPin size={14}/> {passport.city && passport.state ? `${passport.city}, ${passport.state}` : 'Location not added'} · {passport.primaryTrade || 'Trade not added'}</p>
        </div>
        <div className="passport-score-box">
          <span>WORK SCORE</span>
          <strong>BUILDING</strong>
          <small>Verified evidence required</small>
        </div>
      </section>

      <div className="passport-stats-grid">
        <article className="card passport-stat"><BriefcaseBusiness size={19}/><strong>{passport.workHistory.length}</strong><span>Work history records</span></article>
        <article className="card passport-stat"><CheckCircle2 size={19}/><strong>{verifiedCount}</strong><span>Verified evidence</span></article>
        <article className="card passport-stat"><ShieldCheck size={19}/><strong>{passport.skills.length}</strong><span>Skills listed</span></article>
        <article className="card passport-stat"><MapPin size={19}/><strong>{passport.travelRadius || 0}</strong><span>Travel radius</span></article>
      </div>

      <div className="passport-columns">
        <section className="card passport-section">
          <div className="section-title"><div><span className="kicker">SKILLS</span><h2>Professional capabilities</h2></div><VerificationBadge status="SELF_REPORTED"/></div>
          <div className="selected-skills">
            {passport.skills.length ? passport.skills.map(s => <span className="skill-pill" key={s}>{s}</span>) : <p className="muted">No skills added yet.</p>}
          </div>
        </section>

        <section className="card passport-section">
          <div className="section-title"><div><span className="kicker">WORK HISTORY</span><h2>Professional record</h2></div></div>
          <div className="history-list">
            {passport.workHistory.length ? passport.workHistory.map(item => (
              <div className="history-card" key={item.id}>
                <div><strong>{item.role}</strong><span>{item.company}</span></div>
                <VerificationBadge status={item.status}/>
              </div>
            )) : <p className="muted">No work history added yet.</p>}
          </div>
        </section>
      </div>
    </AppShell>
  );
}