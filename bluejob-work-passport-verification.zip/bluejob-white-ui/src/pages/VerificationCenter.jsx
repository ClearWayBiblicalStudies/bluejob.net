import { useMemo, useState } from 'react';
import { FileCheck2, LockKeyhole, UploadCloud } from 'lucide-react';
import AppShell from '../components/AppShell';
import VerificationBadge from '../components/VerificationBadge';
import { addEvidence, loadEvidence } from '../lib/profileStore';

const evidenceTypes = [
  ['EMPLOYMENT', 'Employment Record / W-2 / 1099'],
  ['PAY_STUB', 'Pay Stub'],
  ['CONTRACT', 'Contract / Work Order'],
  ['INVOICE', 'Invoice'],
  ['PAYMENT', 'Payment Record'],
  ['EMPLOYER_CONFIRMATION', 'Employer / Contractor Confirmation'],
  ['LICENSE', 'License'],
  ['CERTIFICATION', 'Certification'],
  ['INSURANCE', 'Insurance'],
  ['PROJECT_PHOTO', 'Project Photos'],
  ['OTHER', 'Other Approved Evidence'],
];

export default function VerificationCenter() {
  const [items, setItems] = useState(loadEvidence());
  const [form, setForm] = useState({ type: 'EMPLOYMENT', title: '', organization: '', trade: '', notes: '' });
  const [fileName, setFileName] = useState('');
  const pending = useMemo(() => items.filter(x => x.status === 'PENDING').length, [items]);

  function submit(e) {
    e.preventDefault();
    if (!form.title) return;
    setItems(addEvidence({ ...form, fileName: fileName || null, source: 'USER_SUBMISSION' }));
    setForm({ type: 'EMPLOYMENT', title: '', organization: '', trade: '', notes: '' });
    setFileName('');
  }

  return (
    <AppShell active="passport">
      <div className="page-heading">
        <div>
          <span className="kicker">VERIFICATION CENTER</span>
          <h1>Turn work history into verified proof.</h1>
          <p>Submit evidence privately. BlueJob records the verification result on your Work Passport without exposing sensitive source documents.</p>
        </div>
        <div className="verification-count"><strong>{pending}</strong><span>Pending review</span></div>
      </div>

      <div className="verification-layout">
        <section className="card form-section">
          <div className="section-title">
            <div><span className="kicker">SUBMIT EVIDENCE</span><h2>Add proof of experience</h2></div>
            <UploadCloud size={22}/>
          </div>
          <form onSubmit={submit}>
            <div className="form-grid two">
              <label>Evidence type
                <select value={form.type} onChange={e => setForm(f => ({...f, type: e.target.value}))}>
                  {evidenceTypes.map(([value,label]) => <option key={value} value={value}>{label}</option>)}
                </select>
              </label>
              <label>Title / description<input value={form.title} onChange={e => setForm(f => ({...f, title: e.target.value}))}/></label>
              <label>Company / organization<input value={form.organization} onChange={e => setForm(f => ({...f, organization: e.target.value}))}/></label>
              <label>Trade<input value={form.trade} onChange={e => setForm(f => ({...f, trade: e.target.value}))}/></label>
              <label className="span-two">Notes<textarea rows="3" value={form.notes} onChange={e => setForm(f => ({...f, notes: e.target.value}))}/></label>
              <label className="span-two file-drop">
                <input type="file" onChange={e => setFileName(e.target.files?.[0]?.name || '')}/>
                <FileCheck2 size={22}/>
                <strong>{fileName || 'Choose supporting document'}</strong>
                <span>Production files must be encrypted and privately stored.</span>
              </label>
            </div>
            <button className="button button-primary" type="submit">Submit for Verification</button>
          </form>
        </section>

        <aside className="card privacy-panel">
          <LockKeyhole size={25}/>
          <span className="kicker">PRIVATE BY DESIGN</span>
          <h2>Your documents are not your public profile.</h2>
          <p>W-2s, 1099s, pay stubs, IDs, insurance records, and payment records stay private. The public Passport shows the verified result only.</p>
          <div className="privacy-example">
            <span>Public result</span>
            <strong>Employment Verified ✓</strong>
          </div>
        </aside>
      </div>

      <section className="card admin-table-card">
        <div className="admin-table-head evidence-grid">
          <span>Evidence</span><span>Organization</span><span>Trade</span><span>Status</span><span>Submitted</span>
        </div>
        {items.length === 0 ? (
          <div className="empty-state"><h3>No evidence submitted yet</h3><p>Add proof to begin strengthening your Work Passport and future Work Score.</p></div>
        ) : items.map(item => (
          <div className="admin-table-row evidence-grid" key={item.id}>
            <div><strong>{item.title}</strong><span>{item.fileName || item.type}</span></div>
            <span>{item.organization || '—'}</span>
            <span>{item.trade || '—'}</span>
            <VerificationBadge status={item.status}/>
            <span>{new Date(item.createdAt).toLocaleDateString()}</span>
          </div>
        ))}
      </section>
    </AppShell>
  );
}