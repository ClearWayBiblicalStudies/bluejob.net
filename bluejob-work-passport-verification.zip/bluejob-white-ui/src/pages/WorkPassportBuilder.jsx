import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppShell from '../components/AppShell';
import VerificationBadge from '../components/VerificationBadge';
import { loadPassport, savePassport } from '../lib/profileStore';

const skillSuggestions = {
  Framing: ['Metal Stud Framing', 'Wood Framing', 'Layout', 'Blocking', 'Doors & Hardware'],
  Concrete: ['Formwork', 'Flatwork', 'Footings', 'Reinforcement', 'Finishing'],
  Drywall: ['Hang Board', 'Finish', 'Texture', 'Repairs'],
  'General Construction': ['Punch Work', 'Demo', 'Site Work', 'Carpentry']
};

export default function WorkPassportBuilder() {
  const navigate = useNavigate();
  const [passport, setPassport] = useState(loadPassport());
  const [skillInput, setSkillInput] = useState('');
  const [history, setHistory] = useState({
    company: '', role: '', startDate: '', endDate: '', location: '',
    responsibilities: '', projectType: '', projectValue: ''
  });

  useEffect(() => savePassport(passport), [passport]);

  const completion = useMemo(() => {
    const checks = [
      passport.legalName, passport.city, passport.state, passport.primaryTrade,
      passport.skills.length > 0, passport.yearsExperience, passport.workHistory.length > 0
    ];
    return Math.round((checks.filter(Boolean).length / checks.length) * 100);
  }, [passport]);

  const update = (field, value) => setPassport(p => ({ ...p, [field]: value }));

  function addSkill(skill) {
    const clean = skill.trim();
    if (!clean || passport.skills.includes(clean)) return;
    setPassport(p => ({ ...p, skills: [...p.skills, clean] }));
    setSkillInput('');
  }

  function addHistory() {
    if (!history.company || !history.role) return;
    setPassport(p => ({
      ...p,
      workHistory: [...p.workHistory, { ...history, id: crypto.randomUUID(), status: 'CLAIMED' }]
    }));
    setHistory({
      company: '', role: '', startDate: '', endDate: '', location: '',
      responsibilities: '', projectType: '', projectValue: ''
    });
  }

  const suggestions = skillSuggestions[passport.primaryTrade] || [];

  return (
    <AppShell active="passport">
      <div className="page-heading">
        <div>
          <span className="kicker">WORK PASSPORT</span>
          <h1>Build your professional work record.</h1>
          <p>Your Work Passport begins with your history and becomes stronger as BlueJob verifies the evidence behind it.</p>
        </div>
        <div className="passport-progress"><strong>{completion}%</strong><span>Profile complete</span></div>
      </div>

      <div className="passport-layout">
        <section className="card form-section">
          <div className="section-title">
            <div><span className="kicker">01</span><h2>Professional Identity</h2></div>
            <VerificationBadge status="SELF_REPORTED"/>
          </div>
          <div className="form-grid two">
            <label>Legal name<input value={passport.legalName} onChange={e => update('legalName', e.target.value)} /></label>
            <label>Display name<input value={passport.displayName} onChange={e => update('displayName', e.target.value)} /></label>
            <label>City<input value={passport.city} onChange={e => update('city', e.target.value)} /></label>
            <label>State<input value={passport.state} onChange={e => update('state', e.target.value)} /></label>
            <label>Travel radius (miles)<input type="number" value={passport.travelRadius} onChange={e => update('travelRadius', Number(e.target.value))} /></label>
            <label>Years of experience<input value={passport.yearsExperience} onChange={e => update('yearsExperience', e.target.value)} /></label>
          </div>
        </section>

        <section className="card form-section">
          <div className="section-title">
            <div><span className="kicker">02</span><h2>Trades & Skills</h2></div>
            <VerificationBadge status="SELF_REPORTED"/>
          </div>
          <div className="form-grid two">
            <label>Primary trade
              <select value={passport.primaryTrade} onChange={e => update('primaryTrade', e.target.value)}>
                <option value="">Select trade</option>
                <option>General Construction</option><option>Framing</option><option>Concrete</option>
                <option>Drywall</option><option>Painting</option><option>Flooring</option>
                <option>HVAC</option><option>Electrical</option><option>Plumbing</option>
              </select>
            </label>
            <label>Worker type
              <select value={passport.workerType} onChange={e => update('workerType', e.target.value)}>
                <option value="INDIVIDUAL">Individual</option>
                <option value="SUBCONTRACTOR">Subcontractor</option>
                <option value="CREW">Crew</option>
              </select>
            </label>
            <label>Crew size<input type="number" min="1" value={passport.crewSize} onChange={e => update('crewSize', Number(e.target.value))} /></label>
            <label>Availability
              <select value={passport.availability} onChange={e => update('availability', e.target.value)}>
                <option value="AVAILABLE">Available</option>
                <option value="LIMITED">Limited Availability</option>
                <option value="UNAVAILABLE">Unavailable</option>
              </select>
            </label>
          </div>

          <div className="skill-entry">
            <input value={skillInput} onChange={e => setSkillInput(e.target.value)} placeholder="Add a skill" />
            <button className="button button-outline" onClick={() => addSkill(skillInput)}>Add Skill</button>
          </div>

          <div className="suggestion-row">
            {suggestions.map(s => <button key={s} className="chip" onClick={() => addSkill(s)}>{s}</button>)}
          </div>

          <div className="selected-skills">
            {passport.skills.map(s => <span className="skill-pill" key={s}>{s}</span>)}
          </div>
        </section>

        <section className="card form-section">
          <div className="section-title">
            <div><span className="kicker">03</span><h2>Work History</h2></div>
            <span className="history-note">Résumé first. Proof comes next.</span>
          </div>
          <div className="form-grid two">
            <label>Company<input value={history.company} onChange={e => setHistory(h => ({...h, company: e.target.value}))}/></label>
            <label>Position / trade<input value={history.role} onChange={e => setHistory(h => ({...h, role: e.target.value}))}/></label>
            <label>Start date<input type="date" value={history.startDate} onChange={e => setHistory(h => ({...h, startDate: e.target.value}))}/></label>
            <label>End date<input type="date" value={history.endDate} onChange={e => setHistory(h => ({...h, endDate: e.target.value}))}/></label>
            <label>Location<input value={history.location} onChange={e => setHistory(h => ({...h, location: e.target.value}))}/></label>
            <label>Project type<input value={history.projectType} onChange={e => setHistory(h => ({...h, projectType: e.target.value}))}/></label>
            <label className="span-two">Responsibilities<textarea rows="4" value={history.responsibilities} onChange={e => setHistory(h => ({...h, responsibilities: e.target.value}))}/></label>
            <label>Approx. project/work value<input value={history.projectValue} onChange={e => setHistory(h => ({...h, projectValue: e.target.value}))}/></label>
          </div>
          <button className="button button-primary" onClick={addHistory}>Add Work History</button>
          <div className="history-list">
            {passport.workHistory.map(item => (
              <div className="history-card" key={item.id}>
                <div><strong>{item.role}</strong><span>{item.company} · {item.location || 'Location not added'}</span></div>
                <VerificationBadge status={item.status}/>
              </div>
            ))}
          </div>
        </section>

        <section className="card form-section">
          <div className="section-title"><div><span className="kicker">04</span><h2>Work Readiness</h2></div></div>
          <div className="check-grid">
            <label><input type="checkbox" checked={passport.hasTools} onChange={e => update('hasTools', e.target.checked)}/> I have my own tools/equipment</label>
            <label><input type="checkbox" checked={passport.hasTransportation} onChange={e => update('hasTransportation', e.target.checked)}/> I have reliable transportation</label>
          </div>
          <div className="cta-row">
            <button className="button button-outline" onClick={() => navigate('/app/worker')}>Dashboard</button>
            <button className="button button-primary" onClick={() => navigate('/app/verification')}>Verify My Work History</button>
          </div>
        </section>
      </div>
    </AppShell>
  );
}