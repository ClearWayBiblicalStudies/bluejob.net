# BLUEJOB AUTH / SESSION ISOLATION SPEC

Goal:
Every user always enters only their own account.

Non-negotiable:
- no shared account state
- no founder fallback session
- no hard-coded login
- no localStorage credentials
- no frontend-trusted user IDs
- no automatic admin account restoration

Backend session is source of truth.

Every protected request:
1. reads session cookie
2. validates server-side session
3. resolves exactly one user
4. loads that user's permissions
5. queries data scoped to that user

GET /api/me:
must return only the authenticated user's own identity/profile.

Required test:
- user A signup/login
- user B signup/login
- confirm A cannot see B
- confirm B cannot see A
- confirm founder/admin cannot leak into either
- logout revokes session
- invalid session returns 401
