# BLUEJOB VISUAL DESIGN SPEC

Feeling:
premium, fast, clean, dimensional, trustworthy, modern, built for serious workers, like a time saver.

Palette:
- white
- pearl gray
- ice blue
- existing BlueJob blue
- deep navy used sparingly
- charcoal text
- muted blue-gray text

No green haze.

Background haze:
Use layered radial gradients in soft blues, heavily blurred.
Think airbrushed / spray-can blue mist behind white content.
Never reduce readability.

3-D:
Use layered shadows, perspective, frosted surfaces, subtle bevel/highlight, restrained glow.
Avoid spinning, gimmicky neon, cheesy chrome, excessive motion.

Work Score:
This is the main visual asset.
Main layer: MY WORK SCORE / score / rating
Supporting layers: Verified Work Value / Completed Jobs / Reliability / Repeat Hire
Public sample must say EXAMPLE SCORE.
