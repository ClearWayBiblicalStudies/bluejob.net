import { Navigate, Route, Routes } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import SignUpPage from './pages/SignUpPage';
import SignInPage from './pages/SignInPage';
import ChoosePathPage from './pages/ChoosePathPage';
import WorkerDashboard from './pages/WorkerDashboard';
import ContractorDashboard from './pages/ContractorDashboard';
import PostJobPage from './pages/PostJobPage';
import BidDetailPage from './pages/BidDetailPage';
import AdminOverview from './pages/admin/AdminOverview';
import AdminUsers from './pages/admin/AdminUsers';
import AdminOrganizations from './pages/admin/AdminOrganizations';
import AdminJobs from './pages/admin/AdminJobs';
import AdminWorkScores from './pages/admin/AdminWorkScores';
import AdminVerification from './pages/admin/AdminVerification';
import AdminDisputes from './pages/admin/AdminDisputes';
import AdminBilling from './pages/admin/AdminBilling';
import AdminAnalytics from './pages/admin/AdminAnalytics';
import AdminSettings from './pages/admin/AdminSettings';
import AdminRoute from './components/AdminRoute';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/signup" element={<SignUpPage />} />
      <Route path="/signin" element={<SignInPage />} />
      <Route path="/choose-path" element={<ChoosePathPage />} />

      <Route path="/app/worker" element={<WorkerDashboard />} />
      <Route path="/app/contractor" element={<ContractorDashboard />} />
      <Route path="/app/post-job" element={<PostJobPage />} />
      <Route path="/app/jobs/:jobId/bids" element={<BidDetailPage />} />

      <Route element={<AdminRoute />}>
        <Route path="/admin" element={<AdminOverview />} />
        <Route path="/admin/users" element={<AdminUsers />} />
        <Route path="/admin/organizations" element={<AdminOrganizations />} />
        <Route path="/admin/jobs" element={<AdminJobs />} />
        <Route path="/admin/work-scores" element={<AdminWorkScores />} />
        <Route path="/admin/verification" element={<AdminVerification />} />
        <Route path="/admin/disputes" element={<AdminDisputes />} />
        <Route path="/admin/billing" element={<AdminBilling />} />
        <Route path="/admin/analytics" element={<AdminAnalytics />} />
        <Route path="/admin/settings" element={<AdminSettings />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
