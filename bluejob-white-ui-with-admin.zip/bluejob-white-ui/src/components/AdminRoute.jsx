import { Navigate, Outlet } from 'react-router-dom';
import { canAccessAdmin, ensureFounderPreviewSession } from '../lib/adminSession';

export default function AdminRoute() {
  const session = ensureFounderPreviewSession();

  if (!canAccessAdmin(session)) {
    return <Navigate to="/signin" replace />;
  }

  return <Outlet />;
}
