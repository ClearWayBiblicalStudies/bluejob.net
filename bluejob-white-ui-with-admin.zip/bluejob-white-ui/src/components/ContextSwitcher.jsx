import { Building2, ChevronDown, HardHat, ShieldCheck, UserRound } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { ensureFounderPreviewSession, setActiveContext } from '../lib/adminSession';

const contexts = [
  { id: 'PERSONAL', label: 'Personal Work Passport', detail: 'Austin Alfonsi', icon: UserRound, to: '/app/worker' },
  { id: 'CHROME', label: 'Chrome Construction', detail: 'Company workspace', icon: HardHat, to: '/app/contractor' },
  { id: 'GULFSIDE', label: 'Gulfside Improvements', detail: 'Company workspace', icon: Building2, to: '/app/contractor' },
  { id: 'BLUEJOB_ADMIN', label: 'BlueJob Administration', detail: 'Super Admin', icon: ShieldCheck, to: '/admin' },
];

export default function ContextSwitcher({ compact = false }) {
  const navigate = useNavigate();
  const session = ensureFounderPreviewSession();
  const current = contexts.find((item) => item.id === session.activeContext) || contexts[3];
  const Icon = current.icon;

  function changeContext(event) {
    const next = contexts.find((item) => item.id === event.target.value);
    if (!next) return;
    setActiveContext(next.id);
    navigate(next.to);
  }

  return (
    <div className={`context-switcher ${compact ? 'context-switcher--compact' : ''}`}>
      <div className="context-switcher-icon"><Icon size={16} /></div>
      <div className="context-switcher-copy">
        <span>Workspace</span>
        <strong>{current.label}</strong>
      </div>
      <select aria-label="Switch BlueJob workspace" value={current.id} onChange={changeContext}>
        {contexts.map((item) => (
          <option key={item.id} value={item.id}>
            {item.label} — {item.detail}
          </option>
        ))}
      </select>
      <ChevronDown size={14} />
    </div>
  );
}
