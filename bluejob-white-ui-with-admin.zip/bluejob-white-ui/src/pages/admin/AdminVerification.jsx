import AdminShell from '../../components/AdminShell';
import EmptyState from '../../components/EmptyState';

export default function AdminVerification() {
  return (
    <AdminShell title="Verification Queue" subtitle="Review identity, work history, employment, licenses, insurance, certifications, and work evidence.">
      <div className="verification-summary">
        <div className="card verification-stat"><strong>0</strong><span>Waiting</span></div>
        <div className="card verification-stat"><strong>0</strong><span>High Priority</span></div>
        <div className="card verification-stat"><strong>0</strong><span>Needs Information</span></div>
        <div className="card verification-stat"><strong>0</strong><span>Completed Today</span></div>
      </div>
      <section className="card admin-panel">
        <EmptyState title="Verification queue is clear" copy="Private documents must remain access-controlled. Public Work Passports display verification results, never sensitive source documents."/>
      </section>
    </AdminShell>
  );
}
