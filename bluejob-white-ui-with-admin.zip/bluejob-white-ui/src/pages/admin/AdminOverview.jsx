import { BadgeDollarSign, BriefcaseBusiness, Building2, FileCheck2, Gauge, Scale, Users, WalletCards } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import AdminMetric from '../../components/AdminMetric';
import EmptyState from '../../components/EmptyState';
import { founderUser, organizations, platformMetrics } from '../../data/adminData';

export default function AdminOverview() {
  return (
    <AdminShell
      title="Operations Command Center"
      subtitle="Private platform control for BlueJob operations, verification, marketplace health, and growth."
      actions={<button className="button button-primary">Review Platform</button>}
    >
      <div className="admin-metric-grid">
        <AdminMetric label="Registered Users" value={platformMetrics.users} detail="Founder account active" icon={Users}/>
        <AdminMetric label="Organizations" value={platformMetrics.organizations} detail="Initial company workspaces" icon={Building2}/>
        <AdminMetric label="Open Jobs" value={platformMetrics.openJobs} detail="Marketplace opportunities" icon={BriefcaseBusiness}/>
        <AdminMetric label="Verification Queue" value={platformMetrics.verificationQueue} detail="Awaiting human review" icon={FileCheck2}/>
        <AdminMetric label="Active Work Scores" value="0" detail="Founder score remains Building" icon={Gauge}/>
        <AdminMetric label="Disputes" value={platformMetrics.disputes} detail="Open cases" icon={Scale}/>
        <AdminMetric label="Subscriptions" value={platformMetrics.activeSubscriptions} detail="Active paid memberships" icon={WalletCards}/>
        <AdminMetric label="Verified Work Volume" value="$0" detail="Completed verified work" icon={BadgeDollarSign}/>
      </div>

      <div className="admin-two-col">
        <section className="card admin-panel">
          <div className="panel-heading">
            <div>
              <span className="kicker">FOUNDER ACCOUNT</span>
              <h2>{founderUser.name}</h2>
            </div>
            <span className="status-badge status-blue">SUPER ADMIN</span>
          </div>

          <div className="detail-list">
            <div><span>Username</span><strong>{founderUser.username}</strong></div>
            <div><span>Work Score</span><strong>{founderUser.workScoreStatus}</strong></div>
            <div><span>Public score override</span><strong>Disabled</strong></div>
            <div><span>Administrative access</span><strong>Private</strong></div>
          </div>

          <div className="integrity-notice">
            BlueJob administration can control the platform, but cannot manually award a public Work Score. Score integrity uses the same evidence rules for every account.
          </div>
        </section>

        <section className="card admin-panel">
          <div className="panel-heading">
            <div>
              <span className="kicker">INITIAL ORGANIZATIONS</span>
              <h2>Company Workspaces</h2>
            </div>
          </div>
          <div className="org-stack">
            {organizations.map((org) => (
              <div className="org-item" key={org.id}>
                <div className="org-mark">{org.name.slice(0,2).toUpperCase()}</div>
                <div>
                  <strong>{org.name}</strong>
                  <span>{org.relationship} · {org.verification}</span>
                </div>
                <button className="button button-outline">Open</button>
              </div>
            ))}
          </div>
        </section>
      </div>

      <div className="admin-two-col">
        <section className="card admin-panel">
          <div className="panel-heading"><div><span className="kicker">MARKETPLACE</span><h2>Live Operations</h2></div></div>
          <EmptyState
            title="No marketplace activity yet"
            copy="When BlueJob opens, new jobs, bids, matches, completions, and verified work activity will appear here in real time."
          />
        </section>
        <section className="card admin-panel">
          <div className="panel-heading"><div><span className="kicker">ACTION CENTER</span><h2>Needs Attention</h2></div></div>
          <EmptyState
            title="Nothing requires review"
            copy="Verification requests, disputes, failed payments, safety flags, and suspicious activity will be routed here."
          />
        </section>
      </div>
    </AdminShell>
  );
}
