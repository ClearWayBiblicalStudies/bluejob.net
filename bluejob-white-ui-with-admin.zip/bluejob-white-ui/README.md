# BlueJob White UI

White/blue BlueJob frontend matching the approved visual direction.

## Run

```bash
npm install
npm run dev
```

## Included routes

- `/` — public landing page
- `/signup` — account creation
- `/signin` — sign in
- `/choose-path` — subcontractor vs contractor path
- `/app/worker` — Work Score / Work Passport worker dashboard
- `/app/contractor` — contractor operations dashboard
- `/app/post-job` — 5-step job posting flow
- `/app/jobs/1/bids` — bid comparison + bidding insights

## Important

This package is the UI/application shell. Replace frontend-only auth and example values with production API/database services before public launch. Passwords, payment data, verification documents, Work Score decisions, and admin authorization must be server-side.


## BlueJob Administration

New private founder/admin routes:

- `/admin` — Operations Command Center
- `/admin/users`
- `/admin/organizations`
- `/admin/jobs`
- `/admin/work-scores`
- `/admin/verification`
- `/admin/disputes`
- `/admin/billing`
- `/admin/analytics`
- `/admin/settings`

The current package includes a local founder-preview session for UI development only.

**Production requirement:** every privileged action must be authenticated and authorized by the backend. Never rely on hidden frontend navigation as security. The initial founder account must force a password change and MFA during real authentication setup. Work Scores cannot be manually assigned by administrators.
